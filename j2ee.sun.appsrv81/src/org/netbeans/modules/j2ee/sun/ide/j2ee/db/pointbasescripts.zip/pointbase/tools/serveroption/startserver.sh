#!/bin/sh


. "./pbenv.conf"

echo "Starting Server with $PB_CONFIGURED_JAVA_HOME ..."
"$PB_CONFIGURED_JAVA_HOME/bin/java" -Djava.security.manager -Djava.security.policy="$AS_POINTBASE_SAMPLESDB/databases/pointbase.policy" -Ddatabase.home="$AS_POINTBASE_SAMPLESDB/databases" -Dpointbase.ini="$AS_POINTBASE_SAMPLESDB/databases/pointbase.ini" -Dpointbase.lib="$AS_POINTBASE/lib" -classpath .:"$AS_POINTBASE/lib/pbembedded.jar" com.pointbase.net.netServer $@
