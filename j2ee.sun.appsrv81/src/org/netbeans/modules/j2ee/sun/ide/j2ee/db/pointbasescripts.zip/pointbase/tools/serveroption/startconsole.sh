#!/bin/sh


. "./pbenv.conf"

echo "Using $PB_CONFIGURED_JAVA_HOME ..."
"$PB_CONFIGURED_JAVA_HOME/bin/java" -Ddatabase.home="$AS_POINTBASE_SAMPLESDB/databases" -Dpointbase.ini="$AS_POINTBASE_SAMPLESDB/databases/pointbase.ini"   -classpath .:"$AS_POINTBASE/lib/pbclient.jar":"$AS_POINTBASE/lib/pbtools.jar":"$AS_POINTBASE/lib/pbembedded.jar" com.pointbase.tools.toolsConsole
