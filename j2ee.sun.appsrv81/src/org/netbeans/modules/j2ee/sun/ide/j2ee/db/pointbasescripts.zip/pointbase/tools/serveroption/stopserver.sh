#!/bin/sh


. "./pbenv.conf"

echo "Stopping Server with $PB_CONFIGURED_JAVA_HOME ..."
"$PB_CONFIGURED_JAVA_HOME/bin/java" -classpath  .:"$AS_POINTBASE/lib/pbclient.jar":"$AS_POINTBASE/lib/pbtools.jar" com.pointbase.tools.toolsCommander com.pointbase.jdbc.jdbcUniversalDriver jdbc:pointbase:server://localhost/sample "$AS_POINTBASE/tools/serveroption/stopserver.sql" pbsysadmin pbsysadmin 1>/dev/null


