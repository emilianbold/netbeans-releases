# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

class SystemCallError < StandardError
  #     system_call_error === other  => true or false
  #   
  # 
  # Return +true+ if the receiver is a generic +SystemCallError+, or
  # if the error numbers _self_ and _other_ are the same.
  # 
  # 
  # 
  def self.===
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     system_call_error.errno   => fixnum
  #   
  # 
  # Return this SystemCallError's error number.
  # 
  # 
  def errno
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     SystemCallError.new(msg, errno)  => system_call_error_subclass
  #   
  # 
  # If _errno_ corresponds to a known system error code, constructs
  # the appropriate <code>Errno</code> class for that error, otherwise
  # constructs a generic <code>SystemCallError</code> object. The
  # error number is subsequently available via the <code>errno</code>
  # method.
  # 
  # 
  def self.new(msg, errno)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
