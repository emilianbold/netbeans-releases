# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# Document-class: Regexp
#   
# A <code>Regexp</code> holds a regular expression, used to match a pattern
# against strings. Regexps are created using the <code>/.../</code> and
# <code>%r{...}</code> literals, and by the <code>Regexp::new</code>
# constructor.
#   
# 
# 
class Regexp
  IGNORECASE = 'INT2FIX(RE_OPTION_IGNORECASE)'
  EXTENDED = 'INT2FIX(RE_OPTION_EXTENDED)'
  MULTILINE = 'INT2FIX(RE_OPTION_MULTILINE)'
  #     rxp === str   => true or false
  #   
  # 
  # Case Equality---Synonym for <code>Regexp#=~</code> used in case statements.
  #    
  #    a = "HELLO"
  #    case a
  #    when /^[a-z]*$/; print "Lower case\n"
  #    when /^[A-Z]*$/; print "Upper case\n"
  #    else;            print "Mixed case\n"
  #    end
  #    
  # <em>produces:</em>
  #    
  #    Upper case
  # 
  # 
  def ===
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp == other_rxp      => true or false
  #     rxp.eql?(other_rxp)   => true or false
  #   
  # 
  # Equality---Two regexps are equal if their patterns are identical, they have
  # the same character set code, and their <code>casefold?</code> values are the
  # same.
  #    
  #    /abc/  == /abc/x   #=> false
  #    /abc/  == /abc/i   #=> false
  #    /abc/u == /abc/n   #=> false
  # 
  # 
  def eql?(other_rxp)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.match(str)   => matchdata or nil
  #   
  # 
  # Returns a <code>MatchData</code> object describing the match, or
  # <code>nil</code> if there was no match. This is equivalent to retrieving the
  # value of the special variable <code>$~</code> following a normal match.
  #    
  #    /(.)(.)(.)/.match("abc")[2]   #=> "b"
  # 
  # 
  def match(str)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     ~ rxp   => integer or nil
  #   
  # 
  # Match---Matches <i>rxp</i> against the contents of <code>$_</code>.
  # Equivalent to <code><i>rxp</i> =~ $_</code>.
  #    
  #    $_ = "input data"
  #    ~ /at/   #=> 7
  # 
  # 
  def ~
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.casefold?   => true or false
  #   
  # 
  # Returns the value of the case-insensitive flag.
  # 
  # 
  def casefold?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Synonym for <code>Regexp.new</code>
  # 
  def self.compile(*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp == other_rxp      => true or false
  #     rxp.eql?(other_rxp)   => true or false
  #   
  # 
  # Equality---Two regexps are equal if their patterns are identical, they have
  # the same character set code, and their <code>casefold?</code> values are the
  # same.
  #    
  #    /abc/  == /abc/x   #=> false
  #    /abc/  == /abc/i   #=> false
  #    /abc/u == /abc/n   #=> false
  # 
  # 
  def eql?(other_rxp)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.escape(str)   => a_str
  #     Regexp.quote(str)    => a_str
  #   
  # 
  # Escapes any characters that would have special meaning in a regular
  # expression. Returns a new escaped string, or self if no characters are
  # escaped.  For any string,
  # <code>Regexp.escape(<i>str</i>)=~<i>str</i></code> will be true.
  #    
  #    Regexp.escape('\\*?{}.')   #=> \\\\\*\?\{\}\.
  # 
  # 
  def self.escape(str)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.escape(str)   => a_str
  #     Regexp.quote(str)    => a_str
  #   
  # 
  # Escapes any characters that would have special meaning in a regular
  # expression. Returns a new escaped string, or self if no characters are
  # escaped.  For any string,
  # <code>Regexp.escape(<i>str</i>)=~<i>str</i></code> will be true.
  #    
  #    Regexp.escape('\\*?{}.')   #=> \\\\\*\?\{\}\.
  # 
  # 
  def self.quote(str)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.hash   => fixnum
  #   
  # 
  # Produce a hash based on the text and options of this regular expression.
  # 
  # 
  def hash
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.inspect   => string
  #   
  # 
  # Produce a nicely formatted string-version of _rxp_. Perhaps surprisingly,
  # <code>#inspect</code> actually produces the more natural version of
  # the string than <code>#to_s</code>.
  #   
  #    /ab+c/ix.to_s         #=> /ab+c/ix
  #   
  # 
  def inspect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.kcode   => str
  #   
  # 
  # Returns the character set code for the regexp.
  # 
  # 
  def kcode
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.last_match           => matchdata
  #     Regexp.last_match(fixnum)   => str
  #   
  # 
  # The first form returns the <code>MatchData</code> object generated by the
  # last successful pattern match. Equivalent to reading the global variable
  # <code>$~</code>. The second form returns the nth field in this
  # <code>MatchData</code> object.
  #    
  #    /c(.)t/ =~ 'cat'       #=> 0
  #    Regexp.last_match      #=> #<MatchData:0x401b3d30>
  #    Regexp.last_match(0)   #=> "cat"
  #    Regexp.last_match(1)   #=> "a"
  #    Regexp.last_match(2)   #=> nil
  # 
  # 
  def self.last_match(fixnum)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.match(str)   => matchdata or nil
  #   
  # 
  # Returns a <code>MatchData</code> object describing the match, or
  # <code>nil</code> if there was no match. This is equivalent to retrieving the
  # value of the special variable <code>$~</code> following a normal match.
  #    
  #    /(.)(.)(.)/.match("abc")[2]   #=> "b"
  # 
  # 
  def match(str)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.new(string [, options [, lang]])       => regexp
  #     Regexp.new(regexp)                            => regexp
  #     Regexp.compile(string [, options [, lang]])   => regexp
  #     Regexp.compile(regexp)                        => regexp
  #   
  # 
  # Constructs a new regular expression from <i>pattern</i>, which can be either
  # a <code>String</code> or a <code>Regexp</code> (in which case that regexp's
  # options are propagated, and new options may not be specified (a change as of
  # Ruby 1.8). If <i>options</i> is a <code>Fixnum</code>, it should be one or
  # more of the constants <code>Regexp::EXTENDED</code>,
  # <code>Regexp::IGNORECASE</code>, and <code>Regexp::MULTILINE</code>,
  # <em>or</em>-ed together. Otherwise, if <i>options</i> is not
  # <code>nil</code>, the regexp will be case insensitive. The <i>lang</i>
  # parameter enables multibyte support for the regexp: `n', `N' = none, `e',
  # `E' = EUC, `s', `S' = SJIS, `u', `U' = UTF-8.
  # 
  #    r1 = Regexp.new('^a-z+:\\s+\w+')           #=> /^a-z+:\s+\w+/
  #    r2 = Regexp.new('cat', true)               #=> /cat/i
  #    r3 = Regexp.new('dog', Regexp::EXTENDED)   #=> /dog/x
  #    r4 = Regexp.new(r2)                        #=> /cat/i
  # 
  # 
  def self.compile(regexp)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.new(string [, options [, lang]])       => regexp
  #     Regexp.new(regexp)                            => regexp
  #     Regexp.compile(string [, options [, lang]])   => regexp
  #     Regexp.compile(regexp)                        => regexp
  #   
  # 
  # Constructs a new regular expression from <i>pattern</i>, which can be either
  # a <code>String</code> or a <code>Regexp</code> (in which case that regexp's
  # options are propagated, and new options may not be specified (a change as of
  # Ruby 1.8). If <i>options</i> is a <code>Fixnum</code>, it should be one or
  # more of the constants <code>Regexp::EXTENDED</code>,
  # <code>Regexp::IGNORECASE</code>, and <code>Regexp::MULTILINE</code>,
  # <em>or</em>-ed together. Otherwise, if <i>options</i> is not
  # <code>nil</code>, the regexp will be case insensitive. The <i>lang</i>
  # parameter enables multibyte support for the regexp: `n', `N' = none, `e',
  # `E' = EUC, `s', `S' = SJIS, `u', `U' = UTF-8.
  # 
  #    r1 = Regexp.new('^a-z+:\\s+\w+')           #=> /^a-z+:\s+\w+/
  #    r2 = Regexp.new('cat', true)               #=> /cat/i
  #    r3 = Regexp.new('dog', Regexp::EXTENDED)   #=> /dog/x
  #    r4 = Regexp.new(r2)                        #=> /cat/i
  # 
  # 
  def self.new(string, options, lang)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.new(string [, options [, lang]])       => regexp
  #     Regexp.new(regexp)                            => regexp
  #     Regexp.compile(string [, options [, lang]])   => regexp
  #     Regexp.compile(regexp)                        => regexp
  #   
  # 
  # Constructs a new regular expression from <i>pattern</i>, which can be either
  # a <code>String</code> or a <code>Regexp</code> (in which case that regexp's
  # options are propagated, and new options may not be specified (a change as of
  # Ruby 1.8). If <i>options</i> is a <code>Fixnum</code>, it should be one or
  # more of the constants <code>Regexp::EXTENDED</code>,
  # <code>Regexp::IGNORECASE</code>, and <code>Regexp::MULTILINE</code>,
  # <em>or</em>-ed together. Otherwise, if <i>options</i> is not
  # <code>nil</code>, the regexp will be case insensitive. The <i>lang</i>
  # parameter enables multibyte support for the regexp: `n', `N' = none, `e',
  # `E' = EUC, `s', `S' = SJIS, `u', `U' = UTF-8.
  # 
  #    r1 = Regexp.new('^a-z+:\\s+\w+')           #=> /^a-z+:\s+\w+/
  #    r2 = Regexp.new('cat', true)               #=> /cat/i
  #    r3 = Regexp.new('dog', Regexp::EXTENDED)   #=> /dog/x
  #    r4 = Regexp.new(r2)                        #=> /cat/i
  # 
  # 
  def self.compile(string, options, lang)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.new(string [, options [, lang]])       => regexp
  #     Regexp.new(regexp)                            => regexp
  #     Regexp.compile(string [, options [, lang]])   => regexp
  #     Regexp.compile(regexp)                        => regexp
  #   
  # 
  # Constructs a new regular expression from <i>pattern</i>, which can be either
  # a <code>String</code> or a <code>Regexp</code> (in which case that regexp's
  # options are propagated, and new options may not be specified (a change as of
  # Ruby 1.8). If <i>options</i> is a <code>Fixnum</code>, it should be one or
  # more of the constants <code>Regexp::EXTENDED</code>,
  # <code>Regexp::IGNORECASE</code>, and <code>Regexp::MULTILINE</code>,
  # <em>or</em>-ed together. Otherwise, if <i>options</i> is not
  # <code>nil</code>, the regexp will be case insensitive. The <i>lang</i>
  # parameter enables multibyte support for the regexp: `n', `N' = none, `e',
  # `E' = EUC, `s', `S' = SJIS, `u', `U' = UTF-8.
  # 
  #    r1 = Regexp.new('^a-z+:\\s+\w+')           #=> /^a-z+:\s+\w+/
  #    r2 = Regexp.new('cat', true)               #=> /cat/i
  #    r3 = Regexp.new('dog', Regexp::EXTENDED)   #=> /dog/x
  #    r4 = Regexp.new(r2)                        #=> /cat/i
  # 
  # 
  def self.new(regexp)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.options   => fixnum
  #   
  # 
  # Returns the set of bits corresponding to the options used when creating this
  # Regexp (see <code>Regexp::new</code> for details. Note that additional bits
  # may be set in the returned options: these are used internally by the regular
  # expression code. These extra bits are ignored if the options are passed to
  # <code>Regexp::new</code>.
  #    
  #    Regexp::IGNORECASE                  #=> 1
  #    Regexp::EXTENDED                    #=> 2
  #    Regexp::MULTILINE                   #=> 4
  #    
  #    /cat/.options                       #=> 128
  #    /cat/ix.options                     #=> 131
  #    Regexp.new('cat', true).options     #=> 129
  #    Regexp.new('cat', 0, 's').options   #=> 384
  #    
  #    r = /cat/ix
  #    Regexp.new(r.source, r.options)     #=> /cat/ix
  # 
  # 
  def options
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.escape(str)   => a_str
  #     Regexp.quote(str)    => a_str
  #   
  # 
  # Escapes any characters that would have special meaning in a regular
  # expression. Returns a new escaped string, or self if no characters are
  # escaped.  For any string,
  # <code>Regexp.escape(<i>str</i>)=~<i>str</i></code> will be true.
  #    
  #    Regexp.escape('\\*?{}.')   #=> \\\\\*\?\{\}\.
  # 
  # 
  def self.escape(str)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.escape(str)   => a_str
  #     Regexp.quote(str)    => a_str
  #   
  # 
  # Escapes any characters that would have special meaning in a regular
  # expression. Returns a new escaped string, or self if no characters are
  # escaped.  For any string,
  # <code>Regexp.escape(<i>str</i>)=~<i>str</i></code> will be true.
  #    
  #    Regexp.escape('\\*?{}.')   #=> \\\\\*\?\{\}\.
  # 
  # 
  def self.quote(str)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.source   => str
  #   
  # 
  # Returns the original string of the pattern.
  #    
  #    /ab+c/ix.source   #=> "ab+c"
  # 
  # 
  def source
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     rxp.to_s   => str
  #   
  # 
  # Returns a string containing the regular expression and its options (using the
  # <code>(?xxx:yyy)</code> notation. This string can be fed back in to
  # <code>Regexp::new</code> to a regular expression with the same semantics as
  # the original. (However, <code>Regexp#==</code> may not return true when
  # comparing the two, as the source of the regular expression itself may
  # differ, as the example shows).  <code>Regexp#inspect</code> produces a
  # generally more readable version of <i>rxp</i>.
  #    
  #    r1 = /ab+c/ix         #=> /ab+c/ix
  #    s1 = r1.to_s          #=> "(?ix-m:ab+c)"
  #    r2 = Regexp.new(s1)   #=> /(?ix-m:ab+c)/
  #    r1 == r2              #=> false
  #    r1.source             #=> "ab+c"
  #    r2.source             #=> "(?ix-m:ab+c)"
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Regexp.union([pattern]*)   => new_str
  #   
  # 
  # Return a <code>Regexp</code> object that is the union of the given
  # <em>pattern</em>s, i.e., will match any of its parts. The <em>pattern</em>s
  # can be Regexp objects, in which case their options will be preserved, or
  # Strings. If no arguments are given, returns <code>/(?!)/</code>.
  #    
  #    Regexp.union                         #=> /(?!)/
  #    Regexp.union("penzance")             #=> /penzance/
  #    Regexp.union("skiing", "sledding")   #=> /skiing|sledding/
  #    Regexp.union(/dogs/, /cats/i)        #=> /(?-mix:dogs)|(?i-mx:cats)/
  # 
  def self.union(pattern)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
