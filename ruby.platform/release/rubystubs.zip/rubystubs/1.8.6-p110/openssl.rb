# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# OSSL library init
# 
module OpenSSL
  VERSION = 'rb_str_new2(OSSL_VERSION)'
  OPENSSL_VERSION = 'rb_str_new2(OPENSSL_VERSION_TEXT)'
  OPENSSL_VERSION_NUMBER = 'INT2NUM(OPENSSL_VERSION_NUMBER)'

  module ASN1
    UNIVERSAL_TAG_NAME = ary

    class ASN1Data

    end

    class ASN1Error < eOSSLError

    end

    class Constructive < OpenSSL::ASN1::ASN1Data
      include Enumerable

    end

    class Primitive < OpenSSL::ASN1::ASN1Data

    end

  end

  class BN

  end

  class BNError < eOSSLError

  end

  module Cipher

    class Cipher

    end

  end

  class CipherError < eOSSLError

  end

  module Digest

    class Digest

    end

    class DigestError < eOSSLError

    end

  end

  class HMAC

  end

  class HMACError < eOSSLError

  end

  class OpenSSLError < StandardError

  end

  module PKey

    class DH < cPKey
      #   
      # Stores all parameters of key to the hash
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      # 
      def params
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # Makes new instance DH PUBLIC_KEY from PRIVATE_KEY
      # 
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # Prints all parameters of key to buffer
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      # 
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class DHError < ePKeyError

    end

    class DSA < cPKey
      #   
      # Stores all parameters of key to the hash
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      # 
      def params
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # Makes new instance DSA PUBLIC_KEY from PRIVATE_KEY
      # 
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # Prints all parameters of key to buffer
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      # 
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class DSAError < ePKeyError

    end

    class PKey

    end

    class PKeyError < eOSSLError

    end

    class RSA < cPKey
      #   
      # Stores all parameters of key to the hash
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (I's up to you)
      # 
      def params
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # Makes new instance RSA PUBLIC_KEY from PRIVATE_KEY
      # 
      def public_key
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # Prints all parameters of key to buffer
      # INSECURE: PRIVATE INFORMATIONS CAN LEAK OUT!!!
      # Don't use :-)) (It's up to you)
      # 
      def to_text
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class RSAError < ePKeyError

    end

  end

  module Random

    class RandomError < eOSSLError

    end

  end

  module SSL

    class SSLContext

    end

    class SSLError < eOSSLError

    end

    class SSLSocket

    end

  end

end
