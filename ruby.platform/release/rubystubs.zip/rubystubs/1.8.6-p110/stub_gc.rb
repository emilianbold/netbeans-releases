# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# The <code>GC</code> module provides an interface to Ruby's mark and
# sweep garbage collection mechanism. Some of the underlying methods
# are also available via the <code>ObjectSpace</code> module.
# 
# 
module GC
  #     GC.disable    => true or false
  #   
  # 
  # Disables garbage collection, returning <code>true</code> if garbage
  # collection was already disabled.
  #   
  #    GC.disable   #=> false
  #    GC.disable   #=> true
  #   
  # 
  # 
  def self.disable
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     GC.enable    => true or false
  #   
  # 
  # Enables garbage collection, returning <code>true</code> if garbage
  # collection was previously disabled.
  #   
  #    GC.disable   #=> false
  #    GC.enable    #=> true
  #    GC.enable    #=> false
  #   
  # 
  # 
  def self.enable
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     GC.start                     => nil
  #     gc.garbage_collect           => nil
  #     ObjectSpace.garbage_collect  => nil
  #   
  # 
  # Initiates garbage collection, unless manually disabled.
  #   
  # 
  # 
  def garbage_collect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     GC.start                     => nil
  #     gc.garbage_collect           => nil
  #     ObjectSpace.garbage_collect  => nil
  #   
  # 
  # Initiates garbage collection, unless manually disabled.
  #   
  # 
  # 
  def self.start
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
