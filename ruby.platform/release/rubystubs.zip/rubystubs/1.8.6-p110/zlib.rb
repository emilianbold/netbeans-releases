# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
# GZIP_SUPPORT   
# 
# 
module Zlib
  VERSION = 'rb_str_new2(RUBY_ZLIB_VERSION)'
  ZLIB_VERSION = 'rb_str_new2(ZLIB_VERSION)'
  BINARY = 'INT2FIX(Z_BINARY)'
  ASCII = 'INT2FIX(Z_ASCII)'
  UNKNOWN = 'INT2FIX(Z_UNKNOWN)'
  NO_COMPRESSION = 'INT2FIX(Z_NO_COMPRESSION)'
  BEST_SPEED = 'INT2FIX(Z_BEST_SPEED)'
  BEST_COMPRESSION = 'INT2FIX(Z_BEST_COMPRESSION)'
  DEFAULT_COMPRESSION = 'INT2FIX(Z_DEFAULT_COMPRESSION)'
  FILTERED = 'INT2FIX(Z_FILTERED)'
  HUFFMAN_ONLY = 'INT2FIX(Z_HUFFMAN_ONLY)'
  DEFAULT_STRATEGY = 'INT2FIX(Z_DEFAULT_STRATEGY)'
  MAX_WBITS = 'INT2FIX(MAX_WBITS)'
  DEF_MEM_LEVEL = 'INT2FIX(DEF_MEM_LEVEL)'
  MAX_MEM_LEVEL = 'INT2FIX(MAX_MEM_LEVEL)'
  NO_FLUSH = 'INT2FIX(Z_NO_FLUSH)'
  SYNC_FLUSH = 'INT2FIX(Z_SYNC_FLUSH)'
  FULL_FLUSH = 'INT2FIX(Z_FULL_FLUSH)'
  FINISH = 'INT2FIX(Z_FINISH)'
  OS_CODE = 'INT2FIX(OS_CODE)'
  OS_MSDOS = 'INT2FIX(OS_MSDOS)'
  OS_AMIGA = 'INT2FIX(OS_AMIGA)'
  OS_VMS = 'INT2FIX(OS_VMS)'
  OS_UNIX = 'INT2FIX(OS_UNIX)'
  OS_ATARI = 'INT2FIX(OS_ATARI)'
  OS_OS2 = 'INT2FIX(OS_OS2)'
  OS_MACOS = 'INT2FIX(OS_MACOS)'
  OS_TOPS20 = 'INT2FIX(OS_TOPS20)'
  OS_WIN32 = 'INT2FIX(OS_WIN32)'
  OS_VMCMS = 'INT2FIX(OS_VMCMS)'
  OS_ZSYSTEM = 'INT2FIX(OS_ZSYSTEM)'
  OS_CPM = 'INT2FIX(OS_CPM)'
  OS_QDOS = 'INT2FIX(OS_QDOS)'
  OS_RISCOS = 'INT2FIX(OS_RISCOS)'
  OS_UNKNOWN = 'INT2FIX(OS_UNKNOWN)'
  #      Zlib.adler32(string, adler)
  #   
  # 
  # Calculates Alder-32 checksum for +string+, and returns updated value of
  # +adler+. If +string+ is omitted, it returns the Adler-32 initial value. If
  # +adler+ is omitted, it assumes that the initial value is given to +adler+.
  #   
  # FIXME: expression.
  # 
  def self.adler32(string, adler)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      Zlib.crc32(string, adler)
  #   
  # 
  # Calculates CRC checksum for +string+, and returns updated value of +crc+. If
  # +string+ is omitted, it returns the CRC initial value. If +crc+ is omitted, it
  # assumes that the initial value is given to +crc+.
  #   
  # FIXME: expression.
  # 
  def self.crc32(string, adler)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns the table for calculating CRC checksum as an array.
  # 
  def self.crc_table
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns the string which represents the version of zlib library.
  # 
  def self.zlib_version
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


  class BufError < Zlib::Error

  end

  class DataError < Zlib::Error

  end
  #   
  # Zlib::Deflate is the class for compressing data.  See Zlib::Stream for more
  # information.
  # 
  class Deflate < Zlib::ZStream
    # Same as IO.
    # 
    def <<(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::Deflate.deflate(string[, level])
    #   
    # 
    # Compresses the given +string+. Valid values of level are
    # <tt>Zlib::NO_COMPRESSION</tt>, <tt>Zlib::BEST_SPEED</tt>,
    # <tt>Zlib::BEST_COMPRESSION</tt>, <tt>Zlib::DEFAULT_COMPRESSION</tt>, and an
    # integer from 0 to 9.
    #   
    # This method is almost equivalent to the following code:
    #   
    #  def deflate(string, level)
    #    z = Zlib::Deflate.new(level)
    #    dst = z.deflate(string, Zlib::FINISH)
    #    z.close
    #    dst
    #  end
    #   
    # TODO: what's default value of +level+?
    #   
    # 
    def self.deflate(string, level)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      deflate(string[, flush])
    #   
    # 
    # Inputs +string+ into the deflate stream and returns the output from the
    # stream.  On calling this method, both the input and the output buffers of
    # the stream are flushed. If +string+ is nil, this method finishes the
    # stream, just like Zlib::ZStream#finish.
    #   
    # The value of +flush+ should be either <tt>Zlib::NO_FLUSH</tt>,
    # <tt>Zlib::SYNC_FLUSH</tt>, <tt>Zlib::FULL_FLUSH</tt>, or
    # <tt>Zlib::FINISH</tt>. See zlib.h for details.
    #   
    # TODO: document better!
    # 
    def  deflate(string, flush)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      flush(flush)
    #   
    # 
    # This method is equivalent to <tt>deflate('', flush)</tt>.  If flush is omitted,
    # <tt>Zlib::SYNC_FLUSH</tt> is used as flush.  This method is just provided
    # to improve the readability of your Ruby program.
    #   
    # TODO: document better!
    # 
    def  flush(flush)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Duplicates the deflate stream.
    # 
    def initialize_copy
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::Deflate.new(level=nil, windowBits=nil, memlevel=nil, strategy=nil)
    #   
    # 
    # Creates a new deflate stream for compression. See zlib.h for details of
    # each argument. If an argument is nil, the default value of that argument is
    # used.
    #   
    # TODO: document better!
    # 
    def self.new(level=nil, windowBits=nil, memlevel=nil, strategy=nil)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      params(level, strategy)
    #   
    # 
    # Changes the parameters of the deflate stream. See zlib.h for details. The
    # output from the stream by changing the params is preserved in output
    # buffer.
    #   
    # TODO: document better!
    # 
    def  params(level, strategy)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      set_dictionary(string)
    #   
    # 
    # Sets the preset dictionary and returns +string+. This method is available
    # just only after Zlib::Deflate.new or Zlib::ZStream#reset method was called.
    # See zlib.h for details.
    #   
    # TODO: document better!
    # 
    def  set_dictionary(string)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end
  #   
  # The superclass for all exceptions raised by Ruby/zlib.
  #   
  # The following exceptions are defined as subclasses of Zlib::Error. These
  # exceptions are raised when zlib library functions return with an error
  # status.
  #   
  # - Zlib::StreamEnd
  # - Zlib::NeedDict
  # - Zlib::DataError
  # - Zlib::StreamError
  # - Zlib::MemError
  # - Zlib::BufError
  # - Zlib::VersionError
  #   
  # 
  class Error < StandardError

  end
  #   
  # Zlib::GzipFile is an abstract class for handling a gzip formatted
  # compressed file. The operations are defined in the subclasses,
  # Zlib::GzipReader for reading, and Zlib::GzipWriter for writing.
  #   
  # GzipReader should be used by associating an IO, or IO-like, object.
  # 
  class GzipFile
    #   
    # Closes the GzipFile object. This method calls close method of the
    # associated IO object. Returns the associated IO object.
    # 
    def close
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Same as IO.
    # 
    def closed?
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns comments recorded in the gzip file header, or nil if the comments
    # is not present.
    # 
    def comment
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns CRC value of the uncompressed data.
    # 
    def crc
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Closes the GzipFile object. Unlike Zlib::GzipFile#close, this method never
    # calls the close method of the associated IO object. Returns the associated IO
    # object.
    # 
    def finish
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns compression level.
    # 
    def level
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns last modification time recorded in the gzip file header.
    # 
    def mtime
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns original filename recorded in the gzip file header, or +nil+ if
    # original filename is not present.
    # 
    def orig_name
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns OS code number recorded in the gzip file header.
    # 
    def os_code
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      sync = flag
    #   
    # 
    # Same as IO.  If flag is +true+, the associated IO object must respond to the
    # +flush+ method.  While +sync+ mode is +true+, the compression ratio
    # decreases sharply.
    # 
    def sync=
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Same as IO.
    # 
    def sync
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Same as IO.
    # 
    def to_io
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader#wrap and Zlib::GzipWriter#wrap.
    # 
    def self.wrap(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Raised when the CRC checksum recorded in gzip file footer is not equivalent
    # to the CRC checksum of the actual uncompressed data. 
    # 
    class CRCError < Zlib::GzipFile::Error

    end
    #   
    # Base class of errors that occur when processing GZIP files.
    # 
    class Error < Zlib::Error

    end
    #   
    # Raised when the data length recorded in the gzip file footer is not equivalent
    # to the length of the actual uncompressed data. 
    # 
    class LengthError < Zlib::GzipFile::Error

    end
    #   
    # Raised when gzip file footer is not found. 
    # 
    class NoFooter < Zlib::GzipFile::Error

    end

  end
  #   
  # Zlib::GzipReader is the class for reading a gzipped file.  GzipReader should
  # be used an IO, or -IO-lie, object.
  #   
  #  Zlib::GzipReader.open('hoge.gz') {|gz|
  #    print gz.read
  #  }
  #   
  #  File.open('hoge.gz') do |f|
  #    gz = Zlib::GzipReader.new(f)
  #    print gz.read
  #    gz.close
  #  end
  #   
  #  # TODO: test these.  Are they equivalent?  Can GzipReader.new take a
  #  # block?
  #   
  # == Method Catalogue
  #   
  # The following methods in Zlib::GzipReader are just like their counterparts
  # in IO, but they raise Zlib::Error or Zlib::GzipFile::Error exception if an
  # error was found in the gzip file.
  # - #each
  # - #each_line
  # - #each_byte
  # - #gets
  # - #getc
  # - #lineno
  # - #lineno=
  # - #read
  # - #readchar
  # - #readline
  # - #readlines
  # - #ungetc
  #   
  # Be careful of the footer of the gzip file. A gzip file has the checksum of
  # pre-compressed data in its footer. GzipReader checks all uncompressed data
  # against that checksum at the following cases, and if it fails, raises
  # <tt>Zlib::GzipFile::NoFooter</tt>, <tt>Zlib::GzipFile::CRCError</tt>, or
  # <tt>Zlib::GzipFile::LengthError</tt> exception.
  #   
  # - When an reading request is received beyond the end of file (the end of
  #  compressed data). That is, when Zlib::GzipReader#read,
  #  Zlib::GzipReader#gets, or some other methods for reading returns nil.
  # - When Zlib::GzipFile#close method is called after the object reaches the
  #  end of file.
  # - When Zlib::GzipReader#unused method is called after the object reaches
  #  the end of file.
  #   
  # The rest of the methods are adequately described in their own
  # documentation.
  # 
  class GzipReader < Zlib::GzipFile
    include Enumerable
    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def each(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def each_byte
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def each_line(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def eof?
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def eof
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def getc
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def gets(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def lineno=(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def lineno
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::GzipReader.new(io)
    #   
    # 
    # Creates a GzipReader object associated with +io+. The GzipReader object reads
    # gzipped data from +io+, and parses/decompresses them.  At least, +io+ must have
    # a +read+ method that behaves same as the +read+ method in IO class.
    #   
    # If the gzip file header is incorrect, raises an Zlib::GzipFile::Error
    # exception.
    # 
    def self.new(io)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::GzipReader.open(filename) {|gz| ... }
    #   
    # 
    # Opens a file specified by +filename+ as a gzipped file, and returns a
    # GzipReader object associated with that file.  Further details of this method
    # are in Zlib::GzipReader.new and ZLib::GzipReader.wrap.
    # 
    def self.open(filename)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def pos
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def read(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def readchar
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def readline(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def readlines(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Resets the position of the file pointer to the point created the GzipReader
    # object.  The associated IO object needs to respond to the +seek+ method.
    # 
    def rewind
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def tell
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # See Zlib::GzipReader documentation for a description.
    # 
    def ungetc(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns the rest of the data which had read for parsing gzip format, or
    # +nil+ if the whole gzip file is not parsed yet.
    # 
    def unused
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end
  #   
  # Zlib::GzipWriter is a class for writing gzipped files.  GzipWriter should
  # be used with an instance of IO, or IO-like, object. 
  #   
  # For example:
  #   
  #  Zlib::GzipWriter.open('hoge.gz') do |gz|
  #    gz.write 'jugemu jugemu gokou no surikire...'
  #  end
  #   
  #  File.open('hoge.gz', 'w') do |f|
  #    gz = Zlib::GzipWriter.new(f)
  #    gz.write 'jugemu jugemu gokou no surikire...'
  #    gz.close
  #  end
  #   
  #  # TODO: test these.  Are they equivalent?  Can GzipWriter.new take a
  #  # block?
  #   
  # NOTE: Due to the limitation of Ruby's finalizer, you must explicitly close
  # GzipWriter objects by Zlib::GzipWriter#close etc.  Otherwise, GzipWriter
  # will be not able to write the gzip footer and will generate a broken gzip
  # file.
  # 
  class GzipWriter < Zlib::GzipFile
    #   
    # Document-method: <<
    # Same as IO.
    # 
    # Same as IO.
    # 
    def <<(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def comment=(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      flush(flush=nil)
    #   
    # 
    # Flushes all the internal buffers of the GzipWriter object.  The meaning of
    # +flush+ is same as in Zlib::Deflate#deflate.  <tt>Zlib::SYNC_FLUSH</tt> is used if
    # +flush+ is omitted.  It is no use giving flush <tt>Zlib::NO_FLUSH</tt>.
    # 
    def  flush(flush=nil)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def mtime=(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::GzipWriter.new(io, level, strategy)
    #   
    # 
    # Creates a GzipWriter object associated with +io+. +level+ and +strategy+
    # should be the same as the arguments of Zlib::Deflate.new.  The GzipWriter
    # object writes gzipped data to +io+.  At least, +io+ must respond to the
    # +write+ method that behaves same as write method in IO class.
    # 
    def self.new(io, level, strategy)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::GzipWriter.open(filename, level=nil, strategy=nil) { |gz| ... }
    #   
    # 
    # Opens a file specified by +filename+ for writing gzip compressed data, and
    # returns a GzipWriter object associated with that file.  Further details of
    # this method are found in Zlib::GzipWriter.new and Zlib::GzipWriter#wrap.
    # 
    def self.open(filename, level=nil, strategy=nil)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def orig_name=(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def pos
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Document-method: print
    # Same as IO.
    # 
    # Same as IO.
    # 
    def print(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Document-method: printf
    # Same as IO.
    # 
    # Same as IO.
    # 
    def printf(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Same as IO.
    # 
    def putc(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Document-method: puts
    # Same as IO.
    # 
    # Same as IO.
    # 
    def puts(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # ???
    # 
    def tell
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Same as IO.
    # 
    def write(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end
  #   
  # Zlib:Inflate is the class for decompressing compressed data.  Unlike
  # Zlib::Deflate, an instance of this class is not able to duplicate (clone,
  # dup) itself.
  # 
  class Inflate < Zlib::ZStream
    # Same as IO.
    # 
    def <<(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::Inflate.inflate(string)
    #   
    # 
    # Decompresses +string+. Raises a Zlib::NeedDict exception if a preset
    # dictionary is needed for decompression.
    #   
    # This method is almost equivalent to the following code:
    #   
    #  def inflate(string)
    #    zstream = Zlib::Inflate.new
    #    buf = zstream.inflate(string)
    #    zstream.finish
    #    zstream.close
    #    buf
    #  end
    #   
    # 
    def self.inflate(string)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      inflate(string)
    #   
    # 
    # Inputs +string+ into the inflate stream and returns the output from the
    # stream.  Calling this method, both the input and the output buffer of the
    # stream are flushed.  If string is +nil+, this method finishes the stream,
    # just like Zlib::ZStream#finish.
    #   
    # Raises a Zlib::NeedDict exception if a preset dictionary is needed to
    # decompress.  Set the dictionary by Zlib::Inflate#set_dictionary and then
    # call this method again with an empty string.  (<i>???</i>)
    #   
    # TODO: document better!
    # 
    def  inflate(string)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      Zlib::Inflate.new(window_bits)
    #   
    # 
    # Creates a new inflate stream for decompression. See zlib.h for details
    # of the argument.  If +window_bits+ is +nil+, the default value is used.
    #   
    # TODO: document better!
    # 
    def self.new(window_bits)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Sets the preset dictionary and returns +string+.  This method is available just
    # only after a Zlib::NeedDict exception was raised.  See zlib.h for details.
    #   
    # TODO: document better!
    # 
    def set_dictionary(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #      sync(string)
    #   
    # 
    # Inputs +string+ into the end of input buffer and skips data until a full
    # flush point can be found.  If the point is found in the buffer, this method
    # flushes the buffer and returns false.  Otherwise it returns +true+ and the
    # following data of full flush point is preserved in the buffer.
    # 
    def  sync(string)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Quoted verbatim from original documentation:
    #   
    #  What is this?
    #   
    # <tt>:)</tt>
    # 
    def sync_point?
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

  class MemError < Zlib::Error

  end

  class NeedDict < Zlib::Error

  end

  class StreamEnd < Zlib::Error

  end

  class StreamError < Zlib::Error

  end

  class VersionError < Zlib::Error

  end
  #   
  # Zlib::ZStream is the abstract class for the stream which handles the
  # compressed data. The operations are defined in the subclasses:
  # Zlib::Deflate for compression, and Zlib::Inflate for decompression.
  #   
  # An instance of Zlib::ZStream has one stream (struct zstream in the source)
  # and two variable-length buffers which associated to the input (next_in) of
  # the stream and the output (next_out) of the stream. In this document,
  # "input buffer" means the buffer for input, and "output buffer" means the
  # buffer for output.
  #   
  # Data input into an instance of Zlib::ZStream are temporally stored into
  # the end of input buffer, and then data in input buffer are processed from
  # the beginning of the buffer until no more output from the stream is
  # produced (i.e. until avail_out > 0 after processing).  During processing,
  # output buffer is allocated and expanded automatically to hold all output
  # data.
  #   
  # Some particular instance methods consume the data in output buffer and
  # return them as a String.
  #   
  # Here is an ascii art for describing above:
  #   
  #   +================ an instance of Zlib::ZStream ================+
  #   ||                                                            ||
  #   ||     +--------+          +-------+          +--------+      ||
  #   ||  +--| output |<---------|zstream|<---------| input  |<--+  ||
  #   ||  |  | buffer |  next_out+-------+next_in   | buffer |   |  ||
  #   ||  |  +--------+                             +--------+   |  ||
  #   ||  |                                                      |  ||
  #   +===|======================================================|===+
  #       |                                                      |
  #       v                                                      |
  #   "output data"                                         "input data"
  #   
  # If an error occurs during processing input buffer, an exception which is a
  # subclass of Zlib::Error is raised.  At that time, both input and output
  # buffer keep their conditions at the time when the error occurs.
  #   
  # == Method Catalogue
  #   
  # Many of the methods in this class are fairly low-level and unlikely to be
  # of interest to users.  In fact, users are unlikely to use this class
  # directly; rather they will be interested in Zlib::Inflate and
  # Zlib::Deflate.
  #   
  # The higher level methods are listed below.
  #   
  # - #total_in
  # - #total_out
  # - #data_type
  # - #adler
  # - #reset
  # - #finish
  # - #finished?
  # - #close
  # - #closed?
  # 
  class ZStream
    #   
    # Returns the adler-32 checksum.
    # 
    def adler
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns bytes of data in the input buffer. Normally, returns 0.
    # 
    def avail_in
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Allocates +size+ bytes of free space in the output buffer. If there are more
    # than +size+ bytes already in the buffer, the buffer is truncated. Because 
    # free space is allocated automatically, you usually don't need to use this
    # method.
    # 
    def avail_out=(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns number of bytes of free spaces in output buffer.  Because the free
    # space is allocated automatically, this method returns 0 normally.
    # 
    def avail_out
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Closes the stream. All operations on the closed stream will raise an
    # exception.
    # 
    def close
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Returns true if the stream is closed.
    # 
    def closed?
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Guesses the type of the data which have been inputed into the stream. The
    # returned value is either <tt>Zlib::BINARY</tt>, <tt>Zlib::ASCII</tt>, or
    # <tt>Zlib::UNKNOWN</tt>.
    # 
    def data_type
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # Closes the stream. All operations on the closed stream will raise an
    # exception.
    # 
    def end
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns true if the stream is closed.
  # 
  def ended?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Finishes the stream and flushes output buffer. See Zlib::Deflate#finish and
  # Zlib::Inflate#finish for details of this behavior.
  # 
  def finish
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns true if the stream is finished.
  # 
  def finished?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Flushes input buffer and returns all data in that buffer.
  # 
  def flush_next_in
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Flushes output buffer and returns all data in that buffer.
  # 
  def flush_next_out
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Resets and initializes the stream. All data in both input and output buffer
  # are discarded.
  # 
  def reset
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns true if the stream is finished.
  # 
  def stream_end?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns the total bytes of the input data to the stream.  FIXME
  # 
  def total_in
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Returns the total bytes of the output data from the stream.  FIXME
  # 
  def total_out
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end

end
