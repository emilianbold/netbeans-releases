# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# Descendents of class <code>Exception</code> are used to communicate
# between <code>raise</code> methods and <code>rescue</code>
# statements in <code>begin/end</code> blocks. <code>Exception</code>
# objects carry information about the exception---its type (the
# exception's class name), an optional descriptive string, and
# optional traceback information. Programs may subclass 
# <code>Exception</code> to add additional information.
# 
# 
class Exception
  #     exception.backtrace    => array
  #   
  # 
  # Returns any backtrace associated with the exception. The backtrace
  # is an array of strings, each containing either ``filename:lineNo: in
  # `method''' or ``filename:lineNo.''
  #    
  #    def a
  #      raise "boom"
  #    end
  #    
  #    def b
  #      a()
  #    end
  #    
  #    begin
  #      b()
  #    rescue => detail
  #      print detail.backtrace.join("\n")
  #    end
  #    
  # <em>produces:</em>
  #    
  #    prog.rb:2:in `a'
  #    prog.rb:6:in `b'
  #    prog.rb:10
  #   
  # 
  def backtrace
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exc.exception(string) -> an_exception or exc
  #   
  # 
  # With no argument, or if the argument is the same as the receiver,
  # return the receiver. Otherwise, create a new
  # exception object of the same class as the receiver, but with a
  # message equal to <code>string.to_str</code>.
  #    
  # 
  def self.exception(string)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exc.exception(string) -> an_exception or exc
  #   
  # 
  # With no argument, or if the argument is the same as the receiver,
  # return the receiver. Otherwise, create a new
  # exception object of the same class as the receiver, but with a
  # message equal to <code>string.to_str</code>.
  #    
  # 
  def exception(string)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exception.inspect   => string
  #   
  # 
  # Return this exception's class name an message
  # 
  # 
  def inspect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exception.message   =>  string
  #     exception.to_str    =>  string
  #   
  # 
  # Returns the result of invoking <code>exception.to_s</code>.
  # Normally this returns the exception's message or name. By
  # supplying a to_str method, exceptions are agreeing to
  # be used where Strings are expected.
  # 
  # 
  def message
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Exception.new(msg = nil)   =>  exception
  #   
  # 
  # Construct a new Exception object, optionally passing in 
  # a message.
  # 
  # 
  def self.new(msg = nil)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exc.set_backtrace(array)   =>  array
  #   
  # 
  # Sets the backtrace information associated with <i>exc</i>. The
  # argument must be an array of <code>String</code> objects in the
  # format described in <code>Exception#backtrace</code>.
  #    
  # 
  # 
  def set_backtrace(array)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exception.to_s   =>  string
  #   
  # 
  # Returns exception's message (or the name of the exception if
  # no message is set).
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     exception.message   =>  string
  #     exception.to_str    =>  string
  #   
  # 
  # Returns the result of invoking <code>exception.to_s</code>.
  # Normally this returns the exception's message or name. By
  # supplying a to_str method, exceptions are agreeing to
  # be used where Strings are expected.
  # 
  # 
  def to_str
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
