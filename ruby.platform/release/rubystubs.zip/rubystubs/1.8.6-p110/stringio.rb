# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# Pseudo I/O on String object.
# 
class StringIO < Data
  include Enumerable
  #     strio << obj     -> strio
  #   
  # 
  # See IO#<<.
  # 
  def <<
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.binmode -> true # 
  #   
  # Returns *strio* itself.  Just for compatibility to IO.
  # 
  def binmode
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.close  -> nil
  #   
  # 
  # Closes strio.  The *strio* is unavailable for any further data 
  # operations; an +IOError+ is raised if such an attempt is made.
  # 
  def close
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.close_read    -> nil
  #   
  # 
  # Closes the read end of a StringIO.  Will raise an +IOError+ if the
  # *strio* is not readable.
  # 
  def close_read
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.close_write    -> nil
  #   
  # 
  # Closes the write end of a StringIO.  Will raise an  +IOError+ if the
  # *strio* is not writeable.
  # 
  def close_write
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.closed?    -> true or false
  #   
  # 
  # Returns +true+ if *strio* is completely closed, +false+ otherwise.
  # 
  def closed?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.closed_read?    -> true or false
  #   
  # 
  # Returns +true+ if *strio* is not readable, +false+ otherwise.
  # 
  def closed_read?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.closed_write?    -> true or false
  #   
  # 
  # Returns +true+ if *strio* is not writable, +false+ otherwise.
  # 
  def closed_write?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.each(sep_string=$/)      {|line| block }  -> strio
  #     strio.each_line(sep_string=$/) {|line| block }  -> strio
  #   
  # 
  # See IO#each.
  # 
  def each_line(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.each(sep_string=$/)      {|line| block }  -> strio
  #     strio.each_line(sep_string=$/) {|line| block }  -> strio
  #   
  # 
  # See IO#each.
  # 
  def each(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.each_byte {|byte| block }  -> strio
  #   
  # 
  # See IO#each_byte.
  # 
  def each_byte
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.each(sep_string=$/)      {|line| block }  -> strio
  #     strio.each_line(sep_string=$/) {|line| block }  -> strio
  #   
  # 
  # See IO#each.
  # 
  def each_line(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.each(sep_string=$/)      {|line| block }  -> strio
  #     strio.each_line(sep_string=$/) {|line| block }  -> strio
  #   
  # 
  # See IO#each.
  # 
  def each(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.eof     -> true or false
  #     strio.eof?    -> true or false
  #   
  # 
  # Returns true if *strio* is at end of file. The stringio must be  
  # opened for reading or an +IOError+ will be raised.
  # 
  def eof?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.eof     -> true or false
  #     strio.eof?    -> true or false
  #   
  # 
  # Returns true if *strio* is at end of file. The stringio must be  
  # opened for reading or an +IOError+ will be raised.
  # 
  def eof
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.fcntl # 
  #   
  # Raises NotImplementedError.
  # 
  def fcntl
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.fileno -> nil # 
  #   
  # Returns +nil+.  Just for compatibility to IO.
  # 
  def fileno
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.flush -> strio # 
  #   
  # Returns *strio* itself.  Just for compatibility to IO.
  # 
  def flush
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.fsync -> 0 # 
  #   
  # Returns 0.  Just for compatibility to IO.
  # 
  def fsync
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.getc   -> fixnum or nil
  #   
  # 
  # See IO#getc.
  # 
  def getc
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.gets(sep_string=$/)   -> string or nil
  #   
  # 
  # See IO#gets.
  # 
  def gets(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.isatty -> nil
  #     strio.tty? -> nil
  #   
  # 
  # 
  #   
  # Returns +false+.  Just for compatibility to IO.
  # 
  def isatty
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.size   -> integer
  #   
  # 
  # Returns the size of the buffer string.
  # 
  def length
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.lineno = integer    -> integer
  #   
  # 
  # Manually sets the current line number to the given value.
  # <code>$.</code> is updated only on the next read.
  # 
  def lineno=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.lineno    -> integer
  #   
  # 
  # Returns the current line number in *strio*. The stringio must be
  # opened for reading. +lineno+ counts the number of times  +gets+ is
  # called, rather than the number of newlines  encountered. The two
  # values will differ if +gets+ is  called with a separator other than
  # newline.  See also the  <code>$.</code> variable.
  # 
  def lineno
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      StringIO.new(string=""[, mode])
  #   
  # 
  # Creates new StringIO instance from with _string_ and _mode_.
  # 
  def self.new(string="", mode=3)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      StringIO.open(string=""[, mode]) {|strio| ...}
  #   
  # 
  # Equivalent to StringIO.new except that when it is called with a block, it
  # yields with the new instance and closes it, and returns the result which
  # returned from the block.
  # 
  def self.open(string="", mode=3)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.path -> nil # 
  #   
  # Returns +nil+.  Just for compatibility to IO.
  # 
  def path
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.pid -> nil # 
  #   
  # Returns +nil+.  Just for compatibility to IO.
  # 
  def pid
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.pos = integer    -> integer
  #   
  # 
  # Seeks to the given position (in bytes) in *strio*.
  # 
  def pos=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.pos     -> integer
  #     strio.tell    -> integer
  #   
  # 
  # Returns the current offset (in bytes) of *strio*.
  # 
  def pos
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.print()             -> nil
  #     strio.print(obj, ...)     -> nil
  #   
  # 
  # See IO#print.
  # 
  def print(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.printf(format_string [, obj, ...] )   -> nil
  #   
  # 
  # See IO#printf.
  # 
  def printf(format_string, obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.putc(obj)    -> obj
  #   
  # 
  # See IO#putc.
  # 
  def putc(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.puts(obj, ...)    -> nil
  #   
  # 
  # See IO#puts.
  # 
  def puts(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.read([length [, buffer]])    -> string, buffer, or nil
  #   
  # 
  # See IO#read.
  # 
  def read(length, buffer)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.readchar   -> fixnum
  #   
  # 
  # See IO#readchar.
  # 
  def readchar
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.readline(sep_string=$/)   -> string
  #   
  # 
  # See IO#readline.
  # 
  def readline(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.readlines(sep_string=$/)  ->   array
  #   
  # 
  # See IO#readlines.
  # 
  def readlines(sep_string="$/")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.reopen(other_StrIO)     -> strio
  #     strio.reopen(string, mode)    -> strio
  #   
  # 
  # Reinitializes *strio* with the given <i>other_StrIO</i> or _string_ 
  # and _mode_ (see StringIO#new).
  # 
  def reopen(string, mode)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.reopen(other_StrIO)     -> strio
  #     strio.reopen(string, mode)    -> strio
  #   
  # 
  # Reinitializes *strio* with the given <i>other_StrIO</i> or _string_ 
  # and _mode_ (see StringIO#new).
  # 
  def reopen(other_StrIO)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.rewind    -> 0
  #   
  # 
  # Positions *strio* to the beginning of input, resetting
  # +lineno+ to zero.
  # 
  def rewind
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.seek(amount, whence=SEEK_SET) -> 0
  #   
  # 
  # Seeks to a given offset _amount_ in the stream according to
  # the value of _whence_ (see IO#seek).
  # 
  def seek(amount, whence=SEEK_SET)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.size   -> integer
  #   
  # 
  # Returns the size of the buffer string.
  # 
  def size
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.string = string  -> string
  #   
  # 
  # Changes underlying String object, the subject of IO.
  # 
  def string=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.string     -> string
  #   
  # 
  # Returns underlying String object, the subject of IO.
  # 
  def string
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      strio.sync = boolean -> boolean # 
  #   
  # Returns the argument unchanged.  Just for compatibility to IO.
  # 
  def sync=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.sync    -> true
  #   
  # 
  # Returns +true+ always.
  # 
  def sync
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.sysread(integer[, outbuf])    -> string
  #   
  # 
  # Similar to #read, but raises +EOFError+ at end of string instead of
  # returning +nil+, as well as IO#sysread does.
  # 
  def sysread(integer, outbuf)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.write(string)    -> integer
  #     strio.syswrite(string) -> integer
  #   
  # 
  # Appends the given string to the underlying buffer string of *strio*.
  # The stream must be opened for writing.  If the argument is not a
  # string, it will be converted to a string using <code>to_s</code>.
  # Returns the number of bytes written.  See IO#write.
  # 
  def syswrite(string)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.write(string)    -> integer
  #     strio.syswrite(string) -> integer
  #   
  # 
  # Appends the given string to the underlying buffer string of *strio*.
  # The stream must be opened for writing.  If the argument is not a
  # string, it will be converted to a string using <code>to_s</code>.
  # Returns the number of bytes written.  See IO#write.
  # 
  def write(string)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.pos     -> integer
  #     strio.tell    -> integer
  #   
  # 
  # Returns the current offset (in bytes) of *strio*.
  # 
  def tell
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.truncate(integer)    -> 0
  #   
  # 
  # Truncates the buffer string to at most _integer_ bytes. The *strio*
  # must be opened for writing.
  # 
  def truncate(integer)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.isatty -> nil
  #     strio.tty? -> nil
  #   
  # 
  # 
  #   
  # Returns +false+.  Just for compatibility to IO.
  # 
  def tty?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.ungetc(integer)   -> nil
  #   
  # 
  # Pushes back one character (passed as a parameter) onto *strio*
  # such that a subsequent buffered read will return it.  Pushing back 
  # behind the beginning of the buffer string is not possible.  Nothing
  # will be done if such an attempt is made.
  # In other case, there is no limitation for multiple pushbacks.
  # 
  def ungetc(integer)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.write(string)    -> integer
  #     strio.syswrite(string) -> integer
  #   
  # 
  # Appends the given string to the underlying buffer string of *strio*.
  # The stream must be opened for writing.  If the argument is not a
  # string, it will be converted to a string using <code>to_s</code>.
  # Returns the number of bytes written.  See IO#write.
  # 
  def syswrite(string)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     strio.write(string)    -> integer
  #     strio.syswrite(string) -> integer
  #   
  # 
  # Appends the given string to the underlying buffer string of *strio*.
  # The stream must be opened for writing.  If the argument is not a
  # string, it will be converted to a string using <code>to_s</code>.
  # Returns the number of bytes written.  See IO#write.
  # 
  def write(string)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
