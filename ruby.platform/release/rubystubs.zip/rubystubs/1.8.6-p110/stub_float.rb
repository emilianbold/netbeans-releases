# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# <code>Float</code> objects represent real numbers using the native
# architecture's double-precision floating point representation.
# 
class Float < Numeric
  include Precision
  ROUNDS = 'INT2FIX(FLT_ROUNDS)'
  RADIX = 'INT2FIX(FLT_RADIX)'
  MANT_DIG = 'INT2FIX(DBL_MANT_DIG)'
  DIG = 'INT2FIX(DBL_DIG)'
  MIN_EXP = 'INT2FIX(DBL_MIN_EXP)'
  MAX_EXP = 'INT2FIX(DBL_MAX_EXP)'
  MIN_10_EXP = 'INT2FIX(DBL_MIN_10_EXP)'
  MAX_10_EXP = 'INT2FIX(DBL_MAX_10_EXP)'
  MIN = 'rb_float_new(DBL_MIN)'
  MAX = 'rb_float_new(DBL_MAX)'
  EPSILON = 'rb_float_new(DBL_EPSILON)'
  #     flt % other         => float
  #     flt.modulo(other)   => float
  #   
  # 
  # Return the modulo after division of <code>flt</code> by <code>other</code>.
  #    
  #    6543.21.modulo(137)      #=> 104.21
  #    6543.21.modulo(137.24)   #=> 92.9299999999996
  # 
  # 
  def modulo(other)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     
  #   
  # 
  # flt ** other   => float
  #   
  # Raises <code>float</code> the <code>other</code> power.
  # 
  #  
  def **
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     float * other   => float
  #   
  # 
  # Returns a new float which is the product of <code>float</code>
  # and <code>other</code>.
  # 
  # 
  def *
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     float + other   => float
  #   
  # 
  # Returns a new float which is the sum of <code>float</code>
  # and <code>other</code>.
  # 
  # 
  def +
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     -float   => float
  #   
  # 
  # Returns float, negated.
  # 
  # 
  def -@
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     float + other   => float
  #   
  # 
  # Returns a new float which is the difference of <code>float</code>
  # and <code>other</code>.
  # 
  # 
  def -
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     float / other   => float
  #   
  # 
  # Returns a new float which is the result of dividing
  # <code>float</code> by <code>other</code>.
  # 
  # 
  def /
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt <=> numeric   => -1, 0, +1
  #   
  # 
  # Returns -1, 0, or +1 depending on whether <i>flt</i> is less than,
  # equal to, or greater than <i>numeric</i>. This is the basis for the
  # tests in <code>Comparable</code>.
  # 
  # 
  def <=>
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt <= other    =>  true or false
  #   
  # 
  # <code>true</code> if <code>flt</code> is less than
  # or equal to <code>other</code>.
  # 
  # 
  def <=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt < other    =>  true or false
  #   
  # 
  # <code>true</code> if <code>flt</code> is less than <code>other</code>.
  # 
  # 
  def <
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt == obj   => true or false
  #   
  # 
  # Returns <code>true</code> only if <i>obj</i> has the same value
  # as <i>flt</i>. Contrast this with <code>Float#eql?</code>, which
  # requires <i>obj</i> to be a <code>Float</code>.
  #    
  #    1.0 == 1   #=> true
  #    
  # 
  # 
  def ==
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt >= other    =>  true or false
  #   
  # 
  # <code>true</code> if <code>flt</code> is greater than 
  # or equal to <code>other</code>.
  # 
  # 
  def >=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt > other    =>  true or false
  #   
  # 
  # <code>true</code> if <code>flt</code> is greater than <code>other</code>.
  # 
  # 
  def >
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.abs    => float
  #   
  # 
  # Returns the absolute value of <i>flt</i>.
  #    
  #    (-34.56).abs   #=> 34.56
  #    -34.56.abs     #=> 34.56
  #    
  # 
  # 
  def abs
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.ceil    => integer
  #   
  # 
  # Returns the smallest <code>Integer</code> greater than or equal to
  # <i>flt</i>.
  #    
  #    1.2.ceil      #=> 2
  #    2.0.ceil      #=> 2
  #    (-1.2).ceil   #=> -1
  #    (-2.0).ceil   #=> -2
  # 
  # 
  def ceil
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # MISSING: documentation
  # 
  # 
  def coerce(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.divmod(numeric)    => array
  #   
  # 
  # See <code>Numeric#divmod</code>.
  # 
  # 
  def divmod(numeric)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.eql?(obj)   => true or false
  #   
  # 
  # Returns <code>true</code> only if <i>obj</i> is a
  # <code>Float</code> with the same value as <i>flt</i>. Contrast this
  # with <code>Float#==</code>, which performs type conversions.
  #    
  #    1.0.eql?(1)   #=> false
  # 
  # 
  def eql?(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.finite? -> true or false
  #   
  # 
  # Returns <code>true</code> if <i>flt</i> is a valid IEEE floating
  # point number (it is not infinite, and <code>nan?</code> is
  # <code>false</code>).
  #    
  # 
  # 
  def finite?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.floor   => integer
  #   
  # 
  # Returns the largest integer less than or equal to <i>flt</i>.
  #    
  #    1.2.floor      #=> 1
  #    2.0.floor      #=> 2
  #    (-1.2).floor   #=> -2
  #    (-2.0).floor   #=> -2
  # 
  # 
  def floor
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.hash   => integer
  #   
  # 
  # Returns a hash code for this float.
  # 
  # 
  def hash
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Float.induced_from(obj)    =>  float
  #   
  # 
  # Convert <code>obj</code> to a float.
  # 
  # 
  def self.induced_from(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.infinite? -> nil, -1, +1
  #   
  # 
  # Returns <code>nil</code>, -1, or +1 depending on whether <i>flt</i>
  # is finite, -infinity, or +infinity.
  #    
  #    (0.0).infinite?        #=> nil
  #    (-1.0/0.0).infinite?   #=> -1
  #    (+1.0/0.0).infinite?   #=> 1
  # 
  # 
  def infinite?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt % other         => float
  #     flt.modulo(other)   => float
  #   
  # 
  # Return the modulo after division of <code>flt</code> by <code>other</code>.
  #    
  #    6543.21.modulo(137)      #=> 104.21
  #    6543.21.modulo(137.24)   #=> 92.9299999999996
  # 
  # 
  def modulo(other)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.nan? -> true or false
  #   
  # 
  # Returns <code>true</code> if <i>flt</i> is an invalid IEEE floating
  # point number.
  #    
  #    a = -1.0      #=> -1.0
  #    a.nan?        #=> false
  #    a = 0.0/0.0   #=> NaN
  #    a.nan?        #=> true
  # 
  # 
  def nan?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.round   => integer
  #   
  # 
  # Rounds <i>flt</i> to the nearest integer. Equivalent to:
  #    
  #    def round
  #      return (self+0.5).floor if self > 0.0
  #      return (self-0.5).ceil  if self < 0.0
  #      return 0
  #    end
  #    
  #    1.5.round      #=> 2
  #    (-1.5).round   #=> -2
  #    
  # 
  # 
  def round
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.to_f   => flt
  #   
  # 
  # As <code>flt</code> is already a float, returns <i>self</i>.
  # 
  # 
  def to_f
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.to_i       => integer
  #     flt.to_int     => integer
  #     flt.truncate   => integer
  #   
  # 
  # Returns <i>flt</i> truncated to an <code>Integer</code>.
  # 
  # 
  def to_i
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.to_i       => integer
  #     flt.to_int     => integer
  #     flt.truncate   => integer
  #   
  # 
  # Returns <i>flt</i> truncated to an <code>Integer</code>.
  # 
  # 
  def to_int
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.to_s    => string
  #   
  # 
  # Returns a string containing a representation of self. As well as a
  # fixed or exponential form of the number, the call may return
  # ``<code>NaN</code>'', ``<code>Infinity</code>'', and
  # ``<code>-Infinity</code>''.
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.to_i       => integer
  #     flt.to_int     => integer
  #     flt.truncate   => integer
  #   
  # 
  # Returns <i>flt</i> truncated to an <code>Integer</code>.
  # 
  # 
  def truncate
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     flt.zero? -> true or false
  #   
  # 
  # Returns <code>true</code> if <i>flt</i> is 0.0.
  #    
  # 
  # 
  def zero?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
