# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# ConditionVariable objects augment class Mutex. Using condition variables,
# it is possible to suspend while in the middle of a critical section until a
# resource becomes available.
#   
# Example:
#   
#  require 'thread'
#   
#  mutex = Mutex.new
#  resource = ConditionVariable.new
#   
#  a = Thread.new {
#    mutex.synchronize {
#      # Thread 'a' now needs the resource
#      resource.wait(mutex)
#      # 'a' can now have the resource
#    }
#  }
#   
#  b = Thread.new {
#    mutex.synchronize {
#      # Thread 'b' has finished using the resource
#      resource.signal
#    }
#  }
#   
# 
class ConditionVariable
  #      broadcast
  # 
  # Wakes up all threads waiting for this condition.
  #   
  # 
  def broadcast
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # for marshalling mutexes and condvars   
  # 
  def marshal_load(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      signal
  # 
  # Wakes up the first thread in line waiting for this condition.
  #   
  # 
  def signal
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      wait
  # 
  # Releases the lock held in +mutex+ and waits; reacquires the lock on wakeup.
  #   
  # 
  def wait
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
#   
# Mutex implements a simple semaphore that can be used to coordinate access to
# shared data from multiple concurrent threads.
#   
# Example:
#   
#  require 'thread'
#  semaphore = Mutex.new
#   
#  a = Thread.new {
#    semaphore.synchronize {
#      # access shared resource
#    }
#  }
#   
#  b = Thread.new {
#    semaphore.synchronize {
#      # access shared resource
#    }
#  }
#   
# 
class Mutex
  #      exclusive_unlock { ... }
  # 
  # If the mutex is locked, unlocks the mutex, wakes one waiting thread, and
  # yields in a critical section.
  #   
  # 
  def exclusive_unlock
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      lock
  # 
  # Attempts to grab the lock and waits if it isn't available.
  #   
  # 
  def lock
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      locked?
  # 
  # Returns +true+ if this lock is currently held by some thread.
  #   
  # 
  def locked?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # for marshalling mutexes and condvars   
  # 
  def marshal_load(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      synchronize { ... }
  # 
  # Obtains a lock, runs the block, and releases the lock when the block
  # completes.  See the example under Mutex.
  #   
  # 
  def synchronize
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      try_lock
  # 
  # Attempts to obtain the lock and returns immediately. Returns +true+ if the
  # lock was granted.
  #   
  # 
  def try_lock
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # Releases the lock. Returns +nil+ if ref wasn't locked.
  #   
  # 
  def unlock
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
#   
# This class provides a way to synchronize communication between threads.
#   
# Example:
#   
#  require 'thread'
#   
#  queue = Queue.new
#   
#  producer = Thread.new do
#    5.times do |i|
#      sleep rand(i) # simulate expense
#      queue << i
#      puts "#{i} produced"
#    end
#  end
#   
#  consumer = Thread.new do
#    5.times do |i|
#      value = queue.pop
#      sleep rand(i/2) # simulate expense
#      puts "consumed #{value}"
#    end
#  end
#   
#  consumer.join
#   
# 
class Queue
  #      clear
  # 
  # Removes all objects from the queue.
  #   
  # 
  def clear
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      empty?
  # 
  # Returns +true+ if the queue is empty.
  #   
  # 
  def empty?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      length
  # 
  # Returns the length of the queue.
  #   
  # 
  def length
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      num_waiting
  # 
  # Returns the number of threads waiting on the queue.
  #   
  # 
  def num_waiting
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # call_seq: pop(non_block=false)
  #   
  # Retrieves data from the queue.  If the queue is empty, the calling thread is
  # suspended until data is pushed onto the queue.  If +non_block+ is true, the
  # thread isn't suspended, and an exception is raised.
  #   
  # 
  def pop(*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      push(obj)
  # 
  # Pushes +obj+ to the queue.
  #   
  # 
  def  push(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
#   
# This class represents queues of specified size capacity.  The push operation
# may be blocked if the capacity is full.
#   
# See Queue for an example of how a SizedQueue works.
#   
# 
class SizedQueue < Queue
  #      max=(size)
  # 
  # Sets the maximum size of the queue.
  #   
  # 
  def max=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      max
  # 
  # Returns the maximum size of the queue.
  #   
  # 
  def max
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      Mutex.new
  # 
  # Creates a new Mutex
  #   
  # 
  def self.new
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      num_waiting
  # 
  # Returns the number of threads waiting on the queue.
  #   
  # 
  def num_waiting
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # call_seq: pop(non_block=false)
  #   
  # Retrieves data from the queue.  If the queue is empty, the calling thread is
  # suspended until data is pushed onto the queue.  If +non_block+ is true, the
  # thread isn't suspended, and an exception is raised.
  #   
  # 
  def pop(*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #      push(obj)
  # 
  # Pushes +obj+ to the queue.
  #   
  # 
  def  push(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end

class Thread
  #     Thread.exclusive { block }   => obj
  #   
  # 
  # Wraps a block in Thread.critical, restoring the original value
  # upon exit from the critical section, and returns the value of the
  # block.
  # 
  # 
  def self.exclusive
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
