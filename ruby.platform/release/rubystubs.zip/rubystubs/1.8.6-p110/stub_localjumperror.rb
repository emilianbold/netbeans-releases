# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

class LocalJumpError < StandardError
  #   
  # call_seq:
  #  local_jump_error.exit_value  => obj
  #   
  # Returns the exit value associated with this +LocalJumpError+.
  # 
  def exit_value
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     local_jump_error.reason   => symbol
  #   
  # 
  # The reason this block was terminated:
  # :break, :redo, :retry, :next, :return, or :noreason.
  # 
  # 
  def reason
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
