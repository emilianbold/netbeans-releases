# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
# Arrays are ordered, integer-indexed collections of any object. 
# Array indexing starts at 0, as in C or Java.  A negative index is 
# assumed to be relative to the end of the array---that is, an index of -1 
# indicates the last element of the array, -2 is the next to last 
# element in the array, and so on. 
# 
# 
class Array
  include Enumerable
  #     array & other_array
  # 
  # 
  # Set Intersection---Returns a new array
  # containing elements common to the two arrays, with no duplicates.
  #   
  #    [ 1, 1, 3, 5 ] & [ 1, 2, 3 ]   #=> [ 1, 3 ]
  # 
  # 
  # 
  def &
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array * int     ->    an_array
  #     array * str     ->    a_string
  # 
  # 
  # Repetition---With a String argument, equivalent to
  # self.join(str). Otherwise, returns a new array
  # built by concatenating the _int_ copies of _self_.
  #   
  #   
  #    [ 1, 2, 3 ] * 3    #=> [ 1, 2, 3, 1, 2, 3, 1, 2, 3 ]
  #    [ 1, 2, 3 ] * ","  #=> "1,2,3"
  #   
  # 
  # 
  def *
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array + other_array   -> an_array
  # 
  # 
  # Concatenation---Returns a new array built by concatenating the
  # two arrays together to produce a third array.
  # 
  #    [ 1, 2, 3 ] + [ 4, 5 ]    #=> [ 1, 2, 3, 4, 5 ]
  # 
  # 
  def +
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array - other_array    -> an_array
  # 
  # 
  # Array Difference---Returns a new array that is a copy of
  # the original array, removing any items that also appear in
  # other_array. (If you need set-like behavior, see the
  # library class Set.)
  #   
  #    [ 1, 1, 2, 2, 3, 3, 4, 5 ] - [ 1, 2, 4 ]  #=>  [ 3, 3, 5 ]
  # 
  # 
  def -
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array << obj            -> array
  #   
  # 
  # Append---Pushes the given object on to the end of this array. This
  # expression returns the array itself, so several appends
  # may be chained together.
  #   
  #    [ 1, 2 ] << "c" << "d" << [ 3, 4 ]
  #            #=>  [ 1, 2, "c", "d", [ 3, 4 ] ]
  #   
  # 
  # 
  def <<
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array <=> other_array   ->  -1, 0, +1
  # 
  # 
  # Comparison---Returns an integer (-1, 0,
  # or +1) if this array is less than, equal to, or greater than
  # other_array.  Each object in each array is compared
  # (using <=>). If any value isn't
  # equal, then that inequality is the return value. If all the
  # values found are equal, then the return is based on a
  # comparison of the array lengths.  Thus, two arrays are
  # ``equal'' according to <code>Array#<=></code> if and only if they have
  # the same length and the value of each element is equal to the
  # value of the corresponding element in the other array.
  # 
  #    [ "a", "a", "c" ]    <=> [ "a", "b", "c" ]   #=> -1
  #    [ 1, 2, 3, 4, 5, 6 ] <=> [ 1, 2 ]            #=> +1
  #   
  # 
  # 
  def <=>
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array == other_array   ->   bool
  # 
  # 
  # Equality---Two arrays are equal if they contain the same number
  # of elements and if each element is equal to (according to
  # Object.==) the corresponding element in the other array.
  #   
  #    [ "a", "c" ]    == [ "a", "c", 7 ]     #=> false
  #    [ "a", "c", 7 ] == [ "a", "c", 7 ]     #=> true
  #    [ "a", "c", 7 ] == [ "a", "d", "f" ]   #=> false
  #   
  # 
  # 
  def ==
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]         = obj                     ->  obj
  #     array[start, length] = obj or an_array or nil  ->  obj or an_array or nil
  #     array[range]         = obj or an_array or nil  ->  obj or an_array or nil
  # 
  # 
  # Element Assignment---Sets the element at _index_,
  # or replaces a subarray starting at _start_ and
  # continuing for _length_ elements, or replaces a subarray
  # specified by _range_.  If indices are greater than
  # the current capacity of the array, the array grows
  # automatically. A negative indices will count backward
  # from the end of the array. Inserts elements if _length_ is
  # zero. If +nil+ is used in the second and third form,
  # deletes elements from _self_. An +IndexError+ is raised if a
  # negative index points past the beginning of the array. See also
  # <code>Array#push</code>, and <code>Array#unshift</code>.
  # 
  #    a = Array.new
  #    a[4] = "4";                 #=> [nil, nil, nil, nil, "4"]
  #    a[0, 3] = [ 'a', 'b', 'c' ] #=> ["a", "b", "c", nil, "4"]
  #    a[1..2] = [ 1, 2 ]          #=> ["a", 1, 2, nil, "4"]
  #    a[0, 2] = "?"               #=> ["?", 2, nil, "4"]
  #    a[0..2] = "A"               #=> ["A", "4"]
  #    a[-1]   = "Z"               #=> ["A", "Z"]
  #    a[1..-1] = nil              #=> ["A"]
  # 
  # 
  def []=
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # 
  #   Returns a new array populated with the given objects. 
  #  
  # Array.[]( 1, 'a', /^A/ )
  # Array[ 1, 'a', /^A/ ]
  # [ 1, 'a', /^A/ ]
  #   
  # 
  def self.[](*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]                -> obj      or nil
  #     array[start, length]        -> an_array or nil
  #     array[range]                -> an_array or nil
  #     array.slice(index)          -> obj      or nil
  #     array.slice(start, length)  -> an_array or nil
  #     array.slice(range)          -> an_array or nil
  # 
  # 
  # Element Reference---Returns the element at _index_,
  # or returns a subarray starting at _start_ and
  # continuing for _length_ elements, or returns a subarray
  # specified by _range_.
  # Negative indices count backward from the end of the
  # array (-1 is the last element). Returns nil if the index
  # (or starting index) are out of range.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a[2] +  a[0] + a[1]    #=> "cab"
  #    a[6]                   #=> nil
  #    a[1, 2]                #=> [ "b", "c" ]
  #    a[1..3]                #=> [ "b", "c", "d" ]
  #    a[4..7]                #=> [ "e" ]
  #    a[6..10]               #=> nil
  #    a[-3, 3]               #=> [ "c", "d", "e" ]
  #    # special cases
  #    a[5]                   #=> nil
  #    a[5, 1]                #=> []
  #    a[5..10]               #=> []
  #   
  # 
  # 
  def slice(range)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]                -> obj      or nil
  #     array[start, length]        -> an_array or nil
  #     array[range]                -> an_array or nil
  #     array.slice(index)          -> obj      or nil
  #     array.slice(start, length)  -> an_array or nil
  #     array.slice(range)          -> an_array or nil
  # 
  # 
  # Element Reference---Returns the element at _index_,
  # or returns a subarray starting at _start_ and
  # continuing for _length_ elements, or returns a subarray
  # specified by _range_.
  # Negative indices count backward from the end of the
  # array (-1 is the last element). Returns nil if the index
  # (or starting index) are out of range.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a[2] +  a[0] + a[1]    #=> "cab"
  #    a[6]                   #=> nil
  #    a[1, 2]                #=> [ "b", "c" ]
  #    a[1..3]                #=> [ "b", "c", "d" ]
  #    a[4..7]                #=> [ "e" ]
  #    a[6..10]               #=> nil
  #    a[-3, 3]               #=> [ "c", "d", "e" ]
  #    # special cases
  #    a[5]                   #=> nil
  #    a[5, 1]                #=> []
  #    a[5..10]               #=> []
  #   
  # 
  # 
  def slice(start, length)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]                -> obj      or nil
  #     array[start, length]        -> an_array or nil
  #     array[range]                -> an_array or nil
  #     array.slice(index)          -> obj      or nil
  #     array.slice(start, length)  -> an_array or nil
  #     array.slice(range)          -> an_array or nil
  # 
  # 
  # Element Reference---Returns the element at _index_,
  # or returns a subarray starting at _start_ and
  # continuing for _length_ elements, or returns a subarray
  # specified by _range_.
  # Negative indices count backward from the end of the
  # array (-1 is the last element). Returns nil if the index
  # (or starting index) are out of range.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a[2] +  a[0] + a[1]    #=> "cab"
  #    a[6]                   #=> nil
  #    a[1, 2]                #=> [ "b", "c" ]
  #    a[1..3]                #=> [ "b", "c", "d" ]
  #    a[4..7]                #=> [ "e" ]
  #    a[6..10]               #=> nil
  #    a[-3, 3]               #=> [ "c", "d", "e" ]
  #    # special cases
  #    a[5]                   #=> nil
  #    a[5, 1]                #=> []
  #    a[5..10]               #=> []
  #   
  # 
  # 
  def slice(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array | other_array     ->  an_array
  # 
  # 
  # Set Union---Returns a new array by joining this array with
  # other_array, removing duplicates.
  #   
  #    [ "a", "b", "c" ] | [ "c", "d", "a" ]
  #           #=> [ "a", "b", "c", "d" ]
  # 
  # 
  def |
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.assoc(obj)   ->  an_array  or  nil
  # 
  # 
  # Searches through an array whose elements are also arrays
  # comparing _obj_ with the first element of each contained array
  # using obj.==.
  # Returns the first contained array that matches (that
  # is, the first associated array),
  # or +nil+ if no match is found.
  # See also <code>Array#rassoc</code>.
  #   
  #    s1 = [ "colors", "red", "blue", "green" ]
  #    s2 = [ "letters", "a", "b", "c" ]
  #    s3 = "foo"
  #    a  = [ s1, s2, s3 ]
  #    a.assoc("letters")  #=> [ "letters", "a", "b", "c" ]
  #    a.assoc("foo")      #=> nil
  # 
  # 
  def assoc(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.at(index)   ->   obj  or nil
  # 
  # 
  # Returns the element at _index_. A
  # negative index counts from the end of _self_.  Returns +nil+
  # if the index is out of range. See also <code>Array#[]</code>.
  # (<code>Array#at</code> is slightly faster than <code>Array#[]</code>,
  # as it does not accept ranges and so on.)
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a.at(0)     #=> "a"
  #    a.at(-1)    #=> "e"
  # 
  # 
  def at(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.clear    ->  array
  # 
  # 
  # Removes all elements from _self_.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a.clear    #=> [ ]
  # 
  # 
  def clear
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.collect! {|item| block }   ->   array
  #     array.map!     {|item| block }   ->   array
  # 
  # 
  # Invokes the block once for each element of _self_, replacing the
  # element with the value returned by _block_.
  # See also <code>Enumerable#collect</code>.
  #  
  #    a = [ "a", "b", "c", "d" ]
  #    a.collect! {|x| x + "!" }
  #    a             #=>  [ "a!", "b!", "c!", "d!" ]
  # 
  # 
  def collect!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.collect {|item| block }  -> an_array
  #     array.map     {|item| block }  -> an_array
  #   
  # 
  # Invokes <i>block</i> once for each element of <i>self</i>. Creates a 
  # new array containing the values returned by the block.
  # See also <code>Enumerable#collect</code>.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.collect {|x| x + "!" }   #=> ["a!", "b!", "c!", "d!"]
  #    a                          #=> ["a", "b", "c", "d"]
  # 
  # 
  def collect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.compact!    ->   array  or  nil
  # 
  # 
  # Removes +nil+ elements from array.
  # Returns +nil+ if no changes were made.
  #   
  #    [ "a", nil, "b", nil, "c" ].compact! #=> [ "a", "b", "c" ]
  #    [ "a", "b", "c" ].compact!           #=> nil
  # 
  # 
  def compact!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.compact     ->  an_array
  #   
  # 
  # Returns a copy of _self_ with all +nil+ elements removed.
  #   
  #    [ "a", nil, "b", nil, "c", nil ].compact
  #                      #=> [ "a", "b", "c" ]
  # 
  # 
  def compact
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.concat(other_array)   ->  array
  # 
  # 
  # Appends the elements in other_array to _self_.
  # 
  #    [ "a", "b" ].concat( ["c", "d"] ) #=> [ "a", "b", "c", "d" ]
  # 
  # 
  # 
  def concat(other_array)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.delete(obj)            -> obj or nil 
  #     array.delete(obj) { block }  -> obj or nil
  #   
  # 
  # Deletes items from <i>self</i> that are equal to <i>obj</i>. If
  # the item is not found, returns <code>nil</code>. If the optional
  # code block is given, returns the result of <i>block</i> if the item
  # is not found.
  #    
  #    a = [ "a", "b", "b", "b", "c" ]
  #    a.delete("b")                   #=> "b"
  #    a                               #=> ["a", "c"]
  #    a.delete("z")                   #=> nil
  #    a.delete("z") { "not found" }   #=> "not found"
  # 
  # 
  def delete(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.delete_at(index)  -> obj or nil
  #   
  # 
  # Deletes the element at the specified index, returning that element,
  # or <code>nil</code> if the index is out of range. See also
  # <code>Array#slice!</code>.
  #    
  #    a = %w( ant bat cat dog )
  #    a.delete_at(2)    #=> "cat"
  #    a                 #=> ["ant", "bat", "dog"]
  #    a.delete_at(99)   #=> nil
  # 
  # 
  def delete_at(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.delete_if {|item| block }  -> array
  #   
  # 
  # Deletes every element of <i>self</i> for which <i>block</i> evaluates
  # to <code>true</code>.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.delete_if {|x| x >= "b" }   #=> ["a"]
  # 
  # 
  def delete_if
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.each {|item| block }   ->   array
  #   
  # 
  # Calls <i>block</i> once for each element in <i>self</i>, passing that
  # element as a parameter.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.each {|x| print x, " -- " }
  #    
  # produces:
  #    
  #    a -- b -- c --
  # 
  # 
  def each
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.each_index {|index| block }  ->  array
  #   
  # 
  # Same as <code>Array#each</code>, but passes the index of the element
  # instead of the element itself.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.each_index {|x| print x, " -- " }
  #    
  # produces:
  #    
  #    0 -- 1 -- 2 --
  # 
  # 
  def each_index
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.empty?   -> true or false
  #   
  # 
  # Returns <code>true</code> if <i>self</i> array contains no elements.
  #    
  #    [].empty?   #=> true
  # 
  # 
  def empty?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.eql?(other)  -> true or false
  #   
  # 
  # Returns <code>true</code> if _array_ and _other_ are the same object,
  # or are both arrays with the same content.
  # 
  # 
  def eql?(other)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fetch(index)                    -> obj
  #     array.fetch(index, default )          -> obj
  #     array.fetch(index) {|index| block }   -> obj
  #   
  # 
  # Tries to return the element at position <i>index</i>. If the index
  # lies outside the array, the first form throws an
  # <code>IndexError</code> exception, the second form returns
  # <i>default</i>, and the third form returns the value of invoking
  # the block, passing in the index. Negative values of <i>index</i>
  # count from the end of the array.
  #    
  #    a = [ 11, 22, 33, 44 ]
  #    a.fetch(1)               #=> 22
  #    a.fetch(-1)              #=> 44
  #    a.fetch(4, 'cat')        #=> "cat"
  #    a.fetch(4) { |i| i*i }   #=> 16
  # 
  # 
  def fetch(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fetch(index)                    -> obj
  #     array.fetch(index, default )          -> obj
  #     array.fetch(index) {|index| block }   -> obj
  #   
  # 
  # Tries to return the element at position <i>index</i>. If the index
  # lies outside the array, the first form throws an
  # <code>IndexError</code> exception, the second form returns
  # <i>default</i>, and the third form returns the value of invoking
  # the block, passing in the index. Negative values of <i>index</i>
  # count from the end of the array.
  #    
  #    a = [ 11, 22, 33, 44 ]
  #    a.fetch(1)               #=> 22
  #    a.fetch(-1)              #=> 44
  #    a.fetch(4, 'cat')        #=> "cat"
  #    a.fetch(4) { |i| i*i }   #=> 16
  # 
  # 
  def fetch(index, default )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fill(obj)                                -> array
  #     array.fill(obj, start [, length])              -> array
  #     array.fill(obj, range )                        -> array
  #     array.fill {|index| block }                    -> array
  #     array.fill(start [, length] ) {|index| block } -> array
  #     array.fill(range) {|index| block }             -> array
  #   
  # 
  # The first three forms set the selected elements of <i>self</i> (which
  # may be the entire array) to <i>obj</i>. A <i>start</i> of
  # <code>nil</code> is equivalent to zero. A <i>length</i> of
  # <code>nil</code> is equivalent to <i>self.length</i>. The last three
  # forms fill the array with the value of the block. The block is
  # passed the absolute index of each element to be filled.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.fill("x")              #=> ["x", "x", "x", "x"]
  #    a.fill("z", 2, 2)        #=> ["x", "x", "z", "z"]
  #    a.fill("y", 0..1)        #=> ["y", "y", "z", "z"]
  #    a.fill {|i| i*i}         #=> [0, 1, 4, 9]
  #    a.fill(-2) {|i| i*i*i}   #=> [0, 1, 8, 27]
  # 
  # 
  def fill(start, length )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fill(obj)                                -> array
  #     array.fill(obj, start [, length])              -> array
  #     array.fill(obj, range )                        -> array
  #     array.fill {|index| block }                    -> array
  #     array.fill(start [, length] ) {|index| block } -> array
  #     array.fill(range) {|index| block }             -> array
  #   
  # 
  # The first three forms set the selected elements of <i>self</i> (which
  # may be the entire array) to <i>obj</i>. A <i>start</i> of
  # <code>nil</code> is equivalent to zero. A <i>length</i> of
  # <code>nil</code> is equivalent to <i>self.length</i>. The last three
  # forms fill the array with the value of the block. The block is
  # passed the absolute index of each element to be filled.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.fill("x")              #=> ["x", "x", "x", "x"]
  #    a.fill("z", 2, 2)        #=> ["x", "x", "z", "z"]
  #    a.fill("y", 0..1)        #=> ["y", "y", "z", "z"]
  #    a.fill {|i| i*i}         #=> [0, 1, 4, 9]
  #    a.fill(-2) {|i| i*i*i}   #=> [0, 1, 8, 27]
  # 
  # 
  def fill(obj, range )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fill(obj)                                -> array
  #     array.fill(obj, start [, length])              -> array
  #     array.fill(obj, range )                        -> array
  #     array.fill {|index| block }                    -> array
  #     array.fill(start [, length] ) {|index| block } -> array
  #     array.fill(range) {|index| block }             -> array
  #   
  # 
  # The first three forms set the selected elements of <i>self</i> (which
  # may be the entire array) to <i>obj</i>. A <i>start</i> of
  # <code>nil</code> is equivalent to zero. A <i>length</i> of
  # <code>nil</code> is equivalent to <i>self.length</i>. The last three
  # forms fill the array with the value of the block. The block is
  # passed the absolute index of each element to be filled.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.fill("x")              #=> ["x", "x", "x", "x"]
  #    a.fill("z", 2, 2)        #=> ["x", "x", "z", "z"]
  #    a.fill("y", 0..1)        #=> ["y", "y", "z", "z"]
  #    a.fill {|i| i*i}         #=> [0, 1, 4, 9]
  #    a.fill(-2) {|i| i*i*i}   #=> [0, 1, 8, 27]
  # 
  # 
  def fill(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fill(obj)                                -> array
  #     array.fill(obj, start [, length])              -> array
  #     array.fill(obj, range )                        -> array
  #     array.fill {|index| block }                    -> array
  #     array.fill(start [, length] ) {|index| block } -> array
  #     array.fill(range) {|index| block }             -> array
  #   
  # 
  # The first three forms set the selected elements of <i>self</i> (which
  # may be the entire array) to <i>obj</i>. A <i>start</i> of
  # <code>nil</code> is equivalent to zero. A <i>length</i> of
  # <code>nil</code> is equivalent to <i>self.length</i>. The last three
  # forms fill the array with the value of the block. The block is
  # passed the absolute index of each element to be filled.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.fill("x")              #=> ["x", "x", "x", "x"]
  #    a.fill("z", 2, 2)        #=> ["x", "x", "z", "z"]
  #    a.fill("y", 0..1)        #=> ["y", "y", "z", "z"]
  #    a.fill {|i| i*i}         #=> [0, 1, 4, 9]
  #    a.fill(-2) {|i| i*i*i}   #=> [0, 1, 8, 27]
  # 
  # 
  def fill(obj, start, length)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.fill(obj)                                -> array
  #     array.fill(obj, start [, length])              -> array
  #     array.fill(obj, range )                        -> array
  #     array.fill {|index| block }                    -> array
  #     array.fill(start [, length] ) {|index| block } -> array
  #     array.fill(range) {|index| block }             -> array
  #   
  # 
  # The first three forms set the selected elements of <i>self</i> (which
  # may be the entire array) to <i>obj</i>. A <i>start</i> of
  # <code>nil</code> is equivalent to zero. A <i>length</i> of
  # <code>nil</code> is equivalent to <i>self.length</i>. The last three
  # forms fill the array with the value of the block. The block is
  # passed the absolute index of each element to be filled.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.fill("x")              #=> ["x", "x", "x", "x"]
  #    a.fill("z", 2, 2)        #=> ["x", "x", "z", "z"]
  #    a.fill("y", 0..1)        #=> ["y", "y", "z", "z"]
  #    a.fill {|i| i*i}         #=> [0, 1, 4, 9]
  #    a.fill(-2) {|i| i*i*i}   #=> [0, 1, 8, 27]
  # 
  # 
  def fill(range)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.first   ->   obj or nil
  #     array.first(n) -> an_array
  #   
  # 
  # Returns the first element, or the first +n+ elements, of the array.
  # If the array is empty, the first form returns <code>nil</code>, and the
  # second form returns an empty array.
  #   
  #    a = [ "q", "r", "s", "t" ]
  #    a.first    #=> "q"
  #    a.first(1) #=> ["q"]
  #    a.first(3) #=> ["q", "r", "s"]
  # 
  # 
  def first(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.flatten! -> array or nil
  #   
  # 
  # Flattens _self_ in place.
  # Returns <code>nil</code> if no modifications were made (i.e.,
  # <i>array</i> contains no subarrays.)
  #    
  #    a = [ 1, 2, [3, [4, 5] ] ]
  #    a.flatten!   #=> [1, 2, 3, 4, 5]
  #    a.flatten!   #=> nil
  #    a            #=> [1, 2, 3, 4, 5]
  # 
  # 
  def flatten!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.flatten -> an_array
  #   
  # 
  # Returns a new array that is a one-dimensional flattening of this
  # array (recursively). That is, for every element that is an array,
  # extract its elements into the new array.
  #    
  #    s = [ 1, 2, 3 ]           #=> [1, 2, 3]
  #    t = [ 4, 5, 6, [7, 8] ]   #=> [4, 5, 6, [7, 8]]
  #    a = [ s, t, 9, 10 ]       #=> [[1, 2, 3], [4, 5, 6, [7, 8]], 9, 10]
  #    a.flatten                 #=> [1, 2, 3, 4, 5, 6, 7, 8, 9, 10
  # 
  # 
  def flatten
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.frozen?  -> true or false
  #   
  # 
  # Return <code>true</code> if this array is frozen (or temporarily frozen
  # while being sorted).
  # 
  # 
  def frozen?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.hash   -> fixnum
  #   
  # 
  # Compute a hash-code for this array. Two arrays with the same content
  # will have the same hash code (and will compare using <code>eql?</code>).
  # 
  # 
  def hash
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.include?(obj)   -> true or false
  #   
  # 
  # Returns <code>true</code> if the given object is present in
  # <i>self</i> (that is, if any object <code>==</code> <i>anObject</i>),
  # <code>false</code> otherwise.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.include?("b")   #=> true
  #    a.include?("z")   #=> false
  # 
  # 
  def include?(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.index(obj)   ->  int or nil
  #   
  # 
  # Returns the index of the first object in <i>self</i> such that is 
  # <code>==</code> to <i>obj</i>. Returns <code>nil</code> if
  # no match is found.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.index("b")   #=> 1
  #    a.index("z")   #=> nil
  # 
  # 
  def index(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.indexes( i1, i2, ... iN )   -> an_array
  #     array.indices( i1, i2, ... iN )   -> an_array
  #   
  # 
  # Deprecated; use <code>Array#values_at</code>.
  # 
  # 
  def indices( i1, i2, iN )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.indexes( i1, i2, ... iN )   -> an_array
  #     array.indices( i1, i2, ... iN )   -> an_array
  #   
  # 
  # Deprecated; use <code>Array#values_at</code>.
  # 
  # 
  def indexes( i1, i2, iN )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.indexes( i1, i2, ... iN )   -> an_array
  #     array.indices( i1, i2, ... iN )   -> an_array
  #   
  # 
  # Deprecated; use <code>Array#values_at</code>.
  # 
  # 
  def indices( i1, i2, iN )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.indexes( i1, i2, ... iN )   -> an_array
  #     array.indices( i1, i2, ... iN )   -> an_array
  #   
  # 
  # Deprecated; use <code>Array#values_at</code>.
  # 
  # 
  def indexes( i1, i2, iN )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.replace(other_array)  -> array
  #   
  # 
  # Replaces the contents of <i>self</i> with the contents of
  # <i>other_array</i>, truncating or expanding if necessary.
  #    
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a.replace([ "x", "y", "z" ])   #=> ["x", "y", "z"]
  #    a                              #=> ["x", "y", "z"]
  # 
  # 
  def replace(other_array)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.insert(index, obj...)  -> array
  #   
  # 
  # Inserts the given values before the element with the given index
  # (which may be negative).
  #    
  #    a = %w{ a b c d }
  #    a.insert(2, 99)         #=> ["a", "b", 99, "c", "d"]
  #    a.insert(-2, 1, 2, 3)   #=> ["a", "b", 99, "c", 1, 2, 3, "d"]
  # 
  # 
  def insert(index, obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.inspect  -> string
  #   
  # 
  # Create a printable version of <i>array</i>.
  # 
  # 
  def inspect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.join(sep=$,)    -> str
  #   
  # 
  # Returns a string created by converting each element of the array to
  # a string, separated by <i>sep</i>.
  #    
  #    [ "a", "b", "c" ].join        #=> "abc"
  #    [ "a", "b", "c" ].join("-")   #=> "a-b-c"
  # 
  # 
  def join(sep="$,")
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.last     ->  obj or nil
  #     array.last(n)  ->  an_array
  #   
  # 
  # Returns the last element(s) of <i>self</i>. If the array is empty,
  # the first form returns <code>nil</code>.
  #    
  #    [ "w", "x", "y", "z" ].last   #=> "z"
  # 
  # 
  def last(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.length -> int
  #   
  # 
  # Returns the number of elements in <i>self</i>. May be zero.
  #    
  #    [ 1, 2, 3, 4, 5 ].length   #=> 5
  # 
  # 
  def length
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.collect! {|item| block }   ->   array
  #     array.map!     {|item| block }   ->   array
  # 
  # 
  # Invokes the block once for each element of _self_, replacing the
  # element with the value returned by _block_.
  # See also <code>Enumerable#collect</code>.
  #  
  #    a = [ "a", "b", "c", "d" ]
  #    a.collect! {|x| x + "!" }
  #    a             #=>  [ "a!", "b!", "c!", "d!" ]
  # 
  # 
  def map!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.collect {|item| block }  -> an_array
  #     array.map     {|item| block }  -> an_array
  #   
  # 
  # Invokes <i>block</i> once for each element of <i>self</i>. Creates a 
  # new array containing the values returned by the block.
  # See also <code>Enumerable#collect</code>.
  #    
  #    a = [ "a", "b", "c", "d" ]
  #    a.collect {|x| x + "!" }   #=> ["a!", "b!", "c!", "d!"]
  #    a                          #=> ["a", "b", "c", "d"]
  # 
  # 
  def map
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Array.new(size=0, obj=nil)
  #     Array.new(array)
  #     Array.new(size) {|index| block }
  #   
  # 
  # Returns a new array. In the first form, the new array is
  # empty. In the second it is created with _size_ copies of _obj_
  # (that is, _size_ references to the same
  # _obj_). The third form creates a copy of the array
  # passed as a parameter (the array is generated by calling
  # to_ary  on the parameter). In the last form, an array
  # of the given size is created. Each element in this array is
  # calculated by passing the element's index to the given block and
  # storing the return value.
  #   
  #    Array.new
  #    Array.new(2)
  #    Array.new(5, "A")
  # 
  #    # only one copy of the object is created
  #    a = Array.new(2, Hash.new)
  #    a[0]['cat'] = 'feline'
  #    a
  #    a[1]['cat'] = 'Felix'
  #    a
  # 
  #    # here multiple copies are created
  #    a = Array.new(2) { Hash.new }
  #    a[0]['cat'] = 'feline'
  #    a
  # 
  #    squares = Array.new(5) {|i| i*i}
  #    squares
  # 
  #    copy = Array.new(squares)
  # 
  # 
  def self.new(array)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Array.new(size=0, obj=nil)
  #     Array.new(array)
  #     Array.new(size) {|index| block }
  #   
  # 
  # Returns a new array. In the first form, the new array is
  # empty. In the second it is created with _size_ copies of _obj_
  # (that is, _size_ references to the same
  # _obj_). The third form creates a copy of the array
  # passed as a parameter (the array is generated by calling
  # to_ary  on the parameter). In the last form, an array
  # of the given size is created. Each element in this array is
  # calculated by passing the element's index to the given block and
  # storing the return value.
  #   
  #    Array.new
  #    Array.new(2)
  #    Array.new(5, "A")
  # 
  #    # only one copy of the object is created
  #    a = Array.new(2, Hash.new)
  #    a[0]['cat'] = 'feline'
  #    a
  #    a[1]['cat'] = 'Felix'
  #    a
  # 
  #    # here multiple copies are created
  #    a = Array.new(2) { Hash.new }
  #    a[0]['cat'] = 'feline'
  #    a
  # 
  #    squares = Array.new(5) {|i| i*i}
  #    squares
  # 
  #    copy = Array.new(squares)
  # 
  # 
  def self.new(size)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Array.new(size=0, obj=nil)
  #     Array.new(array)
  #     Array.new(size) {|index| block }
  #   
  # 
  # Returns a new array. In the first form, the new array is
  # empty. In the second it is created with _size_ copies of _obj_
  # (that is, _size_ references to the same
  # _obj_). The third form creates a copy of the array
  # passed as a parameter (the array is generated by calling
  # to_ary  on the parameter). In the last form, an array
  # of the given size is created. Each element in this array is
  # calculated by passing the element's index to the given block and
  # storing the return value.
  #   
  #    Array.new
  #    Array.new(2)
  #    Array.new(5, "A")
  # 
  #    # only one copy of the object is created
  #    a = Array.new(2, Hash.new)
  #    a[0]['cat'] = 'feline'
  #    a
  #    a[1]['cat'] = 'Felix'
  #    a
  # 
  #    # here multiple copies are created
  #    a = Array.new(2) { Hash.new }
  #    a[0]['cat'] = 'feline'
  #    a
  # 
  #    squares = Array.new(5) {|i| i*i}
  #    squares
  # 
  #    copy = Array.new(squares)
  # 
  # 
  def self.new(size=0, obj=nil)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.nitems -> int
  #   
  # 
  # Returns the number of non-<code>nil</code> elements in _self_.
  # May be zero.
  #    
  #    [ 1, nil, 3, nil, 5 ].nitems   #=> 3
  # 
  # 
  def nitems
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     arr.pack ( aTemplateString ) -> aBinaryString
  #   
  # 
  # Packs the contents of <i>arr</i> into a binary sequence according to
  # the directives in <i>aTemplateString</i> (see the table below)
  # Directives ``A,'' ``a,'' and ``Z'' may be followed by a count,
  # which gives the width of the resulting field. The remaining
  # directives also may take a count, indicating the number of array
  # elements to convert. If the count is an asterisk
  # (``<code>*</code>''), all remaining array elements will be
  # converted. Any of the directives ``<code>sSiIlL</code>'' may be
  # followed by an underscore (``<code>_</code>'') to use the underlying
  # platform's native size for the specified type; otherwise, they use a
  # platform-independent size. Spaces are ignored in the template
  # string. See also <code>String#unpack</code>.
  #    
  #    a = [ "a", "b", "c" ]
  #    n = [ 65, 66, 67 ]
  #    a.pack("A3A3A3")   #=> "a  b  c  "
  #    a.pack("a3a3a3")   #=> "a\000\000b\000\000c\000\000"
  #    n.pack("ccc")      #=> "ABC"
  #    
  # Directives for +pack+.
  #   
  #  Directive    Meaning
  #  ---------------------------------------------------------------
  #      @     |  Moves to absolute position
  #      A     |  ASCII string (space padded, count is width)
  #      a     |  ASCII string (null padded, count is width)
  #      B     |  Bit string (descending bit order)
  #      b     |  Bit string (ascending bit order)
  #      C     |  Unsigned char
  #      c     |  Char
  #      D, d  |  Double-precision float, native format
  #      E     |  Double-precision float, little-endian byte order
  #      e     |  Single-precision float, little-endian byte order
  #      F, f  |  Single-precision float, native format
  #      G     |  Double-precision float, network (big-endian) byte order
  #      g     |  Single-precision float, network (big-endian) byte order
  #      H     |  Hex string (high nibble first)
  #      h     |  Hex string (low nibble first)
  #      I     |  Unsigned integer
  #      i     |  Integer
  #      L     |  Unsigned long
  #      l     |  Long
  #      M     |  Quoted printable, MIME encoding (see RFC2045)
  #      m     |  Base64 encoded string
  #      N     |  Long, network (big-endian) byte order
  #      n     |  Short, network (big-endian) byte-order
  #      P     |  Pointer to a structure (fixed-length string)
  #      p     |  Pointer to a null-terminated string
  #      Q, q  |  64-bit number
  #      S     |  Unsigned short
  #      s     |  Short
  #      U     |  UTF-8
  #      u     |  UU-encoded string
  #      V     |  Long, little-endian byte order
  #      v     |  Short, little-endian byte order
  #      w     |  BER-compressed integer\fnm
  #      X     |  Back up a byte
  #      x     |  Null byte
  #      Z     |  Same as ``a'', except that null is added with *
  # 
  # 
  def pack ( aTemplateString )
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.pop  -> obj or nil
  #   
  # 
  # Removes the last element from <i>self</i> and returns it, or
  # <code>nil</code> if the array is empty.
  #    
  #    a = [ "a", "m", "z" ]
  #    a.pop   #=> "z"
  #    a       #=> ["a", "m"]
  # 
  # 
  def pop
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.push(obj, ... )   -> array
  # 
  # 
  # Append---Pushes the given object(s) on to the end of this array. This
  # expression returns the array itself, so several appends
  # may be chained together.
  #   
  #    a = [ "a", "b", "c" ]
  #    a.push("d", "e", "f")  
  #            #=> ["a", "b", "c", "d", "e", "f"]
  # 
  # 
  def push(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.rassoc(key) -> an_array or nil
  #   
  # 
  # Searches through the array whose elements are also arrays. Compares
  # <em>key</em> with the second element of each contained array using
  # <code>==</code>. Returns the first contained array that matches. See
  # also <code>Array#assoc</code>.
  #    
  #    a = [ [ 1, "one"], [2, "two"], [3, "three"], ["ii", "two"] ]
  #    a.rassoc("two")    #=> [2, "two"]
  #    a.rassoc("four")   #=> nil
  # 
  # 
  def rassoc(key)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.reject! {|item| block }  -> array or nil
  #   
  # 
  # Equivalent to <code>Array#delete_if</code>, deleting elements from
  # _self_ for which the block evaluates to true, but returns
  # <code>nil</code> if no changes were made. Also see
  # <code>Enumerable#reject</code>.
  # 
  # 
  def reject!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.reject {|item| block }  -> an_array
  #   
  # 
  # Returns a new array containing the items in _self_
  # for which the block is not true.
  # 
  # 
  def reject
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.replace(other_array)  -> array
  #   
  # 
  # Replaces the contents of <i>self</i> with the contents of
  # <i>other_array</i>, truncating or expanding if necessary.
  #    
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a.replace([ "x", "y", "z" ])   #=> ["x", "y", "z"]
  #    a                              #=> ["x", "y", "z"]
  # 
  # 
  def replace(other_array)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.reverse!   -> array 
  #   
  # 
  # Reverses _self_ in place.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.reverse!       #=> ["c", "b", "a"]
  #    a                #=> ["c", "b", "a"]
  # 
  # 
  def reverse!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.reverse -> an_array
  #   
  # 
  # Returns a new array containing <i>self</i>'s elements in reverse order.
  #    
  #    [ "a", "b", "c" ].reverse   #=> ["c", "b", "a"]
  #    [ 1 ].reverse               #=> [1]
  # 
  # 
  def reverse
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.reverse_each {|item| block } 
  #   
  # 
  # Same as <code>Array#each</code>, but traverses <i>self</i> in reverse
  # order.
  #    
  #    a = [ "a", "b", "c" ]
  #    a.reverse_each {|x| print x, " " }
  #    
  # produces:
  #    
  #    c b a
  # 
  # 
  def reverse_each
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.rindex(obj)    ->  int or nil
  #   
  # 
  # Returns the index of the last object in <i>array</i> 
  # <code>==</code> to <i>obj</i>. Returns <code>nil</code> if
  # no match is found.
  #    
  #    a = [ "a", "b", "b", "b", "c" ]
  #    a.rindex("b")   #=> 3
  #    a.rindex("z")   #=> nil
  # 
  # 
  def rindex(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.select {|item| block } -> an_array
  #   
  # 
  # Invokes the block passing in successive elements from <i>array</i>,
  # returning an array containing those elements for which the block
  # returns a true value (equivalent to <code>Enumerable#select</code>).
  #    
  #    a = %w{ a b c d e f }
  #    a.select {|v| v =~ /[aeiou]/}   #=> ["a", "e"]
  # 
  # 
  def select
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.shift   ->   obj or nil
  #   
  # 
  # Returns the first element of <i>self</i> and removes it (shifting all
  # other elements down by one). Returns <code>nil</code> if the array
  # is empty.
  #    
  #    args = [ "-m", "-q", "filename" ]
  #    args.shift   #=> "-m"
  #    args         #=> ["-q", "filename"]
  # 
  # 
  def shift
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # Alias for #length
  def size
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.slice!(index)         -> obj or nil
  #     array.slice!(start, length) -> sub_array or nil
  #     array.slice!(range)         -> sub_array or nil 
  #   
  # 
  # Deletes the element(s) given by an index (optionally with a length)
  # or by a range. Returns the deleted object, subarray, or
  # <code>nil</code> if the index is out of range. Equivalent to:
  #    
  #    def slice!(*args)
  #      result = self[*args]
  #      self[*args] = nil
  #      result
  #    end
  #    
  #    a = [ "a", "b", "c" ]
  #    a.slice!(1)     #=> "b"
  #    a               #=> ["a", "c"]
  #    a.slice!(-1)    #=> "c"
  #    a               #=> ["a"]
  #    a.slice!(100)   #=> nil
  #    a               #=> ["a"]
  # 
  # 
  def slice!(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.slice!(index)         -> obj or nil
  #     array.slice!(start, length) -> sub_array or nil
  #     array.slice!(range)         -> sub_array or nil 
  #   
  # 
  # Deletes the element(s) given by an index (optionally with a length)
  # or by a range. Returns the deleted object, subarray, or
  # <code>nil</code> if the index is out of range. Equivalent to:
  #    
  #    def slice!(*args)
  #      result = self[*args]
  #      self[*args] = nil
  #      result
  #    end
  #    
  #    a = [ "a", "b", "c" ]
  #    a.slice!(1)     #=> "b"
  #    a               #=> ["a", "c"]
  #    a.slice!(-1)    #=> "c"
  #    a               #=> ["a"]
  #    a.slice!(100)   #=> nil
  #    a               #=> ["a"]
  # 
  # 
  def slice!(range)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.slice!(index)         -> obj or nil
  #     array.slice!(start, length) -> sub_array or nil
  #     array.slice!(range)         -> sub_array or nil 
  #   
  # 
  # Deletes the element(s) given by an index (optionally with a length)
  # or by a range. Returns the deleted object, subarray, or
  # <code>nil</code> if the index is out of range. Equivalent to:
  #    
  #    def slice!(*args)
  #      result = self[*args]
  #      self[*args] = nil
  #      result
  #    end
  #    
  #    a = [ "a", "b", "c" ]
  #    a.slice!(1)     #=> "b"
  #    a               #=> ["a", "c"]
  #    a.slice!(-1)    #=> "c"
  #    a               #=> ["a"]
  #    a.slice!(100)   #=> nil
  #    a               #=> ["a"]
  # 
  # 
  def slice!(start, length)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]                -> obj      or nil
  #     array[start, length]        -> an_array or nil
  #     array[range]                -> an_array or nil
  #     array.slice(index)          -> obj      or nil
  #     array.slice(start, length)  -> an_array or nil
  #     array.slice(range)          -> an_array or nil
  # 
  # 
  # Element Reference---Returns the element at _index_,
  # or returns a subarray starting at _start_ and
  # continuing for _length_ elements, or returns a subarray
  # specified by _range_.
  # Negative indices count backward from the end of the
  # array (-1 is the last element). Returns nil if the index
  # (or starting index) are out of range.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a[2] +  a[0] + a[1]    #=> "cab"
  #    a[6]                   #=> nil
  #    a[1, 2]                #=> [ "b", "c" ]
  #    a[1..3]                #=> [ "b", "c", "d" ]
  #    a[4..7]                #=> [ "e" ]
  #    a[6..10]               #=> nil
  #    a[-3, 3]               #=> [ "c", "d", "e" ]
  #    # special cases
  #    a[5]                   #=> nil
  #    a[5, 1]                #=> []
  #    a[5..10]               #=> []
  #   
  # 
  # 
  def slice(range)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]                -> obj      or nil
  #     array[start, length]        -> an_array or nil
  #     array[range]                -> an_array or nil
  #     array.slice(index)          -> obj      or nil
  #     array.slice(start, length)  -> an_array or nil
  #     array.slice(range)          -> an_array or nil
  # 
  # 
  # Element Reference---Returns the element at _index_,
  # or returns a subarray starting at _start_ and
  # continuing for _length_ elements, or returns a subarray
  # specified by _range_.
  # Negative indices count backward from the end of the
  # array (-1 is the last element). Returns nil if the index
  # (or starting index) are out of range.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a[2] +  a[0] + a[1]    #=> "cab"
  #    a[6]                   #=> nil
  #    a[1, 2]                #=> [ "b", "c" ]
  #    a[1..3]                #=> [ "b", "c", "d" ]
  #    a[4..7]                #=> [ "e" ]
  #    a[6..10]               #=> nil
  #    a[-3, 3]               #=> [ "c", "d", "e" ]
  #    # special cases
  #    a[5]                   #=> nil
  #    a[5, 1]                #=> []
  #    a[5..10]               #=> []
  #   
  # 
  # 
  def slice(start, length)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array[index]                -> obj      or nil
  #     array[start, length]        -> an_array or nil
  #     array[range]                -> an_array or nil
  #     array.slice(index)          -> obj      or nil
  #     array.slice(start, length)  -> an_array or nil
  #     array.slice(range)          -> an_array or nil
  # 
  # 
  # Element Reference---Returns the element at _index_,
  # or returns a subarray starting at _start_ and
  # continuing for _length_ elements, or returns a subarray
  # specified by _range_.
  # Negative indices count backward from the end of the
  # array (-1 is the last element). Returns nil if the index
  # (or starting index) are out of range.
  #   
  #    a = [ "a", "b", "c", "d", "e" ]
  #    a[2] +  a[0] + a[1]    #=> "cab"
  #    a[6]                   #=> nil
  #    a[1, 2]                #=> [ "b", "c" ]
  #    a[1..3]                #=> [ "b", "c", "d" ]
  #    a[4..7]                #=> [ "e" ]
  #    a[6..10]               #=> nil
  #    a[-3, 3]               #=> [ "c", "d", "e" ]
  #    # special cases
  #    a[5]                   #=> nil
  #    a[5, 1]                #=> []
  #    a[5..10]               #=> []
  #   
  # 
  # 
  def slice(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.sort!                   -> array
  #     array.sort! {| a,b | block }  -> array 
  #   
  # 
  # Sorts _self_. Comparisons for
  # the sort will be done using the <code><=></code> operator or using
  # an optional code block. The block implements a comparison between
  # <i>a</i> and <i>b</i>, returning -1, 0, or +1. See also
  # <code>Enumerable#sort_by</code>.
  #    
  #    a = [ "d", "a", "e", "c", "b" ]
  #    a.sort                    #=> ["a", "b", "c", "d", "e"]
  #    a.sort {|x,y| y <=> x }   #=> ["e", "d", "c", "b", "a"]
  # 
  # 
  def sort!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.sort                   -> an_array 
  #     array.sort {| a,b | block }  -> an_array 
  #   
  # 
  # Returns a new array created by sorting <i>self</i>. Comparisons for
  # the sort will be done using the <code><=></code> operator or using
  # an optional code block. The block implements a comparison between
  # <i>a</i> and <i>b</i>, returning -1, 0, or +1. See also
  # <code>Enumerable#sort_by</code>.
  #    
  #    a = [ "d", "a", "e", "c", "b" ]
  #    a.sort                    #=> ["a", "b", "c", "d", "e"]
  #    a.sort {|x,y| y <=> x }   #=> ["e", "d", "c", "b", "a"]
  # 
  # 
  def sort
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.to_a     -> array
  #   
  # 
  # Returns _self_. If called on a subclass of Array, converts
  # the receiver to an Array object.
  # 
  # 
  def to_a
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.to_ary -> array
  #   
  # 
  # Returns _self_.
  # 
  # 
  def to_ary
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.to_s -> string
  #   
  # 
  # Returns _self_<code>.join</code>.
  #    
  #    [ "a", "e", "i", "o" ].to_s   #=> "aeio"
  #   
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.transpose -> an_array
  #   
  # 
  # Assumes that <i>self</i> is an array of arrays and transposes the
  # rows and columns.
  #    
  #    a = [[1,2], [3,4], [5,6]]
  #    a.transpose   #=> [[1, 3, 5], [2, 4, 6]]
  # 
  # 
  def transpose
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.uniq! -> array or nil
  #   
  # 
  # Removes duplicate elements from _self_.
  # Returns <code>nil</code> if no changes are made (that is, no
  # duplicates are found).
  #    
  #    a = [ "a", "a", "b", "b", "c" ]
  #    a.uniq!   #=> ["a", "b", "c"]
  #    b = [ "a", "b", "c" ]
  #    b.uniq!   #=> nil
  # 
  # 
  def uniq!
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.uniq   -> an_array
  #   
  # 
  # Returns a new array by removing duplicate values in <i>self</i>.
  #    
  #    a = [ "a", "a", "b", "b", "c" ]
  #    a.uniq   #=> ["a", "b", "c"]
  # 
  # 
  def uniq
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.unshift(obj, ...)  -> array
  #   
  # 
  # Prepends objects to the front of <i>array</i>.
  # other elements up one.
  #    
  #    a = [ "b", "c", "d" ]
  #    a.unshift("a")   #=> ["a", "b", "c", "d"]
  #    a.unshift(1, 2)  #=> [ 1, 2, "a", "b", "c", "d"]
  # 
  # 
  def unshift(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.values_at(selector,... )  -> an_array
  # 
  # 
  # Returns an array containing the elements in
  # _self_ corresponding to the given selector(s). The selectors
  # may be either integer indices or ranges. 
  # See also <code>Array#select</code>.
  # 
  #    a = %w{ a b c d e f }
  #    a.values_at(1, 3, 5)
  #    a.values_at(1, 3, 5, 7)
  #    a.values_at(-1, -3, -5, -7)
  #    a.values_at(1..3, 2...5)
  # 
  # 
  def values_at(selector)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     array.zip(arg, ...)                   -> an_array
  #     array.zip(arg, ...) {| arr | block }  -> nil
  #   
  # 
  # Converts any arguments to arrays, then merges elements of
  # <i>self</i> with corresponding elements from each argument. This
  # generates a sequence of <code>self.size</code> <em>n</em>-element
  # arrays, where <em>n</em> is one more that the count of arguments. If
  # the size of any argument is less than <code>enumObj.size</code>,
  # <code>nil</code> values are supplied. If a block given, it is
  # invoked for each output array, otherwise an array of arrays is
  # returned.
  #    
  #    a = [ 4, 5, 6 ]
  #    b = [ 7, 8, 9 ]
  #    
  #    [1,2,3].zip(a, b)      #=> [[1, 4, 7], [2, 5, 8], [3, 6, 9]]
  #    [1,2].zip(a,b)         #=> [[1, 4, 7], [2, 5, 8]]
  #    a.zip([1,2],[8])       #=> [[4,1,8], [5,2,nil], [6,nil,nil]]
  # 
  # 
  def zip(arg)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
