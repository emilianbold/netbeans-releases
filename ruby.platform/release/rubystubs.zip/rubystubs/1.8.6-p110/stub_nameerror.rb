# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

class NameError < StandardError
  #     name_error.name    =>  string or nil
  #   
  # 
  # Return the name associated with this NameError exception.
  # 
  # 
  def name
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     NameError.new(msg [, name])  => name_error
  #   
  # 
  # Construct a new NameError exception. If given the <i>name</i>
  # parameter may subsequently be examined using the <code>NameError.name</code>
  # method.
  # 
  # 
  def self.new(msg, name)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     name_error.to_s   => string
  #   
  # 
  # Produce a nicely-formated string representing the +NameError+.
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
