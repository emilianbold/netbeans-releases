# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# The class of the singleton object <code>nil</code>.
# 
class NilClass
  #     false & obj   => false
  #     nil & obj     => false
  #   
  # 
  # And---Returns <code>false</code>. <i>obj</i> is always
  # evaluated as it is the argument to a method call---there is no
  # short-circuit evaluation in this case.
  # 
  # 
  def &
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     false ^ obj    => true or false
  #     nil   ^ obj    => true or false
  #   
  # 
  # Exclusive Or---If <i>obj</i> is <code>nil</code> or
  # <code>false</code>, returns <code>false</code>; otherwise, returns
  # <code>true</code>.
  #    
  # 
  # 
  def ^
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     false | obj   =>   true or false
  #     nil   | obj   =>   true or false
  #   
  # 
  # Or---Returns <code>false</code> if <i>obj</i> is
  # <code>nil</code> or <code>false</code>; <code>true</code> otherwise.
  # 
  # 
  def |
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     nil.inspect  => "nil"
  #   
  # 
  # Always returns the string "nil".
  # 
  # 
  def inspect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # call_seq:
  #  nil.nil?               => true
  #   
  # Only the object <i>nil</i> responds <code>true</code> to <code>nil?</code>.
  # 
  # 
  def nil?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     nil.to_a    => []
  #   
  # 
  # Always returns an empty array.
  #    
  #    nil.to_a   #=> []
  # 
  # 
  def to_a
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     nil.to_f    => 0.0
  #   
  # 
  # Always returns zero.
  #    
  #    nil.to_f   #=> 0.0
  # 
  # 
  def to_f
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     nil.to_i => 0
  #   
  # 
  # Always returns zero.
  #    
  #    nil.to_i   #=> 0
  # 
  # 
  # 
  def to_i
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     nil.to_s    => ""
  #   
  # 
  # Always returns the empty string.
  #    
  #    nil.to_s   #=> ""
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
