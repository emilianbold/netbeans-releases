# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# <code>Integer</code> is the basis for the two concrete classes that
# hold whole numbers, <code>Bignum</code> and <code>Fixnum</code>.
#    
# 
class Integer < Numeric
  include Precision
  #     int.to_i      => int
  #     int.to_int    => int
  #     int.floor     => int
  #     int.ceil      => int
  #     int.round     => int
  #     int.truncate  => int
  #   
  # 
  # As <i>int</i> is already an <code>Integer</code>, all these
  # methods simply return the receiver.
  # 
  # 
  def ceil
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.chr    => string
  #   
  # 
  # Returns a string containing the ASCII character represented by the
  # receiver's value.
  #    
  #    65.chr    #=> "A"
  #    ?a.chr    #=> "a"
  #    230.chr   #=> "\346"
  # 
  # 
  def chr
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.downto(limit) {|i| block }     => int
  #   
  # 
  # Iterates <em>block</em>, passing decreasing values from <i>int</i>
  # down to and including <i>limit</i>.
  #    
  #    5.downto(1) { |n| print n, ".. " }
  #    print "  Liftoff!\n"
  #    
  # <em>produces:</em>
  #    
  #    5.. 4.. 3.. 2.. 1..   Liftoff!
  # 
  # 
  def downto(limit)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.to_i      => int
  #     int.to_int    => int
  #     int.floor     => int
  #     int.ceil      => int
  #     int.round     => int
  #     int.truncate  => int
  #   
  # 
  # As <i>int</i> is already an <code>Integer</code>, all these
  # methods simply return the receiver.
  # 
  # 
  def floor
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     Integer.induced_from(obj)    =>  fixnum, bignum
  #   
  # 
  # Convert <code>obj</code> to an Integer.
  # 
  # 
  def self.induced_from(obj)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.integer? -> true
  #   
  # 
  # Always returns <code>true</code>.
  # 
  # 
  def integer?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.next    => integer
  #     int.succ    => integer
  #   
  # 
  # Returns the <code>Integer</code> equal to <i>int</i> + 1.
  #    
  #    1.next      #=> 2
  #    (-1).next   #=> 0
  # 
  # 
  def next
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.to_i      => int
  #     int.to_int    => int
  #     int.floor     => int
  #     int.ceil      => int
  #     int.round     => int
  #     int.truncate  => int
  #   
  # 
  # As <i>int</i> is already an <code>Integer</code>, all these
  # methods simply return the receiver.
  # 
  # 
  def round
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.next    => integer
  #     int.succ    => integer
  #   
  # 
  # Returns the <code>Integer</code> equal to <i>int</i> + 1.
  #    
  #    1.next      #=> 2
  #    (-1).next   #=> 0
  # 
  # 
  def succ
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.times {|i| block }     => int
  #   
  # 
  # Iterates block <i>int</i> times, passing in values from zero to
  # <i>int</i> - 1.
  #    
  #    5.times do |i|
  #      print i, " "
  #    end
  #    
  # <em>produces:</em>
  #    
  #    0 1 2 3 4
  # 
  # 
  def times
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.to_i      => int
  #     int.to_int    => int
  #     int.floor     => int
  #     int.ceil      => int
  #     int.round     => int
  #     int.truncate  => int
  #   
  # 
  # As <i>int</i> is already an <code>Integer</code>, all these
  # methods simply return the receiver.
  # 
  # 
  def to_i
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.to_i      => int
  #     int.to_int    => int
  #     int.floor     => int
  #     int.ceil      => int
  #     int.round     => int
  #     int.truncate  => int
  #   
  # 
  # As <i>int</i> is already an <code>Integer</code>, all these
  # methods simply return the receiver.
  # 
  # 
  def to_int
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.to_i      => int
  #     int.to_int    => int
  #     int.floor     => int
  #     int.ceil      => int
  #     int.round     => int
  #     int.truncate  => int
  #   
  # 
  # As <i>int</i> is already an <code>Integer</code>, all these
  # methods simply return the receiver.
  # 
  # 
  def truncate
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     int.upto(limit) {|i| block }     => int
  #   
  # 
  # Iterates <em>block</em>, passing in integer values from <i>int</i>
  # up to and including <i>limit</i>.
  #    
  #    5.upto(10) { |i| print i, " " }
  #    
  # <em>produces:</em>
  #    
  #    5 6 7 8 9 10
  # 
  # 
  def upto(limit)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
