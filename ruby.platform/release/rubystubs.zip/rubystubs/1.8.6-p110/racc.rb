# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

module Racc

  class CparseParams

  end

  class Parser
    Racc_Runtime_Core_Version_C = 'rb_str_new2(RACC_VERSION)'
    Racc_Runtime_Core_Id_C = 'rb_str_new2("$originalId: cparse.c,v 1.8 2006/07/06 11:39:46 aamine Exp $")'

  end

end
