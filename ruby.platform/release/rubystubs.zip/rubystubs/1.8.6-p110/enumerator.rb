# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

module Enumerable
  #     each_cons(n) {...}
  #   
  # 
  # Iterates the given block for each array of consecutive <n>
  # elements.
  #   
  # e.g.:
  #     (1..10).each_cons(3) {|a| p a}
  #     # outputs below
  #     [1, 2, 3]
  #     [2, 3, 4]
  #     [3, 4, 5]
  #     [4, 5, 6]
  #     [5, 6, 7]
  #     [6, 7, 8]
  #     [7, 8, 9]
  #     [8, 9, 10]
  #   
  # 
  def each_cons(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     e.each_slice(n) {...}
  #   
  # 
  # Iterates the given block for each slice of <n> elements.
  #   
  # e.g.:
  #     (1..10).each_slice(3) {|a| p a}
  #     # outputs below
  #     [1, 2, 3]
  #     [4, 5, 6]
  #     [7, 8, 9]
  #     [10]
  #   
  # 
  def each_slice(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     e.enum_cons(n)
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, :each_cons, n).
  #   
  # 
  def enum_cons(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     e.enum_slice(n)
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, :each_slice, n).
  #   
  # 
  def enum_slice(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     enum_with_index
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, :each_with_index).
  #   
  # 
  def enum_with_index
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # A class which provides a method `each' to be used as an Enumerable
  # object.
  # 
  class Enumerator
    include Enumerable
    #     enum.each {...}
    #   
    # 
    # Iterates the given block using the object and the method specified
    # in the first place.
    #   
    # 
    def each
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     Enumerable::Enumerator.new(obj, method = :each, *args)
    #   
    # 
    # Creates a new Enumerable::Enumerator object, which is to be
    # used as an Enumerable object using the given object's given
    # method with the given arguments.
    #   
    # e.g.:
    #     str = "xyz"
    #   
    #     enum = Enumerable::Enumerator.new(str, :each_byte)
    #     a = enum.map {|b| '%02x' % b } #=> ["78", "79", "7a"]
    #   
    # 
    def self.new(obj, method = :each, *args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

end

class Object
  #     obj.to_enum(method = :each, *args)
  #     obj.enum_for(method = :each, *args)
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, method, *args).
  #   
  # e.g.:
  #    str = "xyz"
  #   
  #    enum = str.enum_for(:each_byte)
  #    a = enum.map {|b| '%02x' % b } #=> ["78", "79", "7a"]
  #   
  #    # protects an array from being modified
  #    a = [1, 2, 3]
  #    some_method(a.to_enum)
  #   
  # 
  def to_enum(method = :each, *args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     obj.to_enum(method = :each, *args)
  #     obj.enum_for(method = :each, *args)
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, method, *args).
  #   
  # e.g.:
  #    str = "xyz"
  #   
  #    enum = str.enum_for(:each_byte)
  #    a = enum.map {|b| '%02x' % b } #=> ["78", "79", "7a"]
  #   
  #    # protects an array from being modified
  #    a = [1, 2, 3]
  #    some_method(a.to_enum)
  #   
  # 
  def enum_for(method = :each, *args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     obj.to_enum(method = :each, *args)
  #     obj.enum_for(method = :each, *args)
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, method, *args).
  #   
  # e.g.:
  #    str = "xyz"
  #   
  #    enum = str.enum_for(:each_byte)
  #    a = enum.map {|b| '%02x' % b } #=> ["78", "79", "7a"]
  #   
  #    # protects an array from being modified
  #    a = [1, 2, 3]
  #    some_method(a.to_enum)
  #   
  # 
  def to_enum(method = :each, *args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     obj.to_enum(method = :each, *args)
  #     obj.enum_for(method = :each, *args)
  #   
  # 
  # Returns Enumerable::Enumerator.new(self, method, *args).
  #   
  # e.g.:
  #    str = "xyz"
  #   
  #    enum = str.enum_for(:each_byte)
  #    a = enum.map {|b| '%02x' % b } #=> ["78", "79", "7a"]
  #   
  #    # protects an array from being modified
  #    a = [1, 2, 3]
  #    some_method(a.to_enum)
  #   
  # 
  def enum_for(method = :each, *args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
