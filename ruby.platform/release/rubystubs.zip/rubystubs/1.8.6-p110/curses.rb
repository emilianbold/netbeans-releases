# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   ------------------------- Initialization -------------------------  
module Curses
  # def addch(ch)   
  def self.addch(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def addstr(str)   
  def self.addstr(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def beep   
  def self.beep
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def cbreak   
  def self.cbreak
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def clear   
  def self.clear
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def close_screen   
  def self.close_screen
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def closed?   
  def self.closed?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def clrtoeol   
  def self.clrtoeol
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def delch   
  def self.delch
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def delelteln   
  def self.deleteln
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def doupdate   
  def self.doupdate
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def echo   
  def self.echo
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def flash   
  def self.flash
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def getch   
  def self.getch
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def getstr   
  def self.getstr
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def inch   
  def self.inch
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def init_screen   
  def self.init_screen
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def insch(ch)   
  def self.insch(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def insertln   
  def self.insertln
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def keyname   
  def self.keyname(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def nl   
  def self.nl
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def nocbreak   
  def self.nocbreak
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def noecho   
  def self.noecho
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def nonl   
  def self.nonl
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def noraw   
  def self.noraw
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def raw   
  def self.raw
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def refresh   
  def self.refresh
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def setpos(y, x)   
  def self.setpos(p1, p2)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def standend   
  def self.standend
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def standout   
  def self.standout
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def stdscr   
  # def init_screen   
  def self.stdscr
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # USE_MOUSE   
  # 
  def self.timeout=(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # def ungetch   
  def self.ungetch(p1)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


  module Key
    MOUSE = 'INT2NUM(KEY_MOUSE)'
    MIN = 'INT2NUM(KEY_MIN)'
    BREAK = 'INT2NUM(KEY_BREAK)'
    DOWN = 'INT2NUM(KEY_DOWN)'
    UP = 'INT2NUM(KEY_UP)'
    LEFT = 'INT2NUM(KEY_LEFT)'
    RIGHT = 'INT2NUM(KEY_RIGHT)'
    HOME = 'INT2NUM(KEY_HOME)'
    BACKSPACE = 'INT2NUM(KEY_BACKSPACE)'
    DL = 'INT2NUM(KEY_DL)'
    IL = 'INT2NUM(KEY_IL)'
    DC = 'INT2NUM(KEY_DC)'
    IC = 'INT2NUM(KEY_IC)'
    EIC = 'INT2NUM(KEY_EIC)'
    CLEAR = 'INT2NUM(KEY_CLEAR)'
    EOS = 'INT2NUM(KEY_EOS)'
    EOL = 'INT2NUM(KEY_EOL)'
    SF = 'INT2NUM(KEY_SF)'
    SR = 'INT2NUM(KEY_SR)'
    NPAGE = 'INT2NUM(KEY_NPAGE)'
    PPAGE = 'INT2NUM(KEY_PPAGE)'
    STAB = 'INT2NUM(KEY_STAB)'
    CTAB = 'INT2NUM(KEY_CTAB)'
    CATAB = 'INT2NUM(KEY_CATAB)'
    ENTER = 'INT2NUM(KEY_ENTER)'
    SRESET = 'INT2NUM(KEY_SRESET)'
    RESET = 'INT2NUM(KEY_RESET)'
    PRINT = 'INT2NUM(KEY_PRINT)'
    LL = 'INT2NUM(KEY_LL)'
    A1 = 'INT2NUM(KEY_A1)'
    A3 = 'INT2NUM(KEY_A3)'
    B2 = 'INT2NUM(KEY_B2)'
    C1 = 'INT2NUM(KEY_C1)'
    C3 = 'INT2NUM(KEY_C3)'
    BTAB = 'INT2NUM(KEY_BTAB)'
    BEG = 'INT2NUM(KEY_BEG)'
    CANCEL = 'INT2NUM(KEY_CANCEL)'
    CLOSE = 'INT2NUM(KEY_CLOSE)'
    COMMAND = 'INT2NUM(KEY_COMMAND)'
    COPY = 'INT2NUM(KEY_COPY)'
    CREATE = 'INT2NUM(KEY_CREATE)'
    END_ = 'INT2NUM(KEY_END)'
    EXIT = 'INT2NUM(KEY_EXIT)'
    FIND = 'INT2NUM(KEY_FIND)'
    HELP = 'INT2NUM(KEY_HELP)'
    MARK = 'INT2NUM(KEY_MARK)'
    MESSAGE = 'INT2NUM(KEY_MESSAGE)'
    MOVE = 'INT2NUM(KEY_MOVE)'
    NEXT = 'INT2NUM(KEY_NEXT)'
    OPEN = 'INT2NUM(KEY_OPEN)'
    OPTIONS = 'INT2NUM(KEY_OPTIONS)'
    PREVIOUS = 'INT2NUM(KEY_PREVIOUS)'
    REDO = 'INT2NUM(KEY_REDO)'
    REFERENCE = 'INT2NUM(KEY_REFERENCE)'
    REFRESH = 'INT2NUM(KEY_REFRESH)'
    REPLACE = 'INT2NUM(KEY_REPLACE)'
    RESTART = 'INT2NUM(KEY_RESTART)'
    RESUME = 'INT2NUM(KEY_RESUME)'
    SAVE = 'INT2NUM(KEY_SAVE)'
    SBEG = 'INT2NUM(KEY_SBEG)'
    SCANCEL = 'INT2NUM(KEY_SCANCEL)'
    SCOMMAND = 'INT2NUM(KEY_SCOMMAND)'
    SCOPY = 'INT2NUM(KEY_SCOPY)'
    SCREATE = 'INT2NUM(KEY_SCREATE)'
    SDC = 'INT2NUM(KEY_SDC)'
    SDL = 'INT2NUM(KEY_SDL)'
    SELECT = 'INT2NUM(KEY_SELECT)'
    SEND = 'INT2NUM(KEY_SEND)'
    SEOL = 'INT2NUM(KEY_SEOL)'
    SEXIT = 'INT2NUM(KEY_SEXIT)'
    SFIND = 'INT2NUM(KEY_SFIND)'
    SHELP = 'INT2NUM(KEY_SHELP)'
    SHOME = 'INT2NUM(KEY_SHOME)'
    SIC = 'INT2NUM(KEY_SIC)'
    SLEFT = 'INT2NUM(KEY_SLEFT)'
    SMESSAGE = 'INT2NUM(KEY_SMESSAGE)'
    SMOVE = 'INT2NUM(KEY_SMOVE)'
    SNEXT = 'INT2NUM(KEY_SNEXT)'
    SOPTIONS = 'INT2NUM(KEY_SOPTIONS)'
    SPREVIOUS = 'INT2NUM(KEY_SPREVIOUS)'
    SPRINT = 'INT2NUM(KEY_SPRINT)'
    SREDO = 'INT2NUM(KEY_SREDO)'
    SREPLACE = 'INT2NUM(KEY_SREPLACE)'
    SRIGHT = 'INT2NUM(KEY_SRIGHT)'
    SRSUME = 'INT2NUM(KEY_SRSUME)'
    SSAVE = 'INT2NUM(KEY_SSAVE)'
    SSUSPEND = 'INT2NUM(KEY_SSUSPEND)'
    SUNDO = 'INT2NUM(KEY_SUNDO)'
    SUSPEND = 'INT2NUM(KEY_SUSPEND)'
    UNDO = 'INT2NUM(KEY_UNDO)'
    RESIZE = 'INT2NUM(KEY_RESIZE)'
    MAX = 'INT2NUM(KEY_MAX)'

  end

  class MouseEvent

  end

  class Window < Data
    # def <<(str)   
    def <<(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def addch(ch)   
    def addch(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def addstr(str)   
    def addstr(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def begx   
    def begx
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def begy   
    def begy
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def box(vert, hor)   
    def box(*args)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def clear   
    def clear
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def close   
    def close
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def clrtoeol   
    def clrtoeol
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def curx   
    def curx
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def cury   
    def cury
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def delch   
    def delch
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def delelteln   
    def deleteln
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def getch   
    def getch
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def getstr   
    def getstr
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def inch   
    def inch
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def insch(ch)   
    def insch(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def insertln   
    def insertln
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def maxx   
    def maxx
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def maxy   
    def maxy
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def move(y, x)   
    def move(p1, p2)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def initialize(h, w, top, left)   
    def self.new(p1, p2, p3, p4)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def noutrefresh   
    def noutrefresh
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def refresh   
    def refresh
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # USE_COLOR   
    # 
    def scroll
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def setpos(y, x)   
    def setpos(p1, p2)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def standend   
    def standend
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def standout   
    def standout
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    # def subwin(height, width, top, left)   
    def subwin(p1, p2, p3, p4)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

end
