# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

module Readline
  HISTORY = history
  FILENAME_COMPLETION_PROC = fcomp
  USERNAME_COMPLETION_PROC = ucomp
  VERSION = 'rb_str_new2(rl_library_version)'
  VERSION = 'rb_str_new2("2.0 or before version")'

end
