# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# <code>MatchData</code> is the type of the special variable <code>$~</code>,
# and is the type of the object returned by <code>Regexp#match</code> and
# <code>Regexp#last_match</code>. It encapsulates all the results of a pattern
# match, results normally accessed through the special variables
# <code>$&</code>, <code>$'</code>, <code>$`</code>, <code>$1</code>,
# <code>$2</code>, and so on. <code>Matchdata</code> is also known as
# <code>MatchingData</code>.
#   
# 
class MatchData
  #     mtch[i]               => obj
  #     mtch[start, length]   => array
  #     mtch[range]           => array
  #   
  # 
  # Match Reference---<code>MatchData</code> acts as an array, and may be
  # accessed using the normal array indexing techniques.  <i>mtch</i>[0] is
  # equivalent to the special variable <code>$&</code>, and returns the entire
  # matched string.  <i>mtch</i>[1], <i>mtch</i>[2], and so on return the values
  # of the matched backreferences (portions of the pattern between parentheses).
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m[0]       #=> "HX1138"
  #    m[1, 2]    #=> ["H", "X"]
  #    m[1..3]    #=> ["H", "X", "113"]
  #    m[-3, 2]   #=> ["X", "113"]
  # 
  # 
  def []
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.begin(n)   => integer
  #   
  # 
  # Returns the offset of the start of the <em>n</em>th element of the match
  # array in the string.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.begin(0)   #=> 1
  #    m.begin(2)   #=> 2
  # 
  # 
  def begin(n)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     mtch.captures   => array
    #   
    # 
    # Returns the array of captures; equivalent to <code>mtch.to_a[1..-1]</code>.
    #   
    #    f1,f2,f3,f4 = /(.)(.)(\d+)(\d)/.match("THX1138.").captures
    #    f1    #=> "H"
    #    f2    #=> "X"
    #    f3    #=> "113"
    #    f4    #=> "8"
    # 
    def captures
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #     mtch.end(n)   => integer
    #   
    # 
    # Returns the offset of the character immediately following the end of the
    # <em>n</em>th element of the match array in the string.
    #    
    #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
    #    m.end(0)   #=> 7
    #    m.end(2)   #=> 3
    # 
    # 
    def end(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     obj.to_s    => string
  #   
  # 
  # Returns a string representing <i>obj</i>. The default
  # <code>to_s</code> prints the object's class and an encoding of the
  # object id. As a special case, the top-level object that is the
  # initial execution context of Ruby programs returns ``main.''
  # 
  # 
  def inspect
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.length   => integer
  #     mtch.size     => integer
  #   
  # 
  # Returns the number of elements in the match array.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.length   #=> 5
  #    m.size     #=> 5
  # 
  # 
  def length
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.offset(n)   => array
  #   
  # 
  # Returns a two-element array containing the beginning and ending offsets of
  # the <em>n</em>th match.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.offset(0)   #=> [1, 7]
  #    m.offset(4)   #=> [6, 7]
  # 
  # 
  def offset(n)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.post_match   => str
  #   
  # 
  # Returns the portion of the original string after the current match.
  # Equivalent to the special variable <code>$'</code>.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138: The Movie")
  #    m.post_match   #=> ": The Movie"
  # 
  # 
  def post_match
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.pre_match   => str
  #   
  # 
  # Returns the portion of the original string before the current match.
  # Equivalent to the special variable <code>$`</code>.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.pre_match   #=> "T"
  # 
  # 
  def pre_match
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.select([index]*)   => array
  #   
  # 
  # Uses each <i>index</i> to access the matching values, returning an
  # array of the corresponding matches.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138: The Movie")
  #    m.to_a               #=> ["HX1138", "H", "X", "113", "8"]
  #    m.select(0, 2, -2)   #=> ["HX1138", "X", "113"]
  # 
  # 
  def select(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.length   => integer
  #     mtch.size     => integer
  #   
  # 
  # Returns the number of elements in the match array.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.length   #=> 5
  #    m.size     #=> 5
  # 
  # 
  def size
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.string   => str
  #   
  # 
  # Returns a frozen copy of the string passed in to <code>match</code>.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.string   #=> "THX1138."
  # 
  # 
  def string
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.to_a   => anArray
  #   
  # 
  # Returns the array of matches.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.to_a   #=> ["HX1138", "H", "X", "113", "8"]
  #    
  # Because <code>to_a</code> is called when expanding
  # <code>*</code><em>variable</em>, there's a useful assignment
  # shortcut for extracting matched fields. This is slightly slower than
  # accessing the fields directly (as an intermediate array is
  # generated).
  #    
  #    all,f1,f2,f3 = *(/(.)(.)(\d+)(\d)/.match("THX1138."))
  #    all   #=> "HX1138"
  #    f1    #=> "H"
  #    f2    #=> "X"
  #    f3    #=> "113"
  # 
  # 
  def to_a
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.to_s   => str
  #   
  # 
  # Returns the entire matched string.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138.")
  #    m.to_s   #=> "HX1138"
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     mtch.select([index]*)   => array
  #   
  # 
  # Uses each <i>index</i> to access the matching values, returning an array of
  # the corresponding matches.
  #    
  #    m = /(.)(.)(\d+)(\d)/.match("THX1138: The Movie")
  #    m.to_a               #=> ["HX1138", "H", "X", "113", "8"]
  #    m.select(0, 2, -2)   #=> ["HX1138", "X", "113"]
  # 
  # 
  def select(index)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
