# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
# Fcntl loads the constants defined in the system's <fcntl.h> C header
# file, and used with both the fcntl(2) and open(2) POSIX system calls.
#   
# Copyright (C) 1997-2001 Yukihiro Matsumoto
#   
# Documented by mathew <meta@pobox.com>
#   
# = Usage
# 
# To perform a fcntl(2) operation, use IO::fcntl in the core classes.
#   
# To perform an open(2) operation, use IO::sysopen.
#   
# The set of operations and constants available depends upon specific OS
# platform. Some values listed below may not be supported on your system.
#   
# The constants supported by Ruby for use with IO::fcntl are:
#   
# - F_DUPFD - duplicate a close-on-exec file handle to a non-close-on-exec
#  file handle.
#   
# - F_GETFD - read the close-on-exec flag of a file handle.
#   
# - F_SETFD - set the close-on-exec flag of a file handle.
#   
# - FD_CLOEXEC - the value of the close-on-exec flag.
#   
# - F_GETFL - get file descriptor flags.
#   
# - F_SETFL - set file descriptor flags.
#   
# - O_APPEND, O_NONBLOCK, etc (see below) - file descriptor flag
#  values for the above.
#   
# - F_GETLK - determine whether a given region of a file is locked.
#   
# - F_SETLK - acquire a lock on a region of a file.
#   
# - F_SETLKW - acquire a lock on a region of a file, waiting if necessary.
#   
# - F_RDLCK, F_WRLCK, F_UNLCK - types of lock for the above.
#   
# The constants supported by Ruby for use with IO::sysopen are:
#   
# - O_APPEND - open file in append mode.
#   
# - O_NOCTTY - open tty without it becoming controlling tty.
#   
# - O_CREAT - create file if it doesn't exist.
#   
# - O_EXCL - used with O_CREAT, fail if file exists.
#   
# - O_TRUNC - truncate file on open.
#   
# - O_NONBLOCK / O_NDELAY - open in non-blocking mode.
#   
# - O_RDONLY - open read-only.
#   
# - O_WRONLY - open write-only.
#   
# - O_RDWR - open read-write.
#   
# - O_ACCMODE - mask to extract read/write flags.
#   
# Example:
# 
#  require 'fcntl'
#   
#  fd = IO::sysopen('/tmp/tempfile', 
#       Fcntl::O_WRONLY | Fcntl::O_EXCL | Fcntl::O_CREAT)
#  f = IO.open(fd)
#  f.syswrite("TEMP DATA")
#  f.close
#   
# 
module Fcntl
  F_DUPFD = 'INT2NUM(F_DUPFD)'
  F_GETFD = 'INT2NUM(F_GETFD)'
  F_GETLK = 'INT2NUM(F_GETLK)'
  F_SETFD = 'INT2NUM(F_SETFD)'
  F_GETFL = 'INT2NUM(F_GETFL)'
  F_SETFL = 'INT2NUM(F_SETFL)'
  F_SETLK = 'INT2NUM(F_SETLK)'
  F_SETLKW = 'INT2NUM(F_SETLKW)'
  FD_CLOEXEC = 'INT2NUM(FD_CLOEXEC)'
  F_RDLCK = 'INT2NUM(F_RDLCK)'
  F_UNLCK = 'INT2NUM(F_UNLCK)'
  F_WRLCK = 'INT2NUM(F_WRLCK)'
  O_CREAT = 'INT2NUM(O_CREAT)'
  O_EXCL = 'INT2NUM(O_EXCL)'
  O_NOCTTY = 'INT2NUM(O_NOCTTY)'
  O_TRUNC = 'INT2NUM(O_TRUNC)'
  O_APPEND = 'INT2NUM(O_APPEND)'
  O_NONBLOCK = 'INT2NUM(O_NONBLOCK)'
  O_NDELAY = 'INT2NUM(O_NDELAY)'
  O_RDONLY = 'INT2NUM(O_RDONLY)'
  O_RDWR = 'INT2NUM(O_RDWR)'
  O_WRONLY = 'INT2NUM(O_WRONLY)'
  O_ACCMODE = 'INT2FIX(O_ACCMODE)'
  O_ACCMODE = 'INT2FIX(O_RDONLY | O_WRONLY | O_RDWR)'

end
