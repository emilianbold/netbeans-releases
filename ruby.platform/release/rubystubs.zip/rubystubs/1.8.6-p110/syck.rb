# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

module YAML

  class DomainType
    attr_accessor :domain
    attr_accessor :type_id
    attr_accessor :value
    #   
    # YAML::DomainType.initialize
    # 
    def self.new(p1, p2, p3)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

  class Object
    attr_accessor :class
    attr_accessor :ivars
    #   
    # YAML::Object.initialize
    # 
    def self.new(p1, p2)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end

    #   
    # YAML::Object.initialize
    # 
    def yaml_initialize(p1, p2)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

  class PrivateType
    attr_accessor :type_id
    attr_accessor :value
    #   
    # YAML::PrivateType.initialize
    # 
    def self.new(p1, p2)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


  end

  module Syck
    VERSION = 'rb_str_new2( SYCK_VERSION )'
    DefaultResolver = oDefaultResolver
    GenericResolver = oGenericResolver
    #   
    # Convert YAML to bytecode
    # 
    def self.compile(p1)
      # This is just a stub for a builtin Ruby method.
      # See the top of this file for more info.
    end


    class BadAlias
      attr_accessor :name
      #   
      # YAML::Syck::BadAlias.<=>
      # 
      def <=>(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::BadAlias.initialize
      # 
      def self.new(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class DefaultKey

    end

    class Emitter
      attr_accessor :level
      #   
      # YAML::Syck::Emitter.emit( object_id ) { |out| ... }
      # 
      def emit(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Emitter.reset( options )
      # 
      def self.new(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Emitter#node_export
      # 
      def node_export(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Emitter.reset( options )
      # 
      def reset(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Emitter#set_resolver
      # 
      def set_resolver(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Map < YAML::Syck::Node
      #   
      # YAML::Syck::Map.add
      # 
      def add(p1, p2)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Map.initialize
      # 
      def self.new(p1, p2, p3)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Map.style=
      # 
      def style=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Map.value=
      # 
      def value=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class MergeKey

    end

    class Node
      attr_accessor :emitter
      attr_reader :kind
      attr_accessor :resolver
      attr_reader :type_id
      attr_reader :value
      attr_reader :value
      #   
      # Cloning method for all node types
      # 
      def initialize_copy(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Node.transform
      # 
      def transform
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Node#type_id=
      # 
      def type_id=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Out
      attr_accessor :emitter
      #   
      # YAML::Syck::Out::map
      # 
      def map(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Out::initialize
      # 
      def self.new(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Out::scalar
      # syck_out_scalar( self, type_id, str, style )
      # VALUE self, type_id, str, style;
      # 
      def scalar(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Out::seq
      # 
      def seq(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Parser
      attr_accessor :input
      attr_accessor :options
      attr_accessor :resolver
      #   
      # YAML::Syck::Parser.bufsize = Integer
      # 
      def bufsize=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Parser.bufsize => Integer
      # 
      def bufsize
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Parser.load( IO or String )
      # 
      def load(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Parser.load_documents( IO or String ) { |doc| }
      # 
      def load_documents(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Parser.initialize( resolver, options )
      # 
      def self.new(*args)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Parser#set_resolver
      # 
      def set_resolver(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Resolver
      attr_accessor :tags
      #   
      # YAML::Syck::Resolver#add_type
      # 
      def add_type(p1, p2)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Resolver#detect_implicit 
      # 
      def detect_implicit(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Resolver.initialize
      # 
      def self.new
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Resolver#node_import
      # 
      def node_import(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Resolver#tagurize
      # 
      def tagurize(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Resolver#transfer
      # 
      def transfer(p1, p2)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Resolver#use_types_at
      # 
      def use_types_at(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Scalar < YAML::Syck::Node
      #   
      # YAML::Syck::Scalar.initialize
      # 
      def self.new(p1, p2, p3)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Scalar.style=
      # 
      def style=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Scalar.value=
      # 
      def value=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

    class Seq < YAML::Syck::Node
      #   
      # YAML::Syck::Seq.add
      # 
      def add(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Seq.initialize
      # 
      def self.new(p1, p2, p3)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Seq.style=
      # 
      def style=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end

      #   
      # YAML::Syck::Seq.value=
      # 
      def value=(p1)
        # This is just a stub for a builtin Ruby method.
        # See the top of this file for more info.
      end


    end

  end

end
