# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

module PTY
  # ruby function: getpty   
  def self.getpty(*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # ruby function: protect_signal - obsolete   
  def self.protect_signal
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # ruby function: reset_signal - obsolete   
  def self.reset_signal
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  # ruby function: getpty   
  def self.spawn(*args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


  class ChildExited < RuntimeError

  end

end
