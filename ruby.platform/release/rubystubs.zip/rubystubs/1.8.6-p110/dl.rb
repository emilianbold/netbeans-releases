# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

class Array

end

module DL
  FuncTable = DLFuncTable
  RTLD_GLOBAL = 'INT2NUM(RTLD_GLOBAL)'
  RTLD_LAZY = 'INT2NUM(RTLD_LAZY)'
  RTLD_NOW = 'INT2NUM(RTLD_NOW)'
  ALIGN_INT = 'INT2NUM(ALIGN_INT)'
  ALIGN_LONG = 'INT2NUM(ALIGN_LONG)'
  ALIGN_FLOAT = 'INT2NUM(ALIGN_FLOAT)'
  ALIGN_SHORT = 'INT2NUM(ALIGN_SHORT)'
  ALIGN_DOUBLE = 'INT2NUM(ALIGN_DOUBLE)'
  ALIGN_VOIDP = 'INT2NUM(ALIGN_VOIDP)'
  MAX_ARG = 'INT2NUM(MAX_ARG)'
  DLSTACK = 'rb_tainted_str_new2(DLSTACK_METHOD)'
  FREE = 'rb_dlsym_new(dlfree, "free", "0P")'

  class DLError < StandardError

  end

  class DLTypeError < DL::DLError

  end

end

class IO

end

class String

end
