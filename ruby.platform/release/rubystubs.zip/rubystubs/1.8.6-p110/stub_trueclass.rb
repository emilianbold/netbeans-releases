# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# The global value <code>true</code> is the only instance of class
# <code>TrueClass</code> and represents a logically true value in
# boolean expressions. The class provides operators allowing
# <code>true</code> to be used in logical expressions.
# 
class TrueClass
  #     true & obj    => true or false
  #   
  # 
  # And---Returns <code>false</code> if <i>obj</i> is
  # <code>nil</code> or <code>false</code>, <code>true</code> otherwise.
  # 
  # 
  def &
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     true ^ obj   => !obj
  #   
  # 
  # Exclusive Or---Returns <code>true</code> if <i>obj</i> is
  # <code>nil</code> or <code>false</code>, <code>false</code>
  # otherwise.
  # 
  # 
  def ^
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     true | obj   => true
  #   
  # 
  # Or---Returns <code>true</code>. As <i>anObject</i> is an argument to
  # a method call, it is always evaluated; there is no short-circuit
  # evaluation in this case.
  #    
  #    true |  puts("or")
  #    true || puts("logical or")
  #    
  # <em>produces:</em>
  #    
  #    or
  # 
  # 
  def |
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     true.to_s   =>  "true"
  #   
  # 
  # The string representation of <code>true</code> is "true".
  # 
  # 
  def to_s
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
