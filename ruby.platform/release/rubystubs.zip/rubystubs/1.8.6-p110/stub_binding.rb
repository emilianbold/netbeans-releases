# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#
#   
# Objects of class <code>Binding</code> encapsulate the execution
# context at some particular place in the code and retain this context 
# for future use. The variables, methods, value of <code>self</code>,
# and possibly an iterator block that can be accessed in this context
# are all retained. Binding objects can be created using
# <code>Kernel#binding</code>, and are made available to the callback
# of <code>Kernel#set_trace_func</code>.
#    
# These binding objects can be passed as the second argument of the
# <code>Kernel#eval</code> method, establishing an environment for the
# evaluation.
#    
#    class Demo
#      def initialize(n)
#        @secret = n
#      end
#      def getBinding
#        return binding()
#      end
#    end
#    
#    k1 = Demo.new(99)
#    b1 = k1.getBinding
#    k2 = Demo.new(-3)
#    b2 = k2.getBinding
#    
#    eval("@secret", b1)   #=> 99
#    eval("@secret", b2)   #=> -3
#    eval("@secret")       #=> nil
#    
# Binding objects have no class-specific methods.
#    
# 
# 
class Binding
  #   
  # MISSING: documentation
  # 
  # 
  def clone
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #   
  # MISSING: documentation
  # 
  # 
  def dup
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
