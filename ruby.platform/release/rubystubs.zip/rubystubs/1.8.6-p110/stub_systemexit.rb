# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

class SystemExit < Exception
  #     SystemExit.new(status=0)   => system_exit
  #   
  # 
  # Create a new +SystemExit+ exception with the given status.
  # 
  # 
  def self.new(status=0)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     system_exit.status   => fixnum
  #   
  # 
  # Return the status value associated with this system exit.
  # 
  # 
  def status
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     system_exit.success?  => true or false
  #   
  # 
  # Returns +true+ if exiting successful, +false+ if not.
  # 
  # 
  def success?
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
