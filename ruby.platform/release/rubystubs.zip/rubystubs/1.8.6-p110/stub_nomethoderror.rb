# This is a machine-generated stub file for the NetBeans IDE Ruby Support.
#
# Many Ruby methods are "built in" which means that there is no
# Ruby source code for them. It is convenient for the IDE however to
# have these files for indexing and documentation purposes, so the following
# class definition is generated from the native implementation as a skeleton
# or stub to index.
#
# Ruby Version: "1.8.6"
# Generator version: 1.0
#

#

class NoMethodError < NameError
  #     no_method_error.args  => obj
  #   
  # 
  # Return the arguments passed in as the third parameter to
  # the constructor.
  # 
  # 
  def args
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end

  #     NoMethodError.new(msg, name [, args])  => no_method_error
  #   
  # 
  # Construct a NoMethodError exception for a method of the given name
  # called with the given arguments. The name may be accessed using
  # the <code>#name</code> method on the resulting object, and the
  # arguments using the <code>#args</code> method.
  # 
  # 
  def self.new(msg, name, args)
    # This is just a stub for a builtin Ruby method.
    # See the top of this file for more info.
  end


end
