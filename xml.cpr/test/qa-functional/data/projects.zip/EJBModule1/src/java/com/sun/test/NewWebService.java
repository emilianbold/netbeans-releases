/*
 * NewWebService.java
 *
 * Created on March 18, 2007, 10:31 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package com.sun.test;

import javax.ejb.Stateless;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

/**
 *
 * @author Hong
 */

@Stateless()
@WebService()
public class NewWebService {
    /**
     * Web service operation
     */
    @WebMethod
    public String operation(@WebParam(name = "name") String name) {
        // TODO implement operation 
        return "Hello "+name;
    }
    
}
