

package captest;

public class CompileCapabilityTestFile {
    public static void main (String argv[]) {
        System.out.println("test");
        Class clazz = aa.testFsXX.class;
        System.out.println(clazz);
    }
}
