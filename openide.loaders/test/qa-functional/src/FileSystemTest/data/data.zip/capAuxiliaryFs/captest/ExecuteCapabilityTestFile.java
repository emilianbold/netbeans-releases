package captest;

import java.net.*;
import java.io.*;


public class ExecuteCapabilityTestFile {
    public static void main (String argv[]) {
      try {
          String str = argv[0];
         int port = Integer.parseInt(str);
        System.out.println("test");
        Socket socket = null;
        PrintStream ps = null;
        try {
            socket = new Socket ("localhost",port);
            ps = new PrintStream(socket.getOutputStream());
            Class clazz = Class.forName("aa.testFsXX");
            System.out.println(clazz);
            ps.println("class found");
        } catch (ClassNotFoundException e ) {
            ps.println ("no class found");
        }
       socket.close();
      } catch(IOException ioe) {
       ioe.printStackTrace();
      }
    }
}
