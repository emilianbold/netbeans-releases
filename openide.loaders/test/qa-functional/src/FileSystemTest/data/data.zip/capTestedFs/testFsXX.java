/*
 * testFsXX.java
 *
 * Created on July 17, 2002, 5:14 PM
 */

/**
 *
 * @author  pz97949
 */
public class testFsXX {
    
    /** Creates a new instance of testFsXX */
    public testFsXX() {
    }
    
}
