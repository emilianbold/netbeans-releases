# cdnJS Script Repository

The repository mirroring all scripts on ajax.cdnjs.com

Want your script included? Easy.

1. Fork this repository
2. Add your file (following the conventions of this repository)
3. Run your package.json through a [JSON Validator](http://jsonlint.com/)
4. Send us a pull request.
