#include "unused.h"
#include "unresolved.h"

int foo() {
    
}
