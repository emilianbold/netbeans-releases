#ifndef UNUSED_H
#define	UNUSED_H

#ifdef	__cplusplus
extern "C" {
#endif

    int foo();


#ifdef	__cplusplus
}
#endif

#endif	/* UNUSED_H */

