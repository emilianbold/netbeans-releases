#ifndef IMPLCLASS_H
#define	IMPLCLASS_H
#include "BaseClass.h"

class ImplClass : public BaseClass {
public:
    ImplClass();
    virtual ~ImplClass();
    int id();
private:

};

#endif	/* IMPLCLASS_H */

