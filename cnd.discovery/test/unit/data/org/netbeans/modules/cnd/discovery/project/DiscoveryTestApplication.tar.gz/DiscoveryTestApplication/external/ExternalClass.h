#ifndef EXTERNALCLASS_H
#define	EXTERNALCLASS_H
#include "BaseClass.h"

class ExternalClass : public BaseClass {
public:
    ExternalClass();
    virtual ~ExternalClass();
    virtual int id();
private:

};

#endif	/* EXTERNALCLASS_H */

