/* 
 * File:   BaseClass.h
 * Author: as204739
 *
 * Created on January 24, 2011, 2:18 PM
 */

#ifndef BASECLASS_H
#define	BASECLASS_H

class BaseClass {
public:
    BaseClass();
    virtual ~BaseClass();
    virtual int id() = 0;
private:

};

#endif	/* BASECLASS_H */

