#include "ImplClass.h"

ImplClass::ImplClass() {
}

ImplClass::~ImplClass() {
}

int ImplClass::id() {
    return 8;
}
