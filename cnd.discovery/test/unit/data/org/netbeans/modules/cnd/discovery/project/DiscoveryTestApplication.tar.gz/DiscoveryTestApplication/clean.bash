#!/bin/bash
echo "Start Clean command in " `pwd`
cd src
./configure
make -f Makefile1 clean
