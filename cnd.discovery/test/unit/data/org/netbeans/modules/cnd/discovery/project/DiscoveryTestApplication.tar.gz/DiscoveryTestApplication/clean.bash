#!/bin/bash
echo "Start Clean command in " `pwd`
cd src
echo "cd " `pwd`
./configure
make -f Makefile clean
