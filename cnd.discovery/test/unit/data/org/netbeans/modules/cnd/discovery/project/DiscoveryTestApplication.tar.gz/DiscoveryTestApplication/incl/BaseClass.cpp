#include "BaseClass.h"

BaseClass::BaseClass() {
}

BaseClass::~BaseClass() {
}

