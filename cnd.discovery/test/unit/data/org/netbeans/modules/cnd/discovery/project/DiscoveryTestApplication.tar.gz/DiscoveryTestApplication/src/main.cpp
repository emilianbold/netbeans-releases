#include <cstdlib>
#include "config.h"
#include QUOTE(IMPL,h)
#include EXT

using namespace std;
QQ
    int ret[] = {-1};
    int foo(){
        return 1;
    }
QQ_CLOSE

using namespace USE;

int MA(int argc, char** argv) {
    ImplClass impl;
    ExternalClass ext;
#ifdef HAVE_CONFIG
    return impl.id()+ext.id()+RET(0)+FOO;
#else
    return qq::in::ret;
#endif
}

