#include <cstdlib>
#include "config.h"
#include "ImplClass.h"
#include "ExternalClass.h"

using namespace std;

/*
 * 
 */
int main(int argc, char** argv) {
    ImplClass impl;
    ExternalClass ext;
#ifdef HAVE_CONFIG
    return impl.id()+ext.id();
#else
    return -1;
#endif
}

