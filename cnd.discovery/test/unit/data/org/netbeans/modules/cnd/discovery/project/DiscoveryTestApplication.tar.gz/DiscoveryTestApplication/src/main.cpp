#include <cstdlib>
#include "config.h"
#include QUOTE(IMPL,h)
#include EXT

using namespace std;
QQ
    int ret = -1;
QQ_CLOSE

int MA(int argc, char** argv) {
    ImplClass impl;
    ExternalClass ext;
#ifdef HAVE_CONFIG
    return impl.id()+ext.id()+qq::ret;
#else
    return qq::ret;
#endif
}

