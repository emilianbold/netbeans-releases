#include "ExternalClass.h"

ExternalClass::ExternalClass() {
}

ExternalClass::~ExternalClass() {
}

int ExternalClass::id() {
    return 4;
}
