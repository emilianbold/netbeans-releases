#!/bin/bash
echo "Start Build command in " `pwd`
cd src
echo "cd " `pwd`
make -f Makefile all
