#!/bin/bash
echo "Start Build command in " `pwd`
cd src
make -f Makefile1 all
