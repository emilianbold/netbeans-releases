
package demo

class DisplayProvider {

    def text = "Hello from Groovy!"

}

