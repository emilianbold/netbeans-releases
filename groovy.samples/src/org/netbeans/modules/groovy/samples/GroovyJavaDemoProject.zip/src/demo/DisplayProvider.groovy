
package demo

class Display {

    def text = "Hello from Groovy!"

}

