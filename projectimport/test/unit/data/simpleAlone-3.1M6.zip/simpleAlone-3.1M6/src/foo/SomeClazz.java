package foo;

public class SomeClazz {

}
