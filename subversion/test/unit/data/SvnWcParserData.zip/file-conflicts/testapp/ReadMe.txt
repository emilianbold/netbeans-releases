So this is what we need
==================================
No, it's not ascii art
<<<<<<< .mine
Oomba baroomba!
=======
It's all right now.
==================================
In fact it's a gas.
>>>>>>> .r5


Wait a minute...