<<<<<<< .mine
This is a file which has important items.
=======
This is a text file which has important details.
>>>>>>> .r18

Woo hoo, look at it work!
