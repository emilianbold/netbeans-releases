/*
 * AnotherMain.java
 *
 * Created on 12 April 2006, 20:36
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package testapp;

/**
 * Some very important comments for this class
 *
 * @author Ed Hillmann
 */
public class AnotherMain {

    /** Creates a new instance of Main */
    public AnotherMain() {
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
    }

}
