package annotations;

public enum TestEnum {
    
    X, Y;
    
}
