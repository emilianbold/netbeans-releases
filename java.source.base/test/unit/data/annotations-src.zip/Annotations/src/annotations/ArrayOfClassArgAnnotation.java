package annotations;

public @interface ArrayOfClassArgAnnotation {

    public Class<?>[] value();
    
}
