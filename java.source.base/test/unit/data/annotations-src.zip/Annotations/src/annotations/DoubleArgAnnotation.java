package annotations;


public @interface DoubleArgAnnotation {
    
    double value();
    
}
