package annotations;


public @interface OptionalArgsAnnotation {
    
    String value() default "<default>";
    
    TestEnum something() default TestEnum.X;
    
}
