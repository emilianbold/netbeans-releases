package annotations;


public @interface ArrayOfStringArgAnnotation {
    
    String[] value();
    
}
