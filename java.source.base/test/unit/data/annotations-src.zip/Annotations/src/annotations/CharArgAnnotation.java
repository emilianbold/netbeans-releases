package annotations;


public @interface CharArgAnnotation {
    
    char value();
    
}
