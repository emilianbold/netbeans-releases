package annotations;

public class RequestProcessor {

    public RequestProcessor() {
    }

    public final class Task {
        Task(RequestProcessor r0, Runnable r1) {}
        Task(RequestProcessor r0, Runnable r1, int i) {};
    }
    
}
