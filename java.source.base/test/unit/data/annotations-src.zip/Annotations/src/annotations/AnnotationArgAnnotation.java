package annotations;


public @interface AnnotationArgAnnotation {
    
    ArrayOfStringArgAnnotation value();
    
}
