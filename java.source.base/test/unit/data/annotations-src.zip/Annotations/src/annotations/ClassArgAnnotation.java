package annotations;

public @interface ClassArgAnnotation {

    public Class<?> value();
    
}
