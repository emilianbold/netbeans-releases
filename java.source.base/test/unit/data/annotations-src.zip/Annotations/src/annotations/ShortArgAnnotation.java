package annotations;


public @interface ShortArgAnnotation {
    
    short value();
    
}
