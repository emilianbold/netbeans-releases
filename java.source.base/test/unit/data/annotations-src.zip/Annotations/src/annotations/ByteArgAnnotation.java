package annotations;


public @interface ByteArgAnnotation {
    
    byte value();
    
}
