package annotations;


public @interface ArrayOfEnumArgAnnotation {
    
    TestEnum[] value();
    
}
