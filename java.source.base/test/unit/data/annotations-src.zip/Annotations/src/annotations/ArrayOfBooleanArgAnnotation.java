package annotations;


public @interface ArrayOfBooleanArgAnnotation {
    
    boolean[] value();
    
}
