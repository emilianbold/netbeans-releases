package annotations;


public @interface EnumArgAnnotation {
    
    TestEnum value();
    
}
