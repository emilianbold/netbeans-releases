package usages;

import annotations.AnnotationArgAnnotation;
import annotations.ArrayOfStringArgAnnotation;
import annotations.ClassArgAnnotation;
import annotations.EnumArgAnnotation;
import annotations.NoArgAnnotation;
import annotations.TestEnum;
import java.util.List;

@NoArgAnnotation
@AnnotationArgAnnotation(@ArrayOfStringArgAnnotation())
@EnumArgAnnotation(TestEnum.X)
@ClassArgAnnotation(List.class)
public class ClassAnnotations {

}
