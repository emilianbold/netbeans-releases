package usages;

import annotations.ArrayOfAnnotationArgAnnotation;
import annotations.ArrayOfClassArgAnnotation;
import annotations.ArrayOfEnumArgAnnotation;
import annotations.ArrayOfStringArgAnnotation;
import annotations.TestEnum;
import java.util.List;

public class FieldArrayAnnotations {
    @ArrayOfAnnotationArgAnnotation(@ArrayOfStringArgAnnotation())
    @ArrayOfEnumArgAnnotation({TestEnum.X})
    @ArrayOfClassArgAnnotation({List.class})
    public static int test;
}
