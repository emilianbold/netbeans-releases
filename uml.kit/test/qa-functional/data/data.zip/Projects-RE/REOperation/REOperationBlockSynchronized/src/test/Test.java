/*
 * Test.java
 *
 * Created on May 23, 2006, 1:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package test;
import java.util.Iterator;
import java.util.LinkedList;

/**
 *
 * @author sunflower@netbeans.org
 */

public class Test {
    
    private Object data1;
    private Object data2;
    
    public void testBlockSynchronized1(Object data1, Object data2){
        synchronized (this){
            setData1(data1);
            setData2(data1);
        }
    }
    
    
    public void setData1(Object data1) {
        this.data1 = data1;
    }
    
    public void setData2(Object data2) {
        this.data2 = data2;
    }
    
    
    
}
