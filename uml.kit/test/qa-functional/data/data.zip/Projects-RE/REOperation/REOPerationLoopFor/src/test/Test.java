/*
 * Test.java
 *
 * Created on May 23, 2006, 1:04 PM
 *
 */

package test;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

/**
 *
 * @author sunflower@netbeans.org
 */

public class Test {
   
  public void testLoopFor1(){
        
        double a[] = { 1 , 2, 3 , 4, 5 } ;
        double b[] = { 5 , 4, 3 , 2, 1 } ;
        double c[] = { 0 , 0, 0 , 0, 0 } ;
        
        for( int i = 0; i < a.length; i++ ){
            c[i] = a[i] + b[i];
        }
        
    }
    
    public void testLoopFor2(){
        
        Object a[] = { new Object()} ;
        Object b[] = { new Object()} ;
        
        String c[] = { "" } ;
        
        for( int i = 0; i < c.length; i++ ){
            c[i] = a[i].toString().concat( b[i].toString() );
        }
        
    }
    
    public void testLoopFor3(){
        
        List list1 = new LinkedList();
        List list2 = new Vector();
        
        for( int i = 0; i < list1.size(); i++ ){
            list2.add(i, list1.get(i));
        }
    }
    
    
    
    
    public void testLoopFor4(){
        
        List<Boolean> list = new LinkedList<Boolean>();
        String res = "".trim();
        
        for( Boolean bool : list ){
            res.concat( bool.toString() );
        }
        
    }
    
    
    public void testLoopFor5(){
        List list = new LinkedList();
        String res = "";
        
        for( Iterator iter = list.iterator(); iter.hasNext(); ){
            res.concat( iter.next().toString() );
        }
    }
    
    
    public void testLoopFor6(){
        
        List list = new LinkedList();
        Object[] array = list.toArray();
        Iterator iter = list.iterator();
        
        loop_a: for( int i = 0; i < list.size(); i++ ){
            loop_b: for( int j = 0; j < array.length; j++ ){
                loop_c: for( ; iter.hasNext(); ){
                    if (iter.next().equals(array[j])){
                        continue loop_a;
                    }
                }
                loop_d: for( Object obj : list){
                    if (obj.equals(list.get(i))){
                        break loop_b;
                    }
                }
            }
        }
    }
        
    
}
