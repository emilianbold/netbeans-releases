/*
 * Test.java
 *
 * Created on May 23, 2006, 1:04 PM
 *
 */

package test;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.Vector;

/**
 *
 * @author sunflower@netbeans.org
 */

public class Test {
    
    public void testBlockTryCatch1() throws Exception{
        try {
            Thread.sleep(1000);
        }catch(InterruptedException e){
            throw new Exception(e);
        }finally{
            Thread.currentThread().getName();
        }
    }
    
}
