/*
 * Test.java
 *
 * Created on May 23, 2006, 1:04 PM
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */

package test;

import java.lang.reflect.Method;
import java.util.LinkedList;
import java.util.List;

/**
 *
 * @author as153250
 */

public class Test {
    
    /** Creates a new instance of Test */
    public Test() {
    }

    
    public void testConditionIf1(){
        
        int a = 10;
        int b = 20;
        
        if ( a > b ){
            a +=1;
        }else{
            b +=1;
        }
        
        if ( ( a + b ) != ( a * b ) ){
            a -=1;
        }else{
            b -=1;
        }
    }
    
    public void testConditionIf2(){
        Method[] method = getClass().getMethods();
        if ( method != null && method.length > 0){
            System.out.println(method[0].getName());
        }else{
            System.out.println(getClass().getName());
        }
    }
    
    
    public void testConditionIf3(){
        
        List list = new LinkedList();
        Integer count = new Integer(0);
        
        
        if( list != null){
            if( 0 < list.size()  && list.size() < 3) {
                if( list.get(0) == list.get(1)){
                    count = new Integer(1);
                }else if (list.get(0) == list.get(2)){
                    count = new Integer(2);
                }else if (list.get(1) == list.get(2)){
                    count = new Integer(3);
                }else{
                    count = new Integer(4);
                }
            }else {
                if  (0 < list.size()  && list.size() < 2){
                    if( list.get(0) == list.get(1)){
                        count = new Integer(5);
                    }
                }
            }
        }else{
            count = new Integer(6);
        }
    }
    
    
    
    public void testConditionIf4(){
        
        boolean a = true;
        boolean b = false;
        
        if ( a & b ){
            a = !b;
        }else{
            b = !a;
        }
        
        if ( ! ( a & b ) || ( !a ^ !b )){
            a = !b;
        }else{
            b = !a;
        }
        
        
    }
    
    
    
}
