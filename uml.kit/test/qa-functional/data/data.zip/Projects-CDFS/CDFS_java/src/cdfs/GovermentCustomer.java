
package cdfs;

public class GovermentCustomer extends Customer{
    
    public boolean acceptsPresents = false;    
}
