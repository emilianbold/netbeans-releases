
package cdfs;

public class CustomerAccount {
    
    /** Creates a new instance of CustomerAccount */
    public CustomerAccount() {
    }
    
}
