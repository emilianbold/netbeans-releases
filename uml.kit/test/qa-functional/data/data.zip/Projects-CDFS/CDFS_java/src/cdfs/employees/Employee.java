
package cdfs.employees;

public class Employee {
    
    public Employee() {
    }
    
}
