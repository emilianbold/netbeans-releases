

package sqd;

import sqd.Order.IDGenerator;
import sqd.employees.Employee;

public class Customer {
    
    /** Creates a new instance of Customer */
    public Customer() {
    }
    
    public String getCustomerName() {
        return "";
    }    
    
    public void setCustomerName(String val) {
    }
    
    public Address[] getAddresses() {
        return addresses;
    }
    
    public void setAddresses(Address[] val) {
    }
    
    private String customerName = "";
    
    private Address[] addresses = null;
    
    private CustomerAccount mainAccount = new CustomerAccount();
    
    private Employee responcibleEmpl = new Employee();
    
    public CustomerAccount getMainAccount() {
        return mainAccount;
    }
    
        
    public void setMainAccount(CustomerAccount m) {
        this.mainAccount = m;
    }
    
    public Employee getResponcibleEmpl() {
        return responcibleEmpl;
    }    
    
    public void setResponcibleEmpl(Employee val) {
        this.responcibleEmpl = val;
    }
    
    public void process(){
        Order ord = new Order();
        Order.IDGenerator gen = ord.getGenerator();
        gen.getID();
        gen = ord.getGenerator();
        gen.getID();
        
    }
    
}
