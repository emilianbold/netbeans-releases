
package sqd;

public class GovermentCustomer extends Customer{
    
    public boolean acceptsPresents = false;    
}
