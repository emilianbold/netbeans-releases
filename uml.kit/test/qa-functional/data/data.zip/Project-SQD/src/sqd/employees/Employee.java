
package sqd.employees;

public class Employee {
    
    public Employee() {
    }
    
}
