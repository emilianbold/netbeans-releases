
package sqd;

public class Address {
    
    /** Creates a new instance of Address */
    public Address() {
    }
    
    private String addressInfo = "";
    
    public String getAddressInfo() {
        return addressInfo;
    }
    
    public void setAddressInfo(String a) {
        this.addressInfo = a;
    }   
    
}
