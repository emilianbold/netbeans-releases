
package sqd;

public class Order {
    
   private String id = new Order.IDGenerator().getID();
   
   private Order.IDGenerator generator = new Order.IDGenerator();
   
   public IDGenerator getGenerator() {
       return generator;
   }
   
   public void setGenerator(IDGenerator val) {
       this.generator = val;
   }
   
   private Order.OrderItem[] items = new Order.OrderItem[3];
   
   
   
   public class IDGenerator{
       public String getID(){
           return "";
       }
   }
   
   
     
    public class OrderItem{
       public String ItemInfo(){
           return "";
       }
   }
    
}
