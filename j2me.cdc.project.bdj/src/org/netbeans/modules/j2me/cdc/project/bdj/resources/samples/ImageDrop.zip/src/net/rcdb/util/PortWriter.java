package net.rcdb.util;

import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;
import java.net.ServerSocket;
import java.net.Socket;

public class PortWriter {
   private BufferedWriter  writer;
   private Thread          thread;

   public PortWriter(final int port) {
      thread = new Thread(new Runnable() {
         public void run() {
            try {
               ServerSocket srv = new ServerSocket(port);
               Socket socket = srv.accept();
               writer = new BufferedWriter(
                     new OutputStreamWriter(socket.getOutputStream()));
               println("hello");
           } catch (IOException e) {
              e.printStackTrace();
           }
         }
      }, "PortWriter");
      thread.start();
   }

   public void close() {
      if (writer != null) {
         try {
            writer.flush();
            writer.close();
         } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
      if (thread != null) {
         thread.interrupt();
      }
   }
   
   public void println() {
      if (writer != null) {
         try {
            writer.write("\n");
            writer.flush();
         } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
   }
   
   public void println(String text) {
      if (writer != null) {
         try {
            if (text != null) {
               writer.write(text);
            }
            writer.write("\n");
            writer.flush();
         } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
         }
      }
   }
}
