package net.rcdb.imagedrop;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.dvb.test.DVBTest;
import org.dvb.ui.FontFactory;
import org.dvb.ui.FontFormatException;
import org.dvb.ui.FontNotAvailableException;

public class ListView extends View {
   private boolean   traceEnabled = true;
   
   private boolean   showInvisibles = false;
   
   private List      list = new ArrayList();

   private int       fontH = 30;
   private int       lineH = (int) (1.3 * fontH);
   private Font      font20;

   private static final long serialVersionUID = 1L;
   
   
   public ListView() {
      trace("ListView()");
      font20 = loadFont("HelveticaNeue", fontH);
      animating = false;   // for now
   }
   
//   public boolean isAnimating() {
//      return false;
//   }

   public void add(String item) {
      synchronized (list) {
         list.add(0, item);
      }
   }
   
   public void paint(Graphics g) {
      if (this.isOpaque()) {
         g.setColor(Color.darkGray);
         g.fillRect(0, 0, this.getWidth(), this.getHeight());
      }
      
      g.setFont(font20);
      g.setColor(Color.white);
      int y = lineH;
      synchronized (list) {
         for (Iterator iterator = list.iterator(); iterator.hasNext();) {
            String item = (String) iterator.next();
            g.drawString(item, 0, y);
            y += lineH;
         }
      }
      
      // invisibles
      if (showInvisibles) {
         int lineCount = this.getHeight() / lineH;
         g.setColor(Color.lightGray);
         for (int i = 1; i <= lineCount; i++) {
            y = i * lineH;
            g.drawLine(0, y, this.getWidth(), y);
         }
      }
   }
   
   public void showInvisibles(boolean b) {
      this.showInvisibles = b;
   }
   
   public boolean invisiblesShowing() {
      return this.showInvisibles;
   }

   // TODO  move to util package
   public static Font loadFont(String fontName, int size) {
      Font font = null;
      try {
         FontFactory fontFactory = new FontFactory();
         font = fontFactory.createFont(fontName, Font.PLAIN, size);
      } catch (FontFormatException e) {
      } catch (IOException e) {
      } catch (FontNotAvailableException e) {
      }
      // check that the font was created
      if (font == null) {
         // use the default font as a backup
         font = new Font("default", Font.PLAIN, size);
      }
      return font;
   }

   private void trace(String str) {
      if (traceEnabled) {
         try {
            DVBTest.log(Thread.currentThread().getName(), str);
            System.out.println(System.currentTimeMillis() + " - " + str);
         } catch (IOException e) {
            e.printStackTrace();
         }
      }
   }
}
