package net.rcdb.imagedrop;

import java.awt.Color;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Image;
import java.awt.Rectangle;

public class ImageView extends View {
   private boolean         showInvisibles = false;
   
   private boolean         isClosing = false;
   
   private Image           currentImage;
   private Image           outgoingImage;
   
   private int             marginY = 200;
   private int             imageFrameX = 0;
   private int             imageFrameY;
   private int             imageFrameW;
   private int             imageFrameH;

   private Rectangle       currentBox = new Rectangle();
   private Rectangle       outgoingBox = new Rectangle();
   
   private Integrator      incomingY = new Integrator();
   {
      incomingY.attraction = 0.1f;
//      incomingY.damping = 0.6f;     // higher damping => less drag
      incomingY.damping = 0.8f;     // higher damping => less drag
   }
   private Integrator      outgoingY = new Integrator();
//   {
//      outgoingY.attraction = 0.4f;
//   }
   static final float      EPSILON = 1f; // default

   private Font            font;

   private static final long serialVersionUID = 1L;

   
   public ImageView(Font font) {
      this.font = font;
   }
   
   public synchronized void close() {
      isClosing = true;
      if (currentImage != null) {
         currentImage.flush();
      }
      if (outgoingImage != null) {
         outgoingImage.flush();
      }
   }
   
   public boolean isAnimating() {
      return !(incomingY.atTarget(EPSILON) && outgoingY.atTarget(EPSILON));
   }

   public void addImage(Image newImage) {
      if (this.currentImage != null) {
         outgoingY.set(currentBox.y);
         outgoingY.target(this.getHeight());
         outgoingBox.setBounds(currentBox);
      }
      
      if (outgoingImage != null) {
         outgoingImage.flush();
      }
      this.outgoingImage = this.currentImage;
      this.currentImage = newImage;
      
      currentBox = placeImage(newImage, currentBox);
      incomingY.set(-currentBox.height);
      incomingY.target(currentBox.y);
   }
   
   public synchronized void paint(Graphics g) {
      if (isClosing) return;
      
      updateDimensions();

      incomingY.update();
      outgoingY.update();
      
      animating = !(incomingY.atTarget() || outgoingY.atTarget());
      
      g.setFont(font);
      
      if (this.isOpaque()) {
         g.setColor(Color.gray);
         g.fillRect(0, 0, this.getWidth(), this.getHeight());
      }
      
      if (outgoingImage != null) {
         outgoingBox.y = (int) outgoingY.value;
         if (outgoingBox.y < this.getHeight()) {
            g.drawImage(outgoingImage, outgoingBox.x, outgoingBox.y, outgoingBox.x + outgoingBox.width, outgoingBox.y + outgoingBox.height,
                  0, 0, outgoingImage.getWidth(null), outgoingImage.getHeight(null), null);
//            g.setColor(Color.red);
//            g.drawString("outgoing", currentBox.x + 100, currentBox.y + 100);
         } else {
            outgoingImage = null;
            outgoingY.noTarget();
         }
      }

      if (currentImage != null) {
         currentBox.y = (int) incomingY.value;
         
         g.drawImage(currentImage, currentBox.x, currentBox.y, currentBox.x + currentBox.width, currentBox.y + currentBox.height,
               0, 0, currentImage.getWidth(null), currentImage.getHeight(null), null);
//         g.setColor(Color.green);
//         g.drawString("current", currentBox.x + 100, currentBox.y + 100);
      }

      // invisibles
      if (showInvisibles) {
         g.setColor(Color.lightGray);                                            // image frame guides
         g.drawLine(0, imageFrameY, this.getWidth() - 1, imageFrameY);
         g.drawLine(0, imageFrameY + imageFrameH - 1, this.getWidth() - 1, imageFrameY + imageFrameH - 1);
         g.setColor(Color.orange);                                               // sized image guides
         g.drawLine(currentBox.x, 0, currentBox.x, this.getHeight());
         g.drawLine(currentBox.x + currentBox.width - 1, 0, currentBox.x + currentBox.width - 1, this.getHeight() - 1);
         g.drawLine(0, currentBox.y, this.getWidth() - 1, currentBox.y);
         g.drawLine(0, currentBox.y + currentBox.height - 1, this.getWidth() - 1, currentBox.y + currentBox.height - 1);
         g.setColor(Color.green);
         g.drawRect(0, 0, this.getWidth() - 1, this.getHeight() - 1);            // component bounds
         g.drawRect(imageFrameX, imageFrameW, imageFrameW - 1, imageFrameH - 1); // image frame
         g.drawRect(currentBox.x, currentBox.y, currentBox.width - 1, currentBox.height - 1);                // scaled image
      }
   }
   
   private void updateDimensions() {
      imageFrameX = 0;
      imageFrameY = marginY;
      imageFrameW = this.getWidth();
      imageFrameH = this.getHeight() - 2 * marginY;
   }
   
   // TODOHI   center if image smaller than imageFrame, otherwise, size to fit
   private Rectangle placeImage(Image image, Rectangle box) {
      double frameAspect = imageFrameW / (double) imageFrameH;
      double imageAspect = image.getWidth(null) / (double) image.getHeight(null);
      if (imageAspect >= frameAspect) {
         // image wider than frame
         box.x = 0;
         box.width = imageFrameW;
         double scale = imageFrameW / (double) image.getWidth(null);
         int imageFrameCenterY = imageFrameY + imageFrameH / 2;
         box.height = (int) (scale * image.getHeight(null));
         box.y = imageFrameCenterY - box.height / 2;
      } else {
         // image taller than frame
         box.y = imageFrameY;
         box.height = imageFrameH;
         double scale = imageFrameH / (double) image.getHeight(null);
         int imageFrameCenterX = imageFrameX + imageFrameW / 2;
         box.width = (int) (scale * image.getWidth(null));
         box.x = imageFrameCenterX - box.width / 2;
      }
      return box;
   }
   
   public void showInvisibles(boolean b) {
      this.showInvisibles = b;
   }
   
   public boolean invisiblesShowing() {
      return this.showInvisibles;
   }
}
