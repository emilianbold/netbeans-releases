package net.rcdb.imagedrop;

public class Integrator {
   final float          DAMPING = 0.5f;
   final float          ATTRACTION = 0.2f;
   static final float   EPSILON = 0.001f; // default

   float value;
   float vel;
   float accel;
   float force;
   float mass = 1;

   float damping = DAMPING;
   float attraction = ATTRACTION;
   boolean targeting;
   float target;


   Integrator() { }

   Integrator(float value) {
      this.value = value;
   }

   Integrator(float value, float damping, float attraction) {
      this.value = value;
      this.damping = damping;
      this.attraction = attraction;
   }

   void set(float v) {
      value = v;
   }

   void update() {
      if (targeting) {
         force += attraction * (target - value);      
      }

      accel = force / mass;
      vel = (vel + accel) * damping;
      value += vel;

      force = 0;
   }

   void target(float t) {
      targeting = true;
      target = t;
   }

   void noTarget() {
      targeting = false;
   }
   
   boolean atTarget() {
      return atTarget(EPSILON);
   }
   
   boolean atTarget(float epsilon) {
      return Math.abs(value - target) <= epsilon;
   }
}
