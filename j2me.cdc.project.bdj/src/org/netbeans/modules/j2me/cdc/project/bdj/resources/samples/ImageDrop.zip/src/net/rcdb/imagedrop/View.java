package net.rcdb.imagedrop;

import java.awt.Component;

public abstract class View extends Component {
   protected boolean    animating = false;
   
   public boolean isAnimating() {
      return animating;
   }
}
