package net.rcdb.imagedrop;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Component;
import java.awt.Font;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Toolkit;
import java.awt.image.BufferedImage;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;
import java.util.Timer;
import java.util.TimerTask;

import javax.tv.xlet.Xlet;
import javax.tv.xlet.XletContext;
import javax.tv.xlet.XletStateChangeException;

import net.rcdb.util.PortWriter;

import org.dvb.event.EventManager;
import org.dvb.event.UserEvent;
import org.dvb.event.UserEventListener;
import org.dvb.event.UserEventRepository;
import org.dvb.test.DVBTest;
import org.dvb.ui.FontFactory;
import org.dvb.ui.FontFormatException;
import org.dvb.ui.FontNotAvailableException;
import org.havi.ui.HSceneFactory;
import org.havi.ui.HScene;
//import org.havi.ui.HState;
//import org.havi.ui.HStaticText;
import org.havi.ui.HTextButton;
import org.havi.ui.HVisible;
import org.havi.ui.event.HRcEvent;

/*
 * Threads
 * -----------------------------------------------
 * xlet - manages xlet lifecyle
 * fetch - polls server for new images
 * animation - drawing loop for the incoming images
 */
/**
 * 
 */
public class ImageDrop implements Xlet, Runnable {
   private boolean               traceEnabled = true;
   private PortWriter            printPort;

   private UserEventRepository   rep;
   private UserEventListener     rcListener;
   private XletContext           xletcontext;

   private String                logoImagePath = "/data/image_drop.jpg";
// private Image                 logoImage;

   // TODO  hard-coded for user 1000 for now
   private int                   userId = 1001;

   private int                   fps = 30;

   private int                   titleSafeX  = 288;   // title safe, 15% of 1920
   private int                   titleSafeY  = 162;   // title safe, 15% of 1080
   private int                   actionSafeX = 135;   // action safe, 7% of 1920
// private int                   actionSafeY = 76;    // action safe, 7% of 1080

   /**
    * URLs of known images, i.e. either downloaded or queued to download.
    */
   private HashSet               imageUrls = new HashSet();
   /**
    * Queue of URLs for images to download.
    */
   private List                  imagesToFetch = new LinkedList();
   /**
    * List of images already downloaded.
    */
   private List                  images = new ArrayList();
   /**
    * List of newly fetched images that haven't yet been displayed.
    */
// // TODOHI   newImages necessary?
// private List                  newImages = new LinkedList();

   // TODO     may need separate host and port strings
   // TODOHI   set reslistHost from an xlet parameter defined externally?
// private String                reslistHost    = "localhost:8080";
// private String                reslistHost    = "192.168.1.103:8080";
// private String                reslistServlet = "reslist/getList";

// private String                reslistHost    = "rcdb.net:8180";
// private String                reslistServlet = "getList/getList";
// private String                reslistQuery   = "?id=";

// http://br01.network.com:8080/sandbox/userfiles.htm?id=1000
   private String                reslistHost    = "br01.network.com:8080";
   private String                reslistServlet = "sandbox/userfiles.htm";
// private String                reslistQuery   = "?id=";
   private String                reslistQuery   = "?name=";


   private Thread                imageFetchThread;

   private HScene                scene;
   private BufferedImage         buffer;
   private Graphics2D            bg;
// private static HStaticText    status;

   private Object                monitor = new Object();    // syncs stop() and run()
   private boolean               stopRequested = false;
   // TODO  combine with stopRequested?
   private boolean               closing = false;

   private Font                  font26;
   private Font                  font18;
// private Font                  font100;
   private Font                  traceFont;

// private int                   boxH = 70;     // height of HAVI widgets

   private Color                 clearColor = new Color(0, 0, 0, 0);    // fully transparent
   private static final Color    POPUP_PINK = new Color(255, 80, 80);

   private ImageView             imageView;
   private ListView              listView;

   private Animation             animation;


   private void draw() {
      // TODOHI   fix
//    if (false) {
      if (!isAnyViewAnimating()) {
         return;
      }
//    }

      if (bg == null) {
         buffer = scene.getGraphicsConfiguration().createCompatibleImage(scene.getWidth(), scene.getHeight());
         bg = (Graphics2D) buffer.getGraphics();
      }

      // clear bg
      bg.setComposite(AlphaComposite.Src);
      bg.setColor(clearColor);
      bg.fillRect(0, 0, buffer.getWidth(), buffer.getHeight());

      paintComponents(bg);

      // exit reminder
      bg.setColor(POPUP_PINK);
      int y = 933;
      bg.drawRect(1470, y, 20, 20);
      bg.drawRect(1471, y+1, 18, 18);
      bg.setColor(Color.lightGray);
      bg.setFont(font26);
      bg.drawString("popup-menu to exit", 1500, 950);
      
//    // heartbeat
//    bg.setFont(font18);
//    bg.setColor(Color.white);
//    bg.drawString(System.currentTimeMillis() + "", 1250, 90);

      // copy to scene
      Graphics2D g = (Graphics2D) scene.getGraphics();
      g.setComposite(AlphaComposite.Src);
      g.drawImage(buffer, 0, 0, null);

      // notify the platform
      Toolkit.getDefaultToolkit().sync();
   }

   /**
    * @return  true if any Component that is a View is animating
    */
   private boolean isAnyViewAnimating() {
      Component[] components = scene.getComponents();
      for (int i = 0; i < components.length; i++) {
         Component c = components[i];
         if (c instanceof View) {
            if (((View) c).isAnimating()) {
               return true;
            }
         }
      }
      return false;
   }

   private void paintComponents(Graphics2D g) {
      Component[] components = scene.getComponents();
      for (int i = 0; i < components.length; i++) {
         Component c = components[i];
         Graphics g2 = g.create(c.getX(), c.getY(), c.getWidth(), c.getHeight());
         c.paint(g2);
         g2.dispose();
      }
   }

   public void initXlet(XletContext xletcontext) throws XletStateChangeException {
      trace("initXlet");
      this.xletcontext = xletcontext;
      this.stopRequested = false;
   }

   public void startXlet() throws XletStateChangeException {
      trace("startXlet");
      new Thread(this).start();
   }

   public void pauseXlet() {
      stop();
   }

   public void destroyXlet(boolean flag) throws XletStateChangeException {
      stop();
   }

   /*
    * Called by "exit button", whatever that is
    */
   private void close() {
      closeRC();
      imageView.close();
      stop();
//    xletcontext.notifyDestroyed();
   }

   private void initRC() {
      rep = new UserEventRepository("rep");
      rep.addAllNumericKeys();
      rep.addAllArrowKeys();
      rep.addKey(HRcEvent.VK_ENTER);
      rep.addKey(HRcEvent.VK_SPACE);
      rep.addKey(org.bluray.ui.event.HRcEvent.VK_POPUP_MENU);

      rcListener = new UserEventListener() {
         public void userEventReceived(UserEvent userevent) {
            if (userevent.getType() == HRcEvent.KEY_PRESSED) {
               handleKeyPress(userevent.getCode());
            }
         }
      };
      EventManager.getInstance().addUserEventListener(rcListener, rep);
   }

   private void closeRC() {
      EventManager.getInstance().removeUserEventListener(rcListener);
      rep.removeAllNumericKeys();
      rep.removeAllArrowKeys();
      rep.removeKey(HRcEvent.VK_ENTER);
      rep.removeKey(HRcEvent.VK_SPACE);
      rep.removeKey(org.bluray.ui.event.HRcEvent.VK_POPUP_MENU);
   }

   private void handleKeyPress(int keycode) {
      trace("handleKeyPres() - keycode: " + keycode);

      switch (keycode) {
         case HRcEvent.VK_1:
            boolean show = !this.imageView.invisiblesShowing();
            this.imageView.showInvisibles(show);
            this.listView.showInvisibles(show);
            break;
         case org.bluray.ui.event.HRcEvent.VK_POPUP_MENU:
            close();
            break;
      }
   }

   protected HTextButton createButton(String text, int x, int y, int width, int height) {
      HTextButton button = new HTextButton(text, x, y, width, height);
      button.setForeground(Color.blue);
      button.setBackgroundMode(HVisible.BACKGROUND_FILL);
      button.setBackground(Color.white);
      button.setHorizontalAlignment(HTextButton.HALIGN_CENTER);
      button.setFont(font18);
      button.setBackground(new Color(255, 255, 255, 50));
      scene.add(button);
      return button;
   }

   private void stop() {
      // end the image fetch thread
      closing = true;
      synchronized (imagesToFetch) {
         // in case the image fetch thread is waiting for new images, wake it
         imagesToFetch.notify();
      }

      // end the animation thread
      this.animation.close();

      closePrintPort();

      // end the xlet thread
      synchronized (monitor) {
         this.stopRequested = true;
         monitor.notifyAll();
      }
   }

   protected void openPrintPort(int port) {
      closePrintPort();
      printPort = new PortWriter(port);
   }

   protected void closePrintPort() {
      if (printPort != null) {
         printPort.close();
         printPort = null;
      }
   }

   public void println(String line) {
      if (line == null) return;
      if (printPort != null) {
         printPort.println(line);
      }
   }


   public void run() {
      openPrintPort(55556);

      font26 = loadFont("HelveticaNeue", 26);
      font18 = loadFont("Vera Sans Bold", 18);
//    font100 = loadFont("HelveticaNeue", 100);
      setup();
      initImageFetcher();

      Image logoImage = loadImage(logoImagePath);
      handleNewImage(logoImage, "Image Drop");

      synchronized (monitor) {
         while (!this.stopRequested) {
            try {
               monitor.wait();
            } catch (InterruptedException e) {
               // TODO Auto-generated catch block
               e.printStackTrace();
            }
         }
      }

      destroyScene();

      xletcontext.notifyDestroyed();
   }

   private void initImageFetcher() {
      // set up a repeating task to check for new images
      TimerTask pollForNewImages = new TimerTask() {
         public void run() {
            trace("pollForNewImages - run()");
            checkForNewImages();
         }
      };
      Timer poller = new Timer();
      poller.schedule(pollForNewImages, 2000, 1000);

      // set up a thread to pop URLs from imagesToFetch, then fetch the
      // images and add them to the images list
      imageFetchThread = new Thread(new Runnable() {
         public void run() {
            while (!closing) {
               String url = null;
               synchronized (imagesToFetch) {
                  if (imagesToFetch.size() > 0) {
                     url = (String) imagesToFetch.remove(0);
                     if (url != null) {
                        Image img = fetchImage(url);
                        // TODO  could probably be more robust (use a regex?)
//                      String name = url.substring(url.lastIndexOf('/') + 1).trim();
                        String name = url.substring(url.lastIndexOf('=') + 1).trim();
                        name = URLDecoder.decode(name);
                        if (img != null) {
//                         newImages.add(img);
                           images.add(img);
                           handleNewImage(img, name);
                        }
                     }
                    try {
                        Thread.sleep(2000);
                    } catch (InterruptedException ex) {
                        ex.printStackTrace();
                    }
                  } else {
                     // wait until notified of new image(s) to fetch
                     try {
                        imagesToFetch.wait();
                     } catch (InterruptedException e) {
                        // TODO Auto-generated catch block
                        e.printStackTrace();
                     }
                  }
               }
            }
         }
      }, "image fetcher");
      imageFetchThread.start();
   }

   /**
    * Polls the server of a list of image URLs, compares that list against the
    * list of known image URLs, and adds any new URLs to the imagesToFetch queue.
    */
   private void checkForNewImages() {
      String[] urls = fetchResourceList(userId);
      if (urls == null) {
         return;
      }
      for (int i = 0; i < urls.length; i++) {
         String url = urls[i];
         if (url == null) {
            continue;
         }

         // Note: Currently not filtering possible non-image files. For now,
         // assuming that nobody uploads any other type of file.
//       String lowerUrl = url.toLowerCase().trim();
//       // filter all but JPEGs
//       if (!(lowerUrl.endsWith(".jpg") || lowerUrl.endsWith(".jpeg"))) {
//       continue;
//       }

         // check if already have it, or if in the fetch queue
         if (imageUrls.contains(url) || imagesToFetch.contains(url)) {
            continue;
         }
         trace("  found new image: " + url);
         imageUrls.add(url);
         synchronized (imagesToFetch) {
            imagesToFetch.add(url);
            imagesToFetch.notify();
         }
      }
   }

   /**
    * Loads an image at a URL.
    * @param filename   URL string
    * @return           Image on success, null on failure
    */
   private Image fetchImage(String filename) {
      trace("fetchImage() - filename: " + filename);
      URL url;
      //try {
         url = ImageDrop.class.getResource(filename);//new URL(filename);
//      } catch (MalformedURLException e1) {
//         // TODO Auto-generated catch block
//         e1.printStackTrace();
//         return null;
//      }
      Image image = Toolkit.getDefaultToolkit().getImage(url);

      HScene component = HSceneFactory.getInstance().getDefaultHScene();
      MediaTracker mediaTracker = new MediaTracker(component);
      mediaTracker.addImage(image, 0);
      try {
         if (!mediaTracker.waitForAll(20000)) { // wait up to 20 seconds
            // presumably, this correctly handles slow net connections
            return null;
         }
      } catch (InterruptedException e) {
         return null;
      } catch (RuntimeException e) {
         return null;
      }
      if (mediaTracker.isErrorAny()) {
         return null;
      }

      return image;
   }

   /**
    * Processes the newly arrived image.
    * @param img
    * @param name
    */
   private void handleNewImage(Image img, String name) {
////  status("newest image: " + name + ", " + img.getWidth(null) + "x" + img.getHeight(null));
//    newImages.clear();
////  if (images.size() > 0) {
////  imageView.setImage((Image) images.get(images.size() - 1));
//////listView.add("image " + ++count);
////  listView.add(name);
////  }
//////draw();


      imageView.addImage(img);
      listView.add(name);
   }

   // TODO  move to util package
   public static Font loadFont(String fontName, int size) {
      Font font = null;
      try {
         FontFactory fontFactory = new FontFactory();
         font = fontFactory.createFont(fontName, Font.PLAIN, size);
      } catch (FontFormatException e) {
      } catch (IOException e) {
      } catch (FontNotAvailableException e) {
      }
      // check that the font was created
      if (font == null) {
         // use the default font as a backup
         font = new Font("default", Font.PLAIN, size);
      }
      return font;
   }

   private void setup() {
      traceFont = loadFont("HelveticaNeue", 100);

      scene = HSceneFactory.getInstance().getDefaultHScene();

      int w = scene.getWidth();
      int h = scene.getHeight();

//    int safeW = w - 2 * titleSafeX;

//    int statusTop = h - titleSafeY - boxH;
//    status = new HStaticText("status", titleSafeX, statusTop, safeW, boxH);
//    status.setBackgroundMode(HVisible.BACKGROUND_FILL);
//    status.setForeground(Color.black);
//    status.setBackground(Color.white);
//    status.setFont(font18);
//    status.setBordersEnabled(true);
//    status.setHorizontalAlignment(HVisible.HALIGN_CENTER);
//    status.setBackground(new Color(255, 255, 255, 200));
//    scene.add(status);

//    status.setTextContent("ImageDrop - press an arrow key to redraw", HState.ALL_STATES);

      int listViewW = 400;
      int listViewH = h - (2 * titleSafeY);
      int imageViewW = w - actionSafeX - titleSafeX - listViewW - 10;

      imageView = new ImageView(traceFont);
      imageView.setBounds(actionSafeX, 0, imageViewW, h);
      scene.add(imageView);

//    int dch = status.getY() - 10 - titleSafeY;
      listView = new ListView();
      listView.setBounds(w - titleSafeX - listViewW, titleSafeY, listViewW, listViewH);
      scene.add(listView);

      initRC();

      animation = new Animation(new Runnable() {
         public void run() {
            draw();
         }
      }, fps);
      animation.start();

      scene.setVisible(true);
   }

   private void destroyScene() {
      // TODO  should remove any action listeners here

      this.scene.removeAll();
      this.scene.dispose();
   }

   private void trace(String str) {
      if (traceEnabled) {
         println(str);
         System.out.println(System.currentTimeMillis() + " - " + str);
         try {
            DVBTest.log(Thread.currentThread().getName(), str);
         } catch (IOException e) {
            e.printStackTrace();
         }
      }
   }

// static void status(String str) {
// status.setTextContent(str, HState.ALL_STATES);
// }

// static boolean isStatusVisible() {
// return status.isVisible();
// }

// static void setStatusVisible(boolean b) {
// status.setVisible(b);
// }

   /**
    * Retrieves a set of URLs for a user ID.
    * @return  returns an empty String[] if there are no URLs
    */
   private String[] fetchResourceList(int userId) {
      // example: http://localhost:8080/reslist/getList?id=1000
//    int userId = 1000;
//      String reslistUrl = "http://" + reslistHost + "/" + reslistServlet + reslistQuery + userId;
//    trace("reslistUrl: " + reslistUrl);
//      String results = loadText(reslistUrl);
//    trace("results: " + results);
//      if (results == null) {
//         return null;
//      }
      String[] urls = new String[] {"/data/DSCN0616.JPG", "/data/IMG_0069.JPG", "/data/IMG_0247.jpg", "/data/IMG_0448.JPG", "/data/IMG_0920.JPG", "/data/IMG_0951.JPG","/data/IMG_3435.JPG"};
      if (urls == null) {
         urls = new String[0];
      }
      // TODOHI   replace host with expected host, assumming it is same as servlet host?
      // If getting the ResourceList servlet to insert the correct host proves to be hard
      // or time consuming to get right, might use a hack here to insert the expected host,
      // at least for early demos.
      return urls;
   }

   // TODO  split() should be in a utility class or base xlet
   /**
    * @param str
    * @param delim
    * @return        null if str is null, empty, or all delimiters
    */
   private String[] split(String str, String delim) {
      if ((str == null) || (str.length() == 0)) return null;
      StringTokenizer st = new StringTokenizer(str, delim);
      int count = 0;
      while (st.hasMoreTokens()) {
         st.nextToken();
         count++;
      }
      if (count == 0) return null;
      String[] results = new String[count];
      st = new StringTokenizer(str, delim);
      int i = 0;
      while (st.hasMoreTokens()) {
         results[i++] = st.nextToken();
      }
      return results;
   }

   // TODO  loadText() should be in a utility class or base xlet
   private String loadText(String filename) {
      try {
         // create a URL for the desired page
         URL url = new URL(filename);

         // read all the text returned by the server
         BufferedReader in = new BufferedReader(new InputStreamReader(url.openStream()));
         StringBuffer sb = new StringBuffer();
         String str;
         while ((str = in.readLine()) != null) {
            // str is one line of text; readLine() strips the newline character(s)
            sb.append(str);
            sb.append("\n");
         }
         in.close();
         return sb.toString();
      } catch (MalformedURLException e) {
         trace("MalformedURLException: " + e);
      } catch (IOException e) {
         trace("IOException: " + e);
      } catch (Throwable e) {
         trace("Throwable: " + e);
      }
      return null;
   }

   protected Image loadImage(String path) {
      URL url = null;
      // Note: The PS3 fails pretty badly when using ClassLoader.getResource() instead of Class.getResource().
      url = this.getClass().getResource(path);
      Image image = null;
      if (url != null) {
         image = Toolkit.getDefaultToolkit().createImage(url);
         if (image == null) {
            return null;
         }

         HScene component = HSceneFactory.getInstance().getDefaultHScene();
         MediaTracker mediaTracker = new MediaTracker(component);
         mediaTracker.addImage(image, 0);
         try {
            mediaTracker.waitForAll();
         } catch (InterruptedException e) {
            return null;
         }
         if (mediaTracker.isErrorAny()) {
            return null;
         }
      }
      return image;
   }

   class Animation {
      private Thread    thread;
      private boolean   closing = false;
      private boolean   paused = false;

      public Animation(final Runnable runner, int fps) {
         final long  frameInterval = 1000 / fps;
         thread = new Thread(new Runnable() {
            public void run() {
               while (!closing) {
                  // wait while paused
                  synchronized (thread) {
                     while (paused) {
                        try {
                           thread.wait();
                        } catch (InterruptedException e) {
                           // TODO Auto-generated catch block
                           e.printStackTrace();
                        }
                     }
                  }

                  long t0 = System.currentTimeMillis();

                  runner.run();

                  long elapsed = System.currentTimeMillis() - t0;
                  try {
                     // sleep larger of 5 ms or unused frame interval
                     Thread.sleep(Math.max(5, frameInterval - elapsed));
                  } catch (InterruptedException e) {
                     // TODO Auto-generated catch block
                     e.printStackTrace();
                  }
               }
            }
         }, "animation");
         thread.start();
      }

      public void close() {
         closing = true;
      }

      public void start() {
         paused = false;
         synchronized (thread) {
            thread.notify();
         }
      }

      public void pause() {
         paused = true;
      }
   }
}
