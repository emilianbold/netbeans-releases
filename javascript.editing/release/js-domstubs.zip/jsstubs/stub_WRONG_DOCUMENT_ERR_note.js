/**
* <p>Nodes from external documents must be cloned using <code><a href="DOM:document.importNode" shape="rect" title="DOM:document.importNode">importNode</a></code> (or adopted using <code><a href="document.adoptNode" shape="rect" title="DOM:document.adoptNode">adoptNode</a></code>) before they can be inserted into the current document. For more on the <code><a href="element.ownerDocument" shape="rect" title="DOM:element.ownerDocument">ownerDocument</a></code> issues see the <a href="http://www.w3.org/DOM/faq.html#ownerdoc" rel="nofollow" shape="rect" title="http://www.w3.org/DOM/faq.html#ownerdoc">W3C DOM FAQ</a>.
* </p><p><a href="http://developer.mozilla.org/en/docs/Gecko" shape="rect" title="Gecko">Gecko</a> did not enforce the use of <code>importNode</code> and <code>adoptNode</code> until 1.9. <a href="http://developer.mozilla.org/en/docs/Gecko_1.9_Changes_affecting_websites" shape="rect" title="Gecko 1.9 Changes affecting websites">Since 1.9 alphas</a>, failing to adopt or import a node before using it in a different document results in the <code>WRONG_DOCUMENT_ERR</code> (<code>NS_ERROR_DOM_WRONG_DOCUMENT_ERR</code>) exception being thrown.
* </p>
* 
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>	  		<li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>	  				</ul>
*/
WRONG_DOCUMENT_ERR_note = function() {
  // This is just a stub for a builtin native JavaScript object.
}

