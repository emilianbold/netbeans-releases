/**
* <h2> <span> Introduction </span></h2>
* <p>The <code>TreeWalker</code> object represents the nodes of a document subtree and a position within them.
* </p><p>A TreeWalker can be created using the <a href="document.createTreeWalker" shape="rect" title="DOM:document.createTreeWalker">createTreeWalker</a> method of the <a href="document" shape="rect" title="DOM:document">document</a> object.
* </p>
* <h2> <span> Properties </span></h2>
* <dl><dt style="font-weight:bold"><a href="DOM:treeWalker.root" shape="rect" title="DOM:treeWalker.root">root</a>
* </dt><dt style="font-weight:bold"><a href="treeWalker.whatToShow" shape="rect" title="DOM:treeWalker.whatToShow">whatToShow</a>
* </dt><dt style="font-weight:bold"><a href="treeWalker.filter" shape="rect" title="DOM:treeWalker.filter">filter</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.ExpandEntityReferences&amp;action=edit" shape="rect" title="DOM:treeWalker.ExpandEntityReferences">expandEntityReferences</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.currentNode&amp;action=edit" shape="rect" title="DOM:treeWalker.currentNode">currentNode</a>
* </dt></dl>
* <h2> <span> Methods </span></h2>
* <dl><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=DOM:treeWalker.parentNode&amp;action=edit" shape="rect" title="DOM:treeWalker.parentNode">parentNode</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.firstChild&amp;action=edit" shape="rect" title="DOM:treeWalker.firstChild">firstChild</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.lastChild&amp;action=edit" shape="rect" title="DOM:treeWalker.lastChild">lastChild</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.previousSibling&amp;action=edit" shape="rect" title="DOM:treeWalker.previousSibling">previousSibling</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.nextSibling&amp;action=edit" shape="rect" title="DOM:treeWalker.nextSibling">nextSibling</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.previousNode&amp;action=edit" shape="rect" title="DOM:treeWalker.previousNode">previousNode</a>
* </dt><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=treeWalker.nextNode&amp;action=edit" shape="rect" title="DOM:treeWalker.nextNode">nextNode</a>
* </dt></dl>
* <h2> <span> Specification </span></h2>
* <p><a href="http://www.w3.org/TR/DOM-Level-2-Traversal-Range/traversal.html#Traversal-TreeWalker" rel="nofollow" shape="rect" title="http://www.w3.org/TR/DOM-Level-2-Traversal-Range/traversal.html#Traversal-TreeWalker">DOM Level 2 Traversal: TreeWalker</a>
* </p>
* 
* <div id="catlinks"><p><a href="http://developer.mozilla.org/en/docs/Special:Categories" shape="rect" title="Special:Categories">Categories</a>: <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:Gecko_DOM_Reference" shape="rect" title="Category:Gecko DOM Reference">Gecko DOM Reference</a></span> | <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:NeedsContent" shape="rect" title="Category:NeedsContent">NeedsContent</a></span></p></div>
* 
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>	  		<li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>	  				</ul>
*/
var treeWalker;

/**
* <h2> <span> Summary </span></h2>
* <p>Returns an object with a method <code>acceptNode(node)</code>.
* </p>
* <h2> <span> Syntax </span></h2>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">nodeFilter = treeWalker.filter;
* </pre>
* <h2> <span> Example </span></h2>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">var treeWalker = document.createTreeWalker(
* document.body,
* NodeFilter.SHOW_ELEMENT,
* { acceptNode: function(node) { return NodeFilter.FILTER_ACCEPT; } },
* false
* );
* nodeFilter = treeWalker.filter; // document.body in this case
* </pre>
* <h2> <span> Notes </span></h2>
* <p>When creating the TreeWalker, the filter object is passed in as the third parameter, and the object method <code>acceptNode(node)</code> is called on every single node to determine whether or not to accept it. This function should return the constant <code>NodeFilter.FILTER_ACCEPT</code> for cases when the node should be accepted and <code>NodeFilter.FILTER_REJECT</code> for cases when the node should be rejected.
* </p>
* 
* <div id="catlinks"><p><a href="http://developer.mozilla.org/en/docs/Special:Categories" shape="rect" title="Special:Categories">Category</a>: <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:Gecko_DOM_Reference" shape="rect" title="Category:Gecko DOM Reference">Gecko DOM Reference</a></span></p></div>
* 
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>	  		<li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>	  				</ul>
*/
treeWalker.filter = function() {
  // This is just a stub for a builtin native JavaScript object.
}

/**
* <h2> <span> Summary </span></h2>
* <p>Returns the node that is the root of what the TreeWalker traverses.
* </p>
* <h2> <span> Syntax </span></h2>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">root = treeWalker.root;
* </pre>
* <h2> <span> Example </span></h2>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">var treeWalker = document.createTreeWalker(
* document.body,
* NodeFilter.SHOW_ELEMENT,
* { acceptNode: function(node) { return NodeFilter.FILTER_ACCEPT; } },
* false
* );
* root = treeWalker.root; // document.body in this case
* </pre>
* 
* <div id="catlinks"><p><a href="http://developer.mozilla.org/en/docs/Special:Categories" shape="rect" title="Special:Categories">Category</a>: <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:Gecko_DOM_Reference" shape="rect" title="Category:Gecko DOM Reference">Gecko DOM Reference</a></span></p></div>
* 
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>	  		<li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>	  				</ul>
*/
treeWalker.root = function() {
  // This is just a stub for a builtin native JavaScript object.
}

/**
* <h2> <span> Summary </span></h2>
* <p>Returns a number signifying what types of nodes should be returned by the treeWalker.
* </p>
* <h2> <span> Syntax </span></h2>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">var nodeTypes = treeWalker.whatToShow;
* </pre>
* <h2> <span> Example </span></h2>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">var treeWalker = document.createTreeWalker(
* document.body,
* NodeFilter.SHOW_ELEMENT + NodeFilter.SHOW_COMMENT + NodeFilter.SHOW_TEXT,
* { acceptNode: function(node) { return NodeFilter.FILTER_ACCEPT; } },
* false
* );
* if( (treeWalker.whatToShow == NodeFilter.SHOW_ALL) ||
* (treeWalker.whatToShow % (NodeFilter.SHOW_COMMENT*2)) &gt;= NodeFilter.SHOW_COMMENT) {
* // treeWalker will show comments
* }
* </pre>
* <h2> <span> Notes </span></h2>
* <p>Valid flags for <code>whatToShow</code> are:
* </p>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">NodeFilter.SHOW_ALL = -1
* NodeFilter.SHOW_ELEMENT = 1
* NodeFilter.SHOW_ATTRIBUTE = 2
* NodeFilter.SHOW_TEXT = 4
* NodeFilter.SHOW_CDATA_SECTION = 8
* NodeFilter.SHOW_ENTITY_REFERENCE = 16
* NodeFilter.SHOW_ENTITY = 32
* NodeFilter.SHOW_PROCESSING_INSTRUCTION = 64
* NodeFilter.SHOW_COMMENT = 128
* NodeFilter.SHOW_DOCUMENT = 256
* NodeFilter.SHOW_DOCUMENT_TYPE = 512
* NodeFilter.SHOW_DOCUMENT_FRAGMENT = 1024
* NodeFilter.SHOW_NOTATION = 2048
* </pre>
* 
* <div id="catlinks"><p><a href="http://developer.mozilla.org/en/docs/Special:Categories" shape="rect" title="Special:Categories">Category</a>: <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:Gecko_DOM_Reference" shape="rect" title="Category:Gecko DOM Reference">Gecko DOM Reference</a></span></p></div>
* 
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>	  		<li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>	  				</ul>
*/
treeWalker.whatToShow = function() {
  // This is just a stub for a builtin native JavaScript object.
}

