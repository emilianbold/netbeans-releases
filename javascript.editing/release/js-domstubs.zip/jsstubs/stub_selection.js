/**
* <div id="contentSub">(Redirected from <a href="http://developer.mozilla.org/en/docs/index.php?title=DOM:selection&amp;redirect=no" shape="rect" title="DOM:selection">DOM:selection</a>)</div>
* 
* <h2> <span> Summary </span></h2>
* <p>The class of the object returned by <code><a href="DOM:window.getSelection" shape="rect" title="DOM:window.getSelection"> window.getSelection()</a></code> and other methods.
* </p>
* <h2> <span> Description </span></h2>
* <p>A selection object represents the <a href="DOM:range" shape="rect" title="DOM:range">ranges</a> that the user has selected. Typically, it holds only one range, accessed as follows:
* </p>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">range = sel.getRangeAt(0);
* </pre>
* <p>Calling the <code><a href="Selection:toString" shape="rect" title="DOM:Selection:toString">toString()</a></code> method returns the text contained in the selection, e.g
* </p>
* <pre style="background:#EEEEEE none repeat scroll 0% 50%;border:1px solid #666666;padding:5px 5px" xml:space="preserve">selObj = window.getSelection();
* window.alert(selObj);
* </pre>
* <h2> <span> Glossary </span></h2>
* <p>Other key terms used in this section.
* </p>
* <dl><dt style="font-weight:bold">anchor
* </dt><dd>The anchor of a selection is the beginning point of the selection.  When making a selection with a mouse, the anchor is where in the document the mouse button is initially pressed.  As the user changes the selection using the mouse or the keyboard, the anchor does not move.
* </dd><dt style="font-weight:bold">focus
* </dt><dd>The focus of a selection is the end point of the selection.  When making a selection with a mouse, the focus is where in the document the mouse button is released.  As the user changes the selection using the mouse or the keyboard, the focus is the end of the selection that moves.
* </dd><dt style="font-weight:bold">range
* </dt><dd>A range is a contiguous part of a document.  A range can contain entire nodes as well as portions of nodes, such as a portion of a text node.  A user will normally only select a single range at a time, but it's possible for a user to select multiple ranges (e.g. by using the Control key).  A range can be retrieved from a selection as a <a href="DOM:range" shape="rect" title="DOM:range">range</a> object. Range objects can also be created via the DOM and programmatically added or removed from a selection.
* </dd></dl>
* <h2> <span> Properties </span></h2>
* <dl><dt style="font-weight:bold"><a href="DOM:Selection:anchorNode" shape="rect" title="DOM:Selection:anchorNode"> anchorNode</a></dt><dd> Returns the node in which the selection begins.
* </dd><dt style="font-weight:bold"><a href="Selection:anchorOffset" shape="rect" title="DOM:Selection:anchorOffset"> anchorOffset</a></dt><dd> Returns the number of characters that the selection's anchor is offset within the anchorNode.
* </dd><dt style="font-weight:bold"><a href="Selection:focusNode" shape="rect" title="DOM:Selection:focusNode"> focusNode</a></dt><dd> Returns the node in which the selection ends.
* </dd><dt style="font-weight:bold"><a href="Selection:focusOffset" shape="rect" title="DOM:Selection:focusOffset"> focusOffset</a></dt><dd> Returns the number of characters that the selection's focus is offset within the focusNode.
* </dd><dt style="font-weight:bold"><a href="Selection:isCollapsed" shape="rect" title="DOM:Selection:isCollapsed"> isCollapsed</a></dt><dd> Returns a boolean indicating whether the selection's start and end points are at the same position.
* </dd><dt style="font-weight:bold"><a href="Selection:rangeCount" shape="rect" title="DOM:Selection:rangeCount"> rangeCount</a></dt><dd> Returns the number of ranges in the selection.
* </dd></dl>
* <h2> <span> Methods </span></h2>
* <dl><dt style="font-weight:bold"><a href="DOM:Selection:getRangeAt" shape="rect" title="DOM:Selection:getRangeAt"> getRangeAt</a></dt><dd> Returns a range object representing one of the ranges currently selected.
* </dd><dt style="font-weight:bold"><a href="Selection:collapse" shape="rect" title="DOM:Selection:collapse"> collapse</a></dt><dd> Collapses the current selection to a single point.
* </dd><dt style="font-weight:bold"><a href="Selection:extend" shape="rect" title="DOM:Selection:extend"> extend</a></dt><dd> Moves the focus of the selection to a specified point.
* </dd><dt style="font-weight:bold"><a href="Selection:collapseToStart" shape="rect" title="DOM:Selection:collapseToStart"> collapseToStart</a></dt><dd> Moves the focus of the selection to the same point at the anchor.
* </dd><dt style="font-weight:bold"><a href="Selection:collapseToEnd" shape="rect" title="DOM:Selection:collapseToEnd"> collapseToEnd</a></dt><dd> Moves the anchor of the selection to the same point as the focus. The focus does not move.
* </dd><dt style="font-weight:bold"><a href="Selection:selectAllChildren" shape="rect" title="DOM:Selection:selectAllChildren"> selectAllChildren</a></dt><dd> Adds all the children of the specified node to the selection.
* </dd><dt style="font-weight:bold"><a href="Selection:addRange" shape="rect" title="DOM:Selection:addRange"> addRange</a></dt><dd> A range object that will be added to the selection.
* </dd><dt style="font-weight:bold"><a href="Selection:removeRange" shape="rect" title="DOM:Selection:removeRange"> removeRange</a></dt><dd> Removes a range from the selection.
* </dd><dt style="font-weight:bold"><a href="Selection:removeAllRanges" shape="rect" title="DOM:Selection:removeAllRanges"> removeAllRanges</a></dt><dd> Removes all ranges from the selection.
* </dd><dt style="font-weight:bold"><a href="Selection:deleteFromDocument" shape="rect" title="DOM:Selection:deleteFromDocument"> deleteFromDocument</a></dt><dd> Deletes the selection's content from the document.
* </dd><dt style="font-weight:bold"><a href="http://developer.mozilla.org/en/docs/index.php?title=Selection:selectionLanguageChange&amp;action=edit" shape="rect" title="DOM:Selection:selectionLanguageChange"> selectionLanguageChange</a></dt><dd>
* </dd><dt style="font-weight:bold"><a href="Selection:toString" shape="rect" title="DOM:Selection:toString"> toString</a></dt><dd> Returns a string currently being represented by the selection object, i.e. the currently selected text.
* </dd><dt style="font-weight:bold"><a href="Selection:containsNode" shape="rect" title="DOM:Selection:containsNode"> containsNode</a></dt><dd> Indicates if a certain node is part of the selection.
* </dd></dl>
* <h2> <span> See also </span></h2>
* <p><a href="DOM:window.getSelection" shape="rect" title="DOM:window.getSelection">window.getSelection</a>,
* <a href="range" shape="rect" title="DOM:range">Range</a>
* </p>
* <h2> <span> External links </span></h2>
* <ul><li> <a href="http://lxr.mozilla.org/mozilla/source/content/base/public/nsISelection.idl" rel="nofollow" shape="rect" title="http://lxr.mozilla.org/mozilla/source/content/base/public/nsISelection.idl">IDL definition in Mozilla cross-reference</a>
* </li></ul>
* 
* <div id="catlinks"><p><a href="http://developer.mozilla.org/en/docs/Special:Categories" shape="rect" title="Special:Categories">Category</a>: <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:Gecko_DOM_Reference" shape="rect" title="Category:Gecko DOM Reference">Gecko DOM Reference</a></span></p></div>
* 
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>	  		<li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>	  				</ul>
*/
var selection;

