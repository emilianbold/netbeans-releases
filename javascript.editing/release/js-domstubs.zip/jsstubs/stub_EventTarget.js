/**
* <p>« </p>
* <p>An <code>EventTarget</code> is a DOM interface implemented by
* objects that can receive DOM events and have listeners for them.
* The most common <code>EventTarget</code>s are <a href="DOM:element" shape="rect" title="DOM:element">DOM elements</a>, although other objects can be
* <code>EventTarget</code>s too, for example <a href="document" shape="rect" title="DOM:document">document</a>, <a href="window" shape="rect" title="DOM:window">window</a>, <a href="http://developer.mozilla.org/en/docs/XMLHttpRequest" shape="rect" title="XMLHttpRequest">XMLHttpRequest</a>, and others.</p>
* 
* <h2> <span>Methods</span></h2>
* <table border="1" style="background:#FFFFFF none repeat scroll 0%;border: 1px solid #666666;margin-bottom:10px;margin-top:10px" width="100%">
* <tr>
* <th colspan="1" rowspan="1">Name &amp; Description</th>
* <th colspan="1" rowspan="1">Return</th>
* </tr>
* <tr>
* <td colspan="1" rowspan="1"><code><a href="DOM:element.addEventListener" shape="rect" title="DOM:element.addEventListener">addEventListener</a>( <a href="http://developer.mozilla.org/en/docs/Global_Objects:String" shape="rect" title="Core JavaScript 1.5 Reference:Global Objects:String">type</a>,
* <a href="http://developer.mozilla.org/en/docs/Global_Objects:Function" shape="rect" title="Core JavaScript 1.5 Reference:Global Objects:Function">handler</a>,
* <a href="http://developer.mozilla.org/en/docs/Global_Objects:Boolean" shape="rect" title="Core JavaScript 1.5 Reference:Global Objects:Boolean">bubble</a>
* )</code>
* Register an event handler of a specific event type on the
* <code>EventTarget</code>.</td>
* <td colspan="1" rowspan="1">-</td>
* </tr>
* <tr>
* <td colspan="1" rowspan="1"><code><a href="element.removeEventListener" shape="rect" title="DOM:element.removeEventListener">removeEventListener</a>( <a href="http://developer.mozilla.org/en/docs/Global_Objects:String" shape="rect" title="Core JavaScript 1.5 Reference:Global Objects:String">type</a>,
* <a href="http://developer.mozilla.org/en/docs/Global_Objects:Function" shape="rect" title="Core JavaScript 1.5 Reference:Global Objects:Function">handler</a>
* )</code>
* Removes an event listener from the <code>EventTarget</code>.</td>
* <td colspan="1" rowspan="1">-</td>
* </tr>
* <tr>
* 
* </tr>
* <tr>
* <td colspan="1" rowspan="1"><code><a href="element.dispatchEvent" shape="rect" title="DOM:element.dispatchEvent">dispatchEvent</a>( <a href="event" shape="rect" title="DOM:event">event</a> )</code>
* Dispatch an event to this <code>EventTarget</code>.</td>
* <td colspan="1" rowspan="1"><a href="http://developer.mozilla.org/en/docs/Global_Objects:Boolean" shape="rect" title="Core JavaScript 1.5 Reference:Global Objects:Boolean">Boolean</a></td>
* </tr>
* </table>
* 
* <h2> <span>Specification</span></h2>
* <p><a href="http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-EventTarget" rel="nofollow" shape="rect" title="http://www.w3.org/TR/DOM-Level-2-Events/events.html#Events-EventTarget">DOM Level 2 Events: EventTarget</a></p>
* 
* <div id="catlinks">
* <p><a href="http://developer.mozilla.org/en/docs/Special:Categories" shape="rect" title="Special:Categories">Category</a>: <span dir="ltr"><a href="http://developer.mozilla.org/en/docs/Category:Gecko_DOM_Reference" shape="rect" title="Category:Gecko DOM Reference">Gecko DOM
* Reference</a></span></p>
* </div>
* <ul style="list-style-type:none;font-size:0.9em;text-align:center">
* <li id="f-copyright">Content is available under <a href="http://developer.mozilla.org/en/docs/MDC:Copyrights" shape="rect" title="MDC:Copyrights">these licenses</a>.</li>
* <li id="f-about"><a href="http://developer.mozilla.org/en/docs/MDC:About" shape="rect" title="MDC:About">About MDC</a></li>
* </ul>
*/
EventTarget = function() {
  // This is just a stub for a builtin native JavaScript object.
}

