/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package org.netbeans.modules.debugger.jpda.backend.truffle;

import com.oracle.truffle.api.ExecutionContext;
import com.oracle.truffle.api.Source;
import com.oracle.truffle.api.debug.ASTPrinter;
import com.oracle.truffle.api.debug.DebugContext;
import com.oracle.truffle.api.debug.DebugManager;
import com.oracle.truffle.api.frame.FrameSlot;
import com.oracle.truffle.api.frame.MaterializedFrame;
import com.oracle.truffle.api.nodes.Node;
import com.oracle.truffle.api.nodes.instrument.NodeInstrumenter;
import com.oracle.truffle.js.engine.TruffleJSEngine;
import com.oracle.truffle.js.engine.TruffleJSEngineFactory;
import com.oracle.truffle.js.runtime.JSContext;
import com.oracle.truffle.repl.debug.AbstractDebugManager;
import javax.script.ScriptEngineManager;

/**
 *
 * @author martin
 */
class JPDATruffleDebugManager extends AbstractDebugManager {

    public JPDATruffleDebugManager(ExecutionContext context) {
        super(context);
    }
    
    static JPDATruffleDebugManager setUp() {
        TruffleJSEngine engine = (TruffleJSEngine) new ScriptEngineManager().getEngineByName(TruffleJSEngineFactory.ENGINE_NAME);
        JSContext jsContext = engine.getJSContext();
        JPDATruffleDebugManager debugManager = new JPDATruffleDebugManager(jsContext);
        jsContext.setDebugContext(new JPDADebugContext(jsContext, debugManager));
        return debugManager;
    }

    private static class JPDADebugContext implements DebugContext {
        
        private final ExecutionContext execContext;
        private final DebugManager debugManager;
        
        public JPDADebugContext(ExecutionContext execContext, DebugManager debugManager) {
            this.execContext = execContext;
            this.debugManager = debugManager;
        }

        @Override
        public ExecutionContext getContext() {
            return execContext;
        }

        @Override
        public NodeInstrumenter getNodeInstrumenter() {
            return null;
        }

        @Override
        public DebugManager getDebugManager() {
            return debugManager;
        }

        @Override
        public ASTPrinter getASTPrinter() {
            return null;
        }

        @Override
        public String displayValue(Object o) {
            return String.valueOf(o);
        }

        @Override
        public String displayIdentifier(FrameSlot fs) {
            return fs.getIdentifier().toString();
        }

        @Override
        public void executionHalted(Node node, MaterializedFrame mf) {
            JPDATruffleAccessor.executionHalted(node, mf);
        }
        
    }
}
