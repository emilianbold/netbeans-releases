package annotations;


public @interface LongArgAnnotation {
    
    long value();
    
}
