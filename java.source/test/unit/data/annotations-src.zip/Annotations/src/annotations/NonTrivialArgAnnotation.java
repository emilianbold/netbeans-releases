package annotations;


public @interface NonTrivialArgAnnotation {
    
    TestEnum something();
    
}
