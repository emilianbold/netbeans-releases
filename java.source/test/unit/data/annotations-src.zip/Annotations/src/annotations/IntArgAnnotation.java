package annotations;


public @interface IntArgAnnotation {
    
    int value();
    
}
