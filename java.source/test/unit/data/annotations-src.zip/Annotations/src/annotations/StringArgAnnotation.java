package annotations;


public @interface StringArgAnnotation {
    
    String value();
    
}
