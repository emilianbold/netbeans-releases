package annotations;


public @interface ArrayOfIntArgAnnotation {
    
    int[] value();
    
}
