package annotations;


public @interface ArrayOfAnnotationArgAnnotation {
    
    ArrayOfStringArgAnnotation[] value();
    
}
