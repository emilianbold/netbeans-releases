package annotations;


public @interface FloatArgAnnotation {
    
    float value();
    
}
