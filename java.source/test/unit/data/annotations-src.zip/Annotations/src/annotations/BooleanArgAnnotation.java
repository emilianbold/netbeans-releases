package annotations;


public @interface BooleanArgAnnotation {
    
    boolean value();
    
}
