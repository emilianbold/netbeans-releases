function Runner() {
    this.nick = "";
    this.dob = new Date();
    this.hello = function () {
    };
    this.conf = {
        a: 1, b: 2, aa:2
    };
}

module.exports = {
    jejda: {
        ale: 1,
        ale2: 1
    },
    pokus: new Date(),
    obj: new Runner(),
    jejda2: {
        ale: 1,
        ale2: 1
    }
};

