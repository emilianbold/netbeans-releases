function Runner2() {
    this.nick2 = "";
    this.dob2 = new Date();
    this.hello2 = function () {
    };
    this.conf2 = {
        a: 1, b: 2
    };
}

Runner2.pokus2 = function () {
};




var o = {
    pokus2: new Date(),
    obj2: new Runner2(),
    neco2 : 2
};

module.exports = o;


