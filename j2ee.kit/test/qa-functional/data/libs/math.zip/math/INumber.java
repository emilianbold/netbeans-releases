/*
 * INumber.java
 *
 * Created on April 18, 2005, 10:59 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package math;

/**
 *
 * @author jungi
 */
public interface INumber {
    
    INumber abs();
    
    INumber add(INumber no);
    
    INumber divide(INumber no);
    
    boolean isDecimal();
    
    boolean isReal();
    
    INumber max(INumber no);
    
    INumber min(INumber no);
    
    INumber multiply(INumber no);
    
    INumber negate();
    
    INumber subtract(INumber no);
}
