/*
 * UndefinedOperationException.java
 *
 * Created on April 18, 2005, 11:16 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package math;

/**
 *
 * @author jungi
 */
public class UndefinedOperationException extends RuntimeException {
    
    /**
     * Creates a new instance of <code>UndefinedOperationException</code> without detail message.
     */
    public UndefinedOperationException() {
    }
    
    
    /**
     * Constructs an instance of <code>UndefinedOperationException</code> with the specified detail message.
     * @param msg the detail message.
     */
    public UndefinedOperationException(String msg) {
        super(msg);
    }
    
    public UndefinedOperationException(String msg, Throwable cause) {
        super(msg, cause);
    }
        
}
