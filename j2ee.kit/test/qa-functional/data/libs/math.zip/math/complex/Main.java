/*
 * Main.java
 *
 * Created on April 14, 2005, 3:17 PM
 *
 * To change this template, choose Tools | Options and locate the template under
 * the Source Creation and Management node. Right-click the template and choose
 * Open. You can then make changes to the template in the Source Editor.
 */

package math.complex;
import math.RealComplexINumber;

/**
 *
 * @author jungi
 */
public class Main {
    
    /** Creates a new instance of Main */
    public Main() {
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        RealComplexINumber cn1 = new RealComplexINumber(1, 1);
        System.out.println(cn1.toString());

        // TODO code application logic here
        /*
        System.out.println();
        System.out.println("plus:");
        System.out.println(new ComplexNumber(1, 1).plus(new ComplexNumber(1,1)));
        System.out.println(new ComplexNumber(-1, -1).plus(new ComplexNumber(1,1)));
        System.out.println(new ComplexNumber(-3, -9).plus(new ComplexNumber(7,19)));
        System.out.println();
        System.out.println("minus:");
        System.out.println(new ComplexNumber(1, 1).minus(new ComplexNumber(1,1)));
        System.out.println(new ComplexNumber(-1, -1).minus(new ComplexNumber(1,1)));
        System.out.println(new ComplexNumber(-3, -9).minus(new ComplexNumber(7,19)));
         */
    }
    
}
