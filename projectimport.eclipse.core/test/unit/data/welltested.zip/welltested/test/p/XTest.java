package p;

import junit.framework.TestCase;

public class XTest extends TestCase {

	public void testToString() {
		assertTrue(new X().toString().contains("p.X"));
	}

}
