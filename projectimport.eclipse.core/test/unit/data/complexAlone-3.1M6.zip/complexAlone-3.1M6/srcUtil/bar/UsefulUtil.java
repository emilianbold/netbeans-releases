package bar;

import boo.Boo;

public class UsefulUtil {
	public static void main(String[] args) {
		new Boo();
	}
}
