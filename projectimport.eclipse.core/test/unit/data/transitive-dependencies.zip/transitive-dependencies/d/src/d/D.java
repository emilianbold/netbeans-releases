package d;
import b.B;
import c.C;
public class D {
	B b;
	C c;
}
