package c;
import a.A;
import b.B;
public class C {
	A a;
	B b;
}
