package app;
public class Main {
	public static void main(String[] args) {
		System.out.println(System.getProperty("greeting") + " " + args[0] + " from " + Main.class.getResource("/resource"));
	}
}
