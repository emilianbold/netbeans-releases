/*
* Support js for By_name
*/

function By_name(uri_) {
    this.uri = uri_;
}

By_name.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new By_nameRemote(this.uri);
   }
}

function By_nameRemote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

By_nameRemote.prototype = {

   get : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   }
}
