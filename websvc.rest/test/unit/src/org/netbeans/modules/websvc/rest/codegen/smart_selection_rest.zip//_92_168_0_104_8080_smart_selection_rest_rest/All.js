/*
* Support js for All
*/

function All(uri_) {
    this.uri = uri_;
}

All.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new AllRemote(this.uri);
   }
}

function AllRemote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

AllRemote.prototype = {

   get : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   }
}
