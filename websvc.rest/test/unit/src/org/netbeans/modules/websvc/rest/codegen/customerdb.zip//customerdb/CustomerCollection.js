/*
* Support js for CustomerCollection
*/

function CustomerCollection(uri_) {
    this.uri = uri_;
}

CustomerCollection.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new CustomerCollectionRemote(this.uri);
   }
}

function CustomerCollectionRemote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

CustomerCollectionRemote.prototype = {


}
