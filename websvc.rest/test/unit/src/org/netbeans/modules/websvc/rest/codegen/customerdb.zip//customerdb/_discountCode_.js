/*
* Support js for _discountCode_
*/

function _discountCode_(uri_) {
    this.uri = uri_;
}

_discountCode_.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new _discountCode_Remote(this.uri);
   }
}

function _discountCode_Remote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

_discountCode_Remote.prototype = {


}
