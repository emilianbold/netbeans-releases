/*
* Support js for Book
*/

function Book(uri_) {
    this.uri = uri_;
}

Book.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new BookRemote(this.uri);
   }
}

function BookRemote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

BookRemote.prototype = {


}
