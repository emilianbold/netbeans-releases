/*
* Support js for DiscountCode
*/

function DiscountCode(uri_) {
    this.uri = uri_;
}

DiscountCode.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new DiscountCodeRemote(this.uri);
   }
}

function DiscountCodeRemote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

DiscountCodeRemote.prototype = {

   getXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getJson : function() {
      return rjsSupport.get(this.uri, 'application/json');
   },

   putXml : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   },

   putJson : function(content) {
      return rjsSupport.put(this.uri, 'application/json', content);
   },

   delete_ : function() {
      return rjsSupport.delete_(this.uri);
   }
}
