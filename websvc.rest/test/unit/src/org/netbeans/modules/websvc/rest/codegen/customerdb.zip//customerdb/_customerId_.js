/*
* Support js for _customerId_
*/

function _customerId_(uri_) {
    this.uri = uri_;
}

_customerId_.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new _customerId_Remote(this.uri);
   }
}

function _customerId_Remote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

_customerId_Remote.prototype = {

   getXml : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   getJson : function() {
      return rjsSupport.get(this.uri, 'application/json');
   },

   putXml : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   },

   putJson : function(content) {
      return rjsSupport.put(this.uri, 'application/json', content);
   },

   delete_ : function() {
      return rjsSupport.delete_(this.uri);
   }
}
