/*
* Support js for Generic
*/

function Generic(uri_) {
    this.uri = uri_;
}

Generic.prototype = {

   getUri : function() {
      return this.uri;
   },
   
   getRemote : function() {
      return new GenericRemote(this.uri);
   }
}

function GenericRemote(uri_) {
    this.uri = uri_+'?expandLevel=1';
}

GenericRemote.prototype = {

   get : function() {
      return rjsSupport.get(this.uri, 'application/xml');
   },

   put : function(content) {
      return rjsSupport.put(this.uri, 'application/xml', content);
   }
}
