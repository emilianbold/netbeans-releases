
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest018 enterprise bean.
*/ 
public interface ExpandTest018Remote extends javax.ejb.EJBObject, test.expand.ExpandTest018RemoteBusiness {

        
}
 