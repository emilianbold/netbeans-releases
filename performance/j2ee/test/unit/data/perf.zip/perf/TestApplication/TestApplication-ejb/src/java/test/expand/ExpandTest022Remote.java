
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest022 enterprise bean.
*/ 
public interface ExpandTest022Remote extends javax.ejb.EJBObject, test.expand.ExpandTest022RemoteBusiness {

        
}
 