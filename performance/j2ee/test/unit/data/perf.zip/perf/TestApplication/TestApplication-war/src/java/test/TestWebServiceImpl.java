package test;


/**
 * This is the implementation bean class for the TestWebServiceweb service.
 * Created Mar 22, 2005 3:37:20 PM
 * @author blaha
 */
public class TestWebServiceImpl implements TestWebServiceSEI {
    
    
    // Enter web service operations here. (Popup menu: Web Service->Add Operation)
}
