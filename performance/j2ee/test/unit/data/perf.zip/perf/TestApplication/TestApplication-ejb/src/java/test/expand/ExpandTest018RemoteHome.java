
package test.expand;


/**
 * This is the home interface for ExpandTest018 enterprise bean.
 */
public interface ExpandTest018RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest018Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
