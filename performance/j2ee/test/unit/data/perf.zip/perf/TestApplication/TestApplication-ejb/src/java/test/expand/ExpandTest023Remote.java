
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest023 enterprise bean.
*/ 
public interface ExpandTest023Remote extends javax.ejb.EJBObject, test.expand.ExpandTest023RemoteBusiness {

        
}
 