
package test.expand;


/**
 * This is the business interface for ExpandTest006 enterprise bean.
 */
public interface ExpandTest006RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
