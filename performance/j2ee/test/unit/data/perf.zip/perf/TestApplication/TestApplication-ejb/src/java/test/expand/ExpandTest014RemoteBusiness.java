
package test.expand;


/**
 * This is the business interface for ExpandTest014 enterprise bean.
 */
public interface ExpandTest014RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
