
package test.expand;


/**
 * This is the home interface for ExpandTest006 enterprise bean.
 */
public interface ExpandTest006RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest006Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
