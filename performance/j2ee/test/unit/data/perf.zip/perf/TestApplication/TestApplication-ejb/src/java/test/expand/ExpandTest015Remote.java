
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest015 enterprise bean.
*/ 
public interface ExpandTest015Remote extends javax.ejb.EJBObject, test.expand.ExpandTest015RemoteBusiness {

        
}
 