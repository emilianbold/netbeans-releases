
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest002 enterprise bean.
*/ 
public interface ExpandTest002Remote extends javax.ejb.EJBObject, test.expand.ExpandTest002RemoteBusiness {

        
}
 