
package test.expand;


/**
 * This is the business interface for ExpandTest001 enterprise bean.
 */
public interface ExpandTest001RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
