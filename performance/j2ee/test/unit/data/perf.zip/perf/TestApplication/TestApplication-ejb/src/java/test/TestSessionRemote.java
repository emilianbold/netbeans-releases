
package test;
   
   
/**
* This is the remote interface for TestSession enterprise bean.
*/ 
public interface TestSessionRemote extends javax.ejb.EJBObject, test.TestSessionRemoteBusiness {

        
}
 