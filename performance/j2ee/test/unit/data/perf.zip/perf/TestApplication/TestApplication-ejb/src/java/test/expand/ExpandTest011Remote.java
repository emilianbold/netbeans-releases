
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest011 enterprise bean.
*/ 
public interface ExpandTest011Remote extends javax.ejb.EJBObject, test.expand.ExpandTest011RemoteBusiness {

        
}
 