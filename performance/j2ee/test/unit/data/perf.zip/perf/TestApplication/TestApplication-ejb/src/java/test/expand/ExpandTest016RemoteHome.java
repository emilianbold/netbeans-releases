
package test.expand;


/**
 * This is the home interface for ExpandTest016 enterprise bean.
 */
public interface ExpandTest016RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest016Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
