
package test.expand;


/**
 * This is the home interface for ExpandTest004 enterprise bean.
 */
public interface ExpandTest004RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest004Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
