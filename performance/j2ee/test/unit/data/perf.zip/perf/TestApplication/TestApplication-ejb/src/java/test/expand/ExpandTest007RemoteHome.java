
package test.expand;


/**
 * This is the home interface for ExpandTest007 enterprise bean.
 */
public interface ExpandTest007RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest007Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
