
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest024 enterprise bean.
*/ 
public interface ExpandTest024Remote extends javax.ejb.EJBObject, test.expand.ExpandTest024RemoteBusiness {

        
}
 