
package test.expand;


/**
 * This is the home interface for ExpandTest019 enterprise bean.
 */
public interface ExpandTest019RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest019Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
