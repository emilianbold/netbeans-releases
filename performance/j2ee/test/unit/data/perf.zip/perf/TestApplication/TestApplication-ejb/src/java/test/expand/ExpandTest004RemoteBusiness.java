
package test.expand;


/**
 * This is the business interface for ExpandTest004 enterprise bean.
 */
public interface ExpandTest004RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
