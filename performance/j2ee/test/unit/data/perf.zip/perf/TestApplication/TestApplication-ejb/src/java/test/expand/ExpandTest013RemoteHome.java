
package test.expand;


/**
 * This is the home interface for ExpandTest013 enterprise bean.
 */
public interface ExpandTest013RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest013Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
