
package test.expand;


/**
 * This is the home interface for ExpandTest010 enterprise bean.
 */
public interface ExpandTest010RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest010Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
