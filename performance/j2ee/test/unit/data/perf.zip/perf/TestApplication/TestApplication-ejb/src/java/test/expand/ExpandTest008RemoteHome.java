
package test.expand;


/**
 * This is the home interface for ExpandTest008 enterprise bean.
 */
public interface ExpandTest008RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest008Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
