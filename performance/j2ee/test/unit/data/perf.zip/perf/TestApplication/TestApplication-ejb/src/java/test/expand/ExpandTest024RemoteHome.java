
package test.expand;


/**
 * This is the home interface for ExpandTest024 enterprise bean.
 */
public interface ExpandTest024RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest024Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
