
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest019 enterprise bean.
*/ 
public interface ExpandTest019Remote extends javax.ejb.EJBObject, test.expand.ExpandTest019RemoteBusiness {

        
}
 