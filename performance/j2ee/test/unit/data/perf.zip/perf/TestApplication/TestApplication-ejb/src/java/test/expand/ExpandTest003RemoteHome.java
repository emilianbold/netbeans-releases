
package test.expand;


/**
 * This is the home interface for ExpandTest003 enterprise bean.
 */
public interface ExpandTest003RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest003Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
