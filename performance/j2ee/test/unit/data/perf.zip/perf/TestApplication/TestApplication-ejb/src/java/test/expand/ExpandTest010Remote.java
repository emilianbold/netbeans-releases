
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest010 enterprise bean.
*/ 
public interface ExpandTest010Remote extends javax.ejb.EJBObject, test.expand.ExpandTest010RemoteBusiness {

        
}
 