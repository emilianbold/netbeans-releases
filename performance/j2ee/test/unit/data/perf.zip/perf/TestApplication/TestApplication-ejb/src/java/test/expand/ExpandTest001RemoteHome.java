
package test.expand;


/**
 * This is the home interface for ExpandTest001 enterprise bean.
 */
public interface ExpandTest001RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest001Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
