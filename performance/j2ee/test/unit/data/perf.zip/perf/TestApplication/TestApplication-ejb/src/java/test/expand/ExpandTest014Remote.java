
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest014 enterprise bean.
*/ 
public interface ExpandTest014Remote extends javax.ejb.EJBObject, test.expand.ExpandTest014RemoteBusiness {

        
}
 