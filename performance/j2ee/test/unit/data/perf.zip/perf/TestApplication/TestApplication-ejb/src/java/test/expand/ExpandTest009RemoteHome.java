
package test.expand;


/**
 * This is the home interface for ExpandTest009 enterprise bean.
 */
public interface ExpandTest009RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest009Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
