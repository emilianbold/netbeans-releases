
package test.expand;


/**
 * This is the home interface for ExpandTest023 enterprise bean.
 */
public interface ExpandTest023RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest023Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
