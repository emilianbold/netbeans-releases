
package test.expand;


/**
 * This is the business interface for ExpandTest002 enterprise bean.
 */
public interface ExpandTest002RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
