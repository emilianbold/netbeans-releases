
package test.expand;


/**
 * This is the business interface for ExpandTest009 enterprise bean.
 */
public interface ExpandTest009RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
