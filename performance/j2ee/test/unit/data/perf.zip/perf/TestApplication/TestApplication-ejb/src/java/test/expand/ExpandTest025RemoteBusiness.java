
package test.expand;


/**
 * This is the business interface for ExpandTest025 enterprise bean.
 */
public interface ExpandTest025RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
