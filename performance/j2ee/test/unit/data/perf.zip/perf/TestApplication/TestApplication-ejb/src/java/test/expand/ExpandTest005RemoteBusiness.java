
package test.expand;


/**
 * This is the business interface for ExpandTest005 enterprise bean.
 */
public interface ExpandTest005RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
