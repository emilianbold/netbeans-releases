
package test.expand;


/**
 * This is the home interface for ExpandTest011 enterprise bean.
 */
public interface ExpandTest011RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest011Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
