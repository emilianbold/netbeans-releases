
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest007 enterprise bean.
*/ 
public interface ExpandTest007Remote extends javax.ejb.EJBObject, test.expand.ExpandTest007RemoteBusiness {

        
}
 