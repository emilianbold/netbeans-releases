
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest017 enterprise bean.
*/ 
public interface ExpandTest017Remote extends javax.ejb.EJBObject, test.expand.ExpandTest017RemoteBusiness {

        
}
 