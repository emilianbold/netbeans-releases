
package test.expand;


/**
 * This is the home interface for ExpandTest022 enterprise bean.
 */
public interface ExpandTest022RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest022Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
