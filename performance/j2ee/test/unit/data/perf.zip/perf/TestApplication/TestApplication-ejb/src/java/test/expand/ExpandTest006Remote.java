
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest006 enterprise bean.
*/ 
public interface ExpandTest006Remote extends javax.ejb.EJBObject, test.expand.ExpandTest006RemoteBusiness {

        
}
 