
package test.expand;


/**
 * This is the business interface for ExpandTest003 enterprise bean.
 */
public interface ExpandTest003RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
