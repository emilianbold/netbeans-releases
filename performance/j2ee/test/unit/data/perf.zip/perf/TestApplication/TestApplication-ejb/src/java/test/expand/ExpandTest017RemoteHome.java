
package test.expand;


/**
 * This is the home interface for ExpandTest017 enterprise bean.
 */
public interface ExpandTest017RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest017Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
