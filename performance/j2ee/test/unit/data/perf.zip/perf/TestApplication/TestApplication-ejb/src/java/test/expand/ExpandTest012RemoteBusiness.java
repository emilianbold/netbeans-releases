
package test.expand;


/**
 * This is the business interface for ExpandTest012 enterprise bean.
 */
public interface ExpandTest012RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
