
package test.expand;


/**
 * This is the business interface for ExpandTest024 enterprise bean.
 */
public interface ExpandTest024RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
