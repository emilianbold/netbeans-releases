
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest021 enterprise bean.
*/ 
public interface ExpandTest021Remote extends javax.ejb.EJBObject, test.expand.ExpandTest021RemoteBusiness {

        
}
 