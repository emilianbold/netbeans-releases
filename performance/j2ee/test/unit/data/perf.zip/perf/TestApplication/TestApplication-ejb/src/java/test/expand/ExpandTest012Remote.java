
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest012 enterprise bean.
*/ 
public interface ExpandTest012Remote extends javax.ejb.EJBObject, test.expand.ExpandTest012RemoteBusiness {

        
}
 