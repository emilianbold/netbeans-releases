
package test.expand;


/**
 * This is the home interface for ExpandTest005 enterprise bean.
 */
public interface ExpandTest005RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest005Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
