
package test.expand;


/**
 * This is the home interface for ExpandTest012 enterprise bean.
 */
public interface ExpandTest012RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest012Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
