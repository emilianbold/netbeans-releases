
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest008 enterprise bean.
*/ 
public interface ExpandTest008Remote extends javax.ejb.EJBObject, test.expand.ExpandTest008RemoteBusiness {

        
}
 