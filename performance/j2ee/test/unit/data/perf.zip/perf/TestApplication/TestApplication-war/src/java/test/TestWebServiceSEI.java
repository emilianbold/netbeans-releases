package test;


/**
 * This is the service endpoint interface for the TestWebServiceweb service.
 * Created Mar 22, 2005 3:37:20 PM
 * @author blaha
 */

public interface TestWebServiceSEI extends java.rmi.Remote {
    
}
