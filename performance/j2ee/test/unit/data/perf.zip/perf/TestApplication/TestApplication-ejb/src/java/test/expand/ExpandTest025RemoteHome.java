
package test.expand;


/**
 * This is the home interface for ExpandTest025 enterprise bean.
 */
public interface ExpandTest025RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest025Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
