
package test.expand;


/**
 * This is the home interface for ExpandTest002 enterprise bean.
 */
public interface ExpandTest002RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.expand.ExpandTest002Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
