
package test.expand;
   
   
/**
* This is the remote interface for ExpandTest013 enterprise bean.
*/ 
public interface ExpandTest013Remote extends javax.ejb.EJBObject, test.expand.ExpandTest013RemoteBusiness {

        
}
 