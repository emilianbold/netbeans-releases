
package test.expand;


/**
 * This is the business interface for ExpandTest022 enterprise bean.
 */
public interface ExpandTest022RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
