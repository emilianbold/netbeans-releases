
package test;


/**
 * This is the business interface for TestEntity enterprise bean.
 */
public interface TestEntityLocalBusiness {
    java.lang.String getCmpField();

    void setCmpField(java.lang.String cmpField);

    String businessMethod();
    
}
