
package test.expand;


/**
 * This is the business interface for ExpandTest010 enterprise bean.
 */
public interface ExpandTest010RemoteBusiness {
    String testMethod() throws java.rmi.RemoteException;
    
}
