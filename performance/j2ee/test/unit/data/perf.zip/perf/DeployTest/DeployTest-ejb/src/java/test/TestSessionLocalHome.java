
package test;


/**
 * This is the local-home interface for TestSession enterprise bean.
 */
public interface TestSessionLocalHome extends javax.ejb.EJBLocalHome {
    
    
    
    /**
     *
     */
    test.TestSessionLocal create()  throws javax.ejb.CreateException;
    
    
}
