
package test;


/**
 * This is the home interface for TestSession enterprise bean.
 */
public interface TestSessionRemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.TestSessionRemote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
