package wstest;


/**
 * This is the implementation bean class for the TestWebService web service.
 * Created 26.4.2005 17:06:24
 * @author lm97939
 */
public class TestWebServiceImpl implements TestWebServiceSEI {
    
    
    // Enter web service operations here. (Popup menu: Web Service->Add Operation)
    /**
     * Web service operation
     */
    public String testOperation() throws java.rmi.RemoteException {
        return lookupTestSessionBean().testMethod();
    }

    private test.TestSessionLocal lookupTestSessionBean() {
        try {
            javax.naming.Context c = new javax.naming.InitialContext();
            test.TestSessionLocalHome rv = (test.TestSessionLocalHome) c.lookup("java:comp/env/ejb/TestSessionBean");
            return rv.create();
        }
        catch(javax.naming.NamingException ne) {
            java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE,"exception caught" ,ne);
            throw new RuntimeException(ne);
        }
        catch(javax.ejb.CreateException ce) {
            java.util.logging.Logger.getLogger(getClass().getName()).log(java.util.logging.Level.SEVERE,"exception caught" ,ce);
            throw new RuntimeException(ce);
        }
    }
}
