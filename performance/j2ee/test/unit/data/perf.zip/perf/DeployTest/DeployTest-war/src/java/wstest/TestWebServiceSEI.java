package wstest;


/**
 * This is the service endpoint interface for the TestWebServiceweb service.
 * Created 26.4.2005 17:06:24
 * @author lm97939
 */

public interface TestWebServiceSEI extends java.rmi.Remote {
    /**
     * Web service operation
     */
    public String testOperation() throws java.rmi.RemoteException;
    
}
