package test;


/**
 * This is the service endpoint interface for the WebService1web service.
 * Created Mar 23, 2005 12:23:12 AM
 * @author blaha
 */

public interface WebService1SEI extends java.rmi.Remote {
    
}
