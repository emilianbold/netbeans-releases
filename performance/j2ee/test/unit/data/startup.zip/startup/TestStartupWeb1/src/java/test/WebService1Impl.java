package test;


/**
 * This is the implementation bean class for the WebService1web service.
 * Created Mar 23, 2005 12:23:12 AM
 * @author blaha
 */
public class WebService1Impl implements WebService1SEI {
    
    
    // Enter web service operations here. (Popup menu: Web Service->Add Operation)
}
