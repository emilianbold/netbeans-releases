package test;


/**
 * This is the service endpoint interface for the WebService3web service.
 * Created Mar 23, 2005 12:25:25 AM
 * @author blaha
 */

public interface WebService3SEI extends java.rmi.Remote {
    
}
