package test;


/**
 * This is the implementation bean class for the WebService3web service.
 * Created Mar 23, 2005 12:25:25 AM
 * @author blaha
 */
public class WebService3Impl implements WebService3SEI {
    
    
    // Enter web service operations here. (Popup menu: Web Service->Add Operation)
}
