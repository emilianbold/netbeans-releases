
package test;


/**
 * This is the business interface for TestSession enterprise bean.
 */
public interface TestSessionLocalBusiness {
    String sayHello();
    
}
