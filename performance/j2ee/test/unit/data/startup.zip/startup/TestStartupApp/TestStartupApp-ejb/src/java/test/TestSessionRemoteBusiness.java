
package test;


/**
 * This is the business interface for TestSession enterprise bean.
 */
public interface TestSessionRemoteBusiness {
    String sayHello() throws java.rmi.RemoteException;
    
}
