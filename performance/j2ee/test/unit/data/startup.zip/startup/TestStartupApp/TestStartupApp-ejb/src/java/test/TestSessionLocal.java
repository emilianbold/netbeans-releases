
package test;
   
   
/**
* This is the local interface for TestSession enterprise bean.
*/ 
public interface TestSessionLocal extends javax.ejb.EJBLocalObject, test.TestSessionLocalBusiness {

        
}
 