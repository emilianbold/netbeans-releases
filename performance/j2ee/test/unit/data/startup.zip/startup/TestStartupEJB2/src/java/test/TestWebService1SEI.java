package test;


/**
 * This is the service endpoint interface for the TestWebService1web service.
 * Created 25.2.2005 10:25:32
 * @author lm97939
 */

public interface TestWebService1SEI extends java.rmi.Remote {
    /**
     * Web service operation
     */
    public int sum(int a, int b) throws java.rmi.RemoteException;
    
}
