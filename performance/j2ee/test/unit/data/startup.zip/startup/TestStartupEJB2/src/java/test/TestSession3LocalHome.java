
package test;


/**
 * This is the local-home interface for TestSession3 enterprise bean.
 */
public interface TestSession3LocalHome extends javax.ejb.EJBLocalHome {
    
    
    
    /**
     *
     */
    test.TestSession3Local create()  throws javax.ejb.CreateException;
    
    
}
