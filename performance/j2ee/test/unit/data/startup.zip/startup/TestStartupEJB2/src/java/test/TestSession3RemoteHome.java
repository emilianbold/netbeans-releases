
package test;


/**
 * This is the home interface for TestSession3 enterprise bean.
 */
public interface TestSession3RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.TestSession3Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
