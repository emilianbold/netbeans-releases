
package test;
   
   
/**
* This is the remote interface for TestSession3 enterprise bean.
*/ 
public interface TestSession3Remote extends javax.ejb.EJBObject, test.TestSession3RemoteBusiness {

        
}
 