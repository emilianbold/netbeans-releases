
package test;
   
   
/**
* This is the local interface for TestSession3 enterprise bean.
*/ 
public interface TestSession3Local extends javax.ejb.EJBLocalObject, test.TestSession3LocalBusiness {

        
}
 