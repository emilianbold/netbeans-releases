package test;


/**
 * This is the service endpoint interface for the TestWebService2web service.
 * Created 28.2.2005 11:51:09
 * @author lm97939
 */

public interface TestWebService2SEI extends java.rmi.Remote {
    /**
     * Web service operation
     */
    public int count(int a, int b) throws java.rmi.RemoteException;

    
}
