
package test;


/**
 * This is the business interface for TestSession3 enterprise bean.
 */
public interface TestSession3LocalBusiness {
    int sum(int a, int b);
    
}
