
package test;


/**
 * This is the business interface for TestSession3 enterprise bean.
 */
public interface TestSession3RemoteBusiness {
    int sum(int a, int b) throws java.rmi.RemoteException;
    
}
