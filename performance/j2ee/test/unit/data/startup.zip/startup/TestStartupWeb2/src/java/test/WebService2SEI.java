package test;


/**
 * This is the service endpoint interface for the WebService2web service.
 * Created Mar 23, 2005 12:24:38 AM
 * @author blaha
 */

public interface WebService2SEI extends java.rmi.Remote {
    
}
