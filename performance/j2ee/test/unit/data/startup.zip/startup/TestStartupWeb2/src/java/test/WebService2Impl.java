package test;


/**
 * This is the implementation bean class for the WebService2web service.
 * Created Mar 23, 2005 12:24:38 AM
 * @author blaha
 */
public class WebService2Impl implements WebService2SEI {
    
    
    // Enter web service operations here. (Popup menu: Web Service->Add Operation)
}
