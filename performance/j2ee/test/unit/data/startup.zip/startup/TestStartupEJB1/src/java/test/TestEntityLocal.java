
package test;
   
   
/**
* This is the local interface for TestEntity enterprise bean.
*/ 
public interface TestEntityLocal extends javax.ejb.EJBLocalObject, test.TestEntityLocalBusiness {

        
}
 