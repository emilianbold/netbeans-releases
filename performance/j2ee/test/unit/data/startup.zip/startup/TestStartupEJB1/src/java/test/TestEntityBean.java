package test;
    
import javax.ejb.*;
  
/**
 * This is the bean class for the TestEntityBean enterprise bean.
 * Created 25.2.2005 10:18:38
 * @author lm97939
 */
   public abstract class TestEntityBean implements javax.ejb.EntityBean, test.TestEntityLocalBusiness {
         private javax.ejb.EntityContext context;
        
         // <editor-fold defaultstate="collapsed" desc="EJB infrastructure methods. Click on the + sign on the left to edit the code.">
         // TODO Consider creating Transfer Object to encapsulate data
         // TODO Review finder methods
         /**
          * @see javax.ejb.EntityBean#setEntityContext(javax.ejb.EntityContext)
          */
          public void setEntityContext (javax.ejb.EntityContext aContext) {
              context = aContext;
          }

         /**
          * @see javax.ejb.EntityBean#ejbActivate()
          */
          public void ejbActivate () {

          }
  
         /**
          * @see javax.ejb.EntityBean#ejbPassivate()
          */
          public void ejbPassivate () {

          }

         /**
          * @see javax.ejb.EntityBean#ejbRemove()
          */
          public void ejbRemove () {

          }
  
         /**
          * @see javax.ejb.EntityBean#unsetEntityContext()
          */
          public void unsetEntityContext () {
              context = null;
          }

         /**
          * @see javax.ejb.EntityBean#ejbLoad()
          */
          public void ejbLoad () {

          }
  
         /**
          * @see javax.ejb.EntityBean#ejbStore()
          */
          public void ejbStore () {

          }
          // </editor-fold>
          
        // <editor-fold defaultstate="collapsed" desc="CMP fields and relationships. Click on the + sign on the left to edit the code.">
           
          public abstract java.lang.String getKey();
          public abstract void setKey(java.lang.String key);
        
         // </editor-fold>
         
         public java.lang.String ejbCreate(java.lang.String key)  throws javax.ejb.CreateException {
             if (key == null) {
                 throw new javax.ejb.CreateException("The field \"key\" must not be null");
             }
                         
             // TODO add additional validation code, throw CreateException if data is not valid
             setKey(key);
              
             return null;
         }
     
         public void ejbPostCreate(java.lang.String key) {
             // TODO populate relationships here if appropriate
             
         }

       public String businessMethod() {
           //TODO implement businessMethod
           return null;
       }

       public abstract java.lang.String getCmpField();

       public abstract void setCmpField(java.lang.String cmpField);
   }
  