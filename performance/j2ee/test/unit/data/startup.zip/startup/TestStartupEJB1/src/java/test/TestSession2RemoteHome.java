
package test;


/**
 * This is the home interface for TestSession2 enterprise bean.
 */
public interface TestSession2RemoteHome extends javax.ejb.EJBHome {
    
    
    
    /**
     *
     */
    test.TestSession2Remote create()  throws javax.ejb.CreateException, java.rmi.RemoteException;
    
    
}
