
package test;


/**
 * This is the local-home interface for TestEntity enterprise bean.
 */
public interface TestEntityLocalHome extends javax.ejb.EJBLocalHome {
    
    
    
    /**
     *
     */
    test.TestEntityLocal findByPrimaryKey(java.lang.String key)  throws javax.ejb.FinderException;
    
    
}
