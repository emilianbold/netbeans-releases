
package test;
   
   
/**
* This is the remote interface for TestSession2 enterprise bean.
*/ 
public interface TestSession2Remote extends javax.ejb.EJBObject, test.TestSession2RemoteBusiness {

        
}
 