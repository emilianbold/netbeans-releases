
package test;
   
   
/**
* This is the local interface for TestSession2 enterprise bean.
*/ 
public interface TestSession2Local extends javax.ejb.EJBLocalObject, test.TestSession2LocalBusiness {

        
}
 