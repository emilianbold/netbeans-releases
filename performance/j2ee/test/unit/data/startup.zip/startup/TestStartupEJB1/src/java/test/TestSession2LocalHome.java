
package test;


/**
 * This is the local-home interface for TestSession2 enterprise bean.
 */
public interface TestSession2LocalHome extends javax.ejb.EJBLocalHome {
    
    
    
    /**
     *
     */
    test.TestSession2Local create()  throws javax.ejb.CreateException;
    
    
}
