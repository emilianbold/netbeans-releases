
package test;


/**
 * This is the business interface for TestSession2 enterprise bean.
 */
public interface TestSession2LocalBusiness {
    String businessMethod();
    
}
