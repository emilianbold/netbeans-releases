
package test;


/**
 * This is the business interface for TestSession2 enterprise bean.
 */
public interface TestSession2RemoteBusiness {
    String businessMethod() throws java.rmi.RemoteException;
    
}
