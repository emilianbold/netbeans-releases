
package test;


/**
 * This is the business interface for TestEntity enterprise bean.
 */
public interface TestEntityLocalBusiness {
    String businessMethod();

    java.lang.String getCmpField();

    void setCmpField(java.lang.String cmpField);
    
}
