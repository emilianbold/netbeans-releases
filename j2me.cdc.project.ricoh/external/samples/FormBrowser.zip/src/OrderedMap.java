

//
// Provide a named alias for an ordered map.
//
// LinkedHashMap retains the order of the items
// added to it, but is not available in JDK 1.3.
// The source code for LinkedHashMap is available
// via the Sun Community Source License, but Ricoh
// does not have redistribution rights for this
// file.  Change OrderedMap to extend com.sun.tools.jdi.LinkedHashMap
// to use the LinkedHashMap implementation from Sun.
//
//	public class OrderedMap extends com.sun.tools.jdi.LinkedHashMap
//
// HashMap does not maintain order, but the code
// will still compile if built this way.
//
public class OrderedMap extends java.util.HashMap
{
	// Ordered map provides no new methods and adds
	// no new functionality; it is used only as an alias
	// for the actual map implementation we wish to use.
}
