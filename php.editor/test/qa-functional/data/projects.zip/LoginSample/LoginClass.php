<?php
session_start();
class LoginClass
{

    function connecttodb($host,$uname,$pass,$db)
    {

        $connection=mysql_connect($host,$uname,$pass);
        $connecteddb=mysql_select_db($db);return;
    }
    function verifylogin($login,$pw,$table,$encrpt=0)
    {
        if($encrpt==0)
            $query="SELECT `pw`,COUNT(`pw`) FROM `$table` WHERE `login`='$login' GROUP BY `pw`";
        else
             $query="SELECT md5(`pw`),COUNT(`pw`) FROM `$table` WHERE `login`='$login' GROUP BY `pw`";
             $result=mysql_query($query);
        if(!$result)
            echo "Error Occured:".mysql_error()."Error No:".mysql_errno()."<br>";
        else
        {
            $row=mysql_fetch_row($result);
            $current_pw=$row[0];
            $count=$row[1];
            if($count==0)
            return(0); //not registered

            else
            {
                if($pw==$current_pw)
                { $_SESSION['login']=$login;return(1); }
                else
                return(2);//password incorrect
            }
        }
    }
} 
?>	