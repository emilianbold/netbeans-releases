<HTML>
<HEAD>
    <TITLE> Login page </TITLE>
</HEAD>
<BODY bgcolor="#52286E">





<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>
<div align="center">
<center>
<table border="0" width="966" height="203">
<tr>
<td width="966" height="1" bgcolor="#FFFFFF" align="center">
<p align="center"><font face="Verdana" size="1"><b>
<marquee><a>*** Please enter the login name and password, then press login button. ***</a></marquee>
</b></font></td>
</tr>
<tr>
    <td width="966" height="241" align="center">


<?php


include("LoginClass.php");


$username=$_POST['username'];
$password=$_POST['password'];
$login=new LoginClass;


$login->connecttodb("localhost","root","adminadmin","useraccess");
$return=$login->verifylogin($username,$password,"users",0);//password is encrpted                                                                            //using md5()
switch($return)
{
    case 0:
    echo "username is not registered till";
    break;
    case 1:
    echo "welcome".$_SESSION['username'];
    break;
    case 2:
    echo "password incorrect";
    break;
}
?>

    </td>
</tr>
<tr>
    <td width="966" height="1" bgcolor="#FFFFFF">
    <p align="center"><font face="Verdana" size="1"><b>this scrept was created for testing</b></font></td>
</tr>
</table>
</center>
</div>

</BODY>
</HTML>

