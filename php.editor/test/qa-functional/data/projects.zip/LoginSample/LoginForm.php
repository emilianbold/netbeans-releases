
<HTML>
<HEAD>
    <TITLE> Login page </TITLE>
</HEAD>
<BODY bgcolor="#22286C">





<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>



<p>&nbsp;</p>
<div align="center">
<center>
<table border="0" width="966" height="203">
<tr>
<td width="966" height="1" bgcolor="#FFFFFF" align="center">
<p align="center"><font face="Verdana" size="1"><b>
<marquee><a>*** Please enter the login name and password, then press login button. ***</a></marquee>
</b></font></td>
</tr>
<tr>
    <td width="966" height="241" align="center">


        <FORM METHOD="post" ACTION="LoginRes.php">

            <p><font face="Verdana" size="2"><b>Login: <INPUT TYPE="text" NAME="username" SIZE=10></b></font></p>

            <p><font face="Verdana" size="2"><b>Password: <INPUT TYPE="text" NAME="password" SIZE=10></b></font></p>

            <p><INPUT TYPE="submit" NAME="login" VALUE="login"></p>

        </FORM>



    </td>
</tr>
<tr>
    <td width="966" height="1" bgcolor="#FFFFFF">
    <p align="center"><font face="Verdana" size="1"><b>this scrept was created for testing</b></font></td>
</tr>
</table>
</center>
</div>

</BODY>
</HTML>


