--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
SET @saved_cs_client     = @@character_set_client;
SET character_set_client = utf8;
CREATE TABLE `users` (
  `id` int(11) NOT NULL auto_increment,
  `login` varchar(25) NOT NULL default '',
  `pw` varchar(32) NOT NULL default '',
  `real_name` varchar(32) NOT NULL default '',
  `extra_info` varchar(100) NOT NULL default '',
  `email` varchar(50) NOT NULL default '',
  `tmp_mail` varchar(50) NOT NULL default '',
  PRIMARY KEY  (`id`),
  UNIQUE KEY `user` (`login`),
  UNIQUE KEY `mail` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=1000058 DEFAULT CHARSET=latin1;
SET character_set_client = @saved_cs_client;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'vika','vika','Victoria','','mail1','');
INSERT INTO `users` VALUES (2, 'hong','hong','Hong Lin','','mail2','');
INSERT INTO `users` VALUES (3, 'misha','misha','Misha','','mail3','');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;

