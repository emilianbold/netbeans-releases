<?php

class Application_Model_DbTable_PropertyBuildType extends Zend_Db_Table_Abstract
{

    protected $_name = 'property_build';


}

