<?php

class Application_Model_DbTable_PriceType extends Zend_Db_Table_Abstract
{

    protected $_name = 'price_type';


}

