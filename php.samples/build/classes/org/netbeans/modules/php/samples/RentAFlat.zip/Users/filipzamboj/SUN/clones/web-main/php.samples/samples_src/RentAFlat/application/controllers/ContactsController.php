<?php

include_once 'BaseController.php';

class ContactsController extends BaseController {

    public function indexAction() {
        
    }

}