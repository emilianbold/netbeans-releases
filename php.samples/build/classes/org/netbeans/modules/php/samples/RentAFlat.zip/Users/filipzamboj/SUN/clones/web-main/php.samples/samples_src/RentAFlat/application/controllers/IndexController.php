<?php

include_once 'BaseController.php';

class IndexController extends BaseController {

    public function indexAction() {

    }

}

