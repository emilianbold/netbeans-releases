/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import javax.ejb.Stateless;

/**
 *
 * @author sickboy
 */
@Stateless
public class TestSessionBeanBean implements TestSessionBeanLocal {

    public String businessMethod() {
        return "Hello";
    }
    
    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method" or "Web Service > Add Operation")
 
}
