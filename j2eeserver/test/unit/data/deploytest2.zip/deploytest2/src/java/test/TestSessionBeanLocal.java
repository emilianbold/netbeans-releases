/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package test;

import javax.ejb.Local;

/**
 *
 * @author sickboy
 */
@Local
public interface TestSessionBeanLocal {

    String businessMethod();
    
}
